import React, { Component } from 'react';
import TablaDinamica from '../comun/TablaDinamica/TablaDinamica';
import Grid from '@material-ui/core/Grid';
import {Panel} from 'primereact/panel';
import {connect} from 'react-redux';


class Configuracion extends Component {
    constructor(props){
        super(props);
        this.state={
           treeData:[],
           selectedNodeKey:null,
           mostrarOperaciones:false,
           operaciones:[],
           mostrarSubdetalle:false,
           subdetalleCabecera:[],
           contenidoSubdetalle:[],
           detalle:[],
           mostrarDetalle:true
        }
    }

    obtenerObjetoValidacion = () => {
        return [];
    }
    obtenerParametros=()=>
    {
        const parametros={
            cabecera:this.state.subdetalleCabecera,
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{return this.state.contenidoSubdetalle;},
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false
        };
        return parametros;
    }

    obtenerCabeceraDetalle= () => {
        const cabecera = [
            { title: 'Nombre', field: 'nombre', editable:"never" },
            { title: 'Valor', field: 'valor' },
        ];

        return cabecera;
    }
    ObtenerParametrosDetalle=()=>{
        const parametros={
            cabecera:this.obtenerCabeceraDetalle(),
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{
            return ([
            {codigo:1, nombre:"Pagina",valor:1},
            {codigo:2, nombre:"Parametro3",valor:2},
            {codigo:3, nombre:"Parametro3",Valor:3},
            {codigo:4, nombre:"Parametro3",valor:4}
            ])
            },
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:true,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false,
            paging:false
        };
        return parametros;      
    }

    render() {
        return (
            <React.Fragment>
                <Grid container spacing={1}>
                    <Grid item xs={6}>
                        <Panel header="Parámetros">
                        {this.state.mostrarDetalle&&
                            <TablaDinamica parametros={this.ObtenerParametrosDetalle()}/>
                        }
                        </Panel>
                        <Panel header="Detalle">
                            

                        </Panel>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        breadcrumb: state.breadcrumb
     };
}

const mapDispatchToProps = {
}


export default connect(mapStateToProps, mapDispatchToProps)(Configuracion);