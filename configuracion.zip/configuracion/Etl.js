import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import FolderOpenIcon from '@material-ui/icons/FolderOpen';
import { Link } from 'react-router-dom';
import '../../../recursos/Style.css';
import MultilineChartIcon from '@material-ui/icons/MultilineChart';
import PlaylistAddCheckIcon from '@material-ui/icons/PlaylistAddCheck';
import AlarmOnIcon from '@material-ui/icons/AlarmOn';
import AssignmentIndIcon from '@material-ui/icons/AssignmentInd';
import StorageIcon from '@material-ui/icons/Storage';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import EmojiSymbolsIcon from '@material-ui/icons/EmojiSymbols';
import LocalOfferIcon from '@material-ui/icons/LocalOffer';
import actualizarBreadCrumb from '../../../../redux/actions/actualizarBreadCrumb';
import { useDispatch } from "react-redux";

export default function Etl() {

  const [open, setOpen] = React.useState(false);
  const dispatch = useDispatch()

  const handleClick = () => {
    setOpen(!open);
  };
  function actualizarOperacion(nombre){
  dispatch(actualizarBreadCrumb(nombre));
  }

  return (
    <React.Fragment>
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      key="ejecucion_main_key"
      className="lateral_menu"
    >
      <ListItem button onClick={handleClick} selected={open}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Ejecución" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding key="operaciones_key">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("costDriversUnidad");}}>
            <ListItemIcon>
              <PlaylistAddCheckIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Cost Drivers Unidad" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="vencimientos_key">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("costDriversProducto");}}>
            <ListItemIcon>
              <AlarmOnIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Cost Drivers Producto" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="clientes_key">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("costos");}}>
            <ListItemIcon>
              <AssignmentIndIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Costos" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="datos_clientes_key">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("clientes");}}>
            <ListItemIcon>
              <StorageIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Datos de Clientes" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="costos_key">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("factorRentabilidad");}}>
            <ListItemIcon>
              <MonetizationOnIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Factor Rentabilidad" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="cost_drivers_utilidad">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("valorFrenCarga");}}>
            <ListItemIcon>
              <EmojiSymbolsIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Valor Fren Carga" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="cost_drivers_producto">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("transaccionPorCanal");}}>
            <ListItemIcon>
              <LocalOfferIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Transacción Por Canal" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="transaccion_por_porducto">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("transaccionPorProducto");}}>
            <ListItemIcon>
              <LocalOfferIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Transacción Por Producto" />
          </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="operaciones_dr">
          <Link to="/submenu/etl/operaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("operaciones");}}>
            <ListItemIcon>
              <LocalOfferIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Operaciones" />
          </ListItem>
          </Link>
        </List>

      </Collapse>
    </List>
        <List
        component="nav"
        aria-labelledby="nested-list-subheader"
        key="configuracion_key"
        className="lateral_menu"
      >
        <ListItem button onClick={handleClick} selected={open}>
          <ListItemIcon>
            <FolderOpenIcon />
          </ListItemIcon>
          <ListItemText primary="Configuración" />
          {open ? <ExpandLess /> : <ExpandMore />}
        </ListItem>
        <Collapse in={open} timeout="auto" unmountOnExit>
          <List component="div" disablePadding key="homologacion">
            <Link to="/submenu/etl/homologacion" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color:'#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="Homologación" />
            </ListItem>
            </Link>
          </List>
          <List component="div" disablePadding key="configuracion">
            <Link to="/submenu/etl/configuracion" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color:'#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="Configuracion" />
            </ListItem>
            </Link>
          </List>
        </Collapse>
      </List>
      </React.Fragment>
  );
}
