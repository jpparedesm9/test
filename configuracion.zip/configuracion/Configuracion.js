import axios from 'axios';
import {JPA_API_URL} from '../../Constantes';

class Configuracion{
    ObtenerConfiguracion=()=>{
        return axios.get(`${JPA_API_URL}/costos/jerarquia/lista`);
    }
}

export default new Configuracion();
