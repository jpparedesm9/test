import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "./comun/Menu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import ReportesServicio from '../../../api/ReportesServicio';
import BimServicio from '../../../api/BimServicio';
import { NotificationManager } from 'react-notifications';
import Box from '@material-ui/core/Box';
import html2canvas from "html2canvas";
import { LOGO_BASE_64 } from "../../../recursos/LOGO_BASE_64";
import ExportacionExcel from '../comun/TablaDinamica/exportacion/ExportacionExcel';
import ExportacionPdf from '../comun/TablaDinamica/exportacion/ExportacionPdf';
import Expandible from "./comun/TablaExpandible";
import Paper from '@material-ui/core/Paper';

const pdfConverter = require("jspdf");

class EvolutivoMensualProductosServicios extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cabecera: [],
            mostrarGrafic: false,
            mostrarTabla: false,
            graficoSpinner: false,
            tablaSpinner: false,
            servicios: [],
            ultimaCabecera: [],
            maestroDetalle2: [],
            datosGrafico: [],//this.procesarArreglo(info),,
            productos: [],
            productosFiltrados: [],
            maestroDetalle: [],
            mostrarProductos: false,
            mostrarServicios: false,
            cabeceraTabla: [],
            cuerpoTabla: [],
            mostrarTablaDatos: false,
            cabeceraGchart: [],
            cuerpoGchart: [],
            mostrarCabeceraGchart: false,
            mostrarCuerpoGchart: false,
            registrosPrimerNivel: []
        };

    }
    componentDidMount() {
        /*
        var productos = [];
        var servicios = [];
        const productosPromise = BimServicio.ObtenerProductoRentabilidad();
        productosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    productos.push({ name: registro.nombre, code: registro.codigo });
                });
        });

        this.setState({ productos }, () => {
            this.setState({ mostrarProductos: true }, () => {
            });
        });

        const codigoServicios = "codigosTiposConceptos=11";
        const serviciosPromise = ReportesServicio.obtenerNombreConceptos(codigoServicios);
        serviciosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    servicios.push({ name: registro.nombre, code: registro.codigo });
                });
            this.setState({ servicios }, () => {
                this.setState({ mostrarServicios: true }, () => {
                });
            });
        });*/
        this.iniciarOperaciones();
    }
    iniciarOperaciones = () => {
    }

    accionEjecutar = (parametros) => {
        this.setState({
            graficoSpinner: true,
            tablaSpinner: true,
            mostrarTabla: false,
            mostrarGrafic: false
        });
        ReportesServicio.obtenerReporteEvolutivoCostoRentabilidadMensual(parametros).then(resultado => {
            this.procesarArreglo(parametros, resultado.data);
        }, error => {
            NotificationManager.error('Error', "Ha ocurrido un error, intente nuevamente", 5000, () => {
                this.setState({
                    graficoSpinner: false,
                    tablaSpinner: false,
                    mostrarTabla: false,
                    mostrarGrafic: false
                });
            });
        });
    }
    procesarArreglo = (parametros, registros) => {
        var provisional = registros;
        this.setState({
            mostrarTablaDatos: false, mostrarCuerpoGchart: false
        }, () => {

            if (parseInt(parametros.tipoProducto) === 1) {
                const cabeceraTabla = ReportesServicio.convertirFormatoTablaCabecera([{ Header: 'Producto', accessor: 'ee_nombre' }], registros[0]);
                var cuerpoGchart = ReportesServicio.obtenerCuerpoGchart(cabeceraTabla, registros);
                const cuerpoTabla = ReportesServicio.convertirFormatoTablaCuerpo(registros);


                const cabeceraGchart = ReportesServicio.obtenerCabeceraFormatoGchart(cabeceraTabla);
                var registrosPrimerNivel = ReportesServicio.obtenerRegistrosPrimerNivel();
                this.setState({
                    cuerpoTabla, cabeceraTabla, cabeceraGchart, cuerpoGchart, registrosPrimerNivel
                }, () => {
                    this.setState({ mostrarTablaDatos: true, mostrarCuerpoGchart: true });
                });
            }
            else {
                const cabeceraTabla = ReportesServicio.convertirFormatoTablaCabecera([{ Header: 'Servicio', accessor: 'pivote' }], registros[0]);
                var cuerpoGchart = ReportesServicio.obtenerServicioCuerpoGchart(cabeceraTabla, provisional);
                const cuerpoTabla = ReportesServicio.convertirServicioTablaCuerpo(registros);

                const cabeceraGchart = ReportesServicio.obtenerCabeceraFormatoGchart(cabeceraTabla);

                var registrosPrimerNivel = registros;
                this.setState({
                    cuerpoTabla, cabeceraTabla, cabeceraGchart, cuerpoGchart, registrosPrimerNivel
                }, () => {
                    this.setState({ mostrarTablaDatos: true, mostrarCuerpoGchart: true });
                });
            }
        });
    }
    obtenerNombreProducto = (codigo) => {
        var nombreProducto = "";
        this.state.productos.forEach(prd => {
            if (prd.code === codigo) nombreProducto = prd.name;
        });
        return nombreProducto;
    }
    obtenerCabecera = () => {
        var cabecera = [];
        cabecera.push({ title: "Fecha", field: "fecha" });
        this.state.productosFiltrados.forEach(producto => {
            var nombreProducto = "";
            this.state.productos.forEach(prd => {
                if (prd.code === producto) nombreProducto = prd.name;
            });
            cabecera.push({ title: nombreProducto, field: "key" + producto.toString() });
        });
        return cabecera;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.state.ultimaCabecera,//this.obtenerCabecera(),
            componente: 'Canal',
            obtenerInformacion: () => {
                return this.state.maestroDetalle2;
            },
            objetoValidacion: (objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "canal",
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }
    ensamblarImagenes = async (registro) => {
        let input = window.document.getElementsByClassName(registro.identificador)[0];
        const canvas = await html2canvas(input);
        var img = canvas.toDataURL("image/png");
        return img;
    }
    exportarExcel = (parametros) => {
        parametros.componente = "Evolutivo Mensual por Productos y Servicios";
        parametros.nombreArchivo = "reporte_base";
        ExportacionExcel.descargarExcelReporte(parametros, this.state.cabeceraTabla, this.state.registrosPrimerNivel);
    }
    exportarPdf = async (parametros, registros) => {
        const pdf = new pdfConverter("l", "pt");
        const marginLeft = 20;
        var imgData = `${LOGO_BASE_64}`;
        pdf.addImage(imgData, 'JPEG', 40, 0, 190, 43);
        const elemento = (parametros.codigoElemento === 1) ? "Productos" : "Servicios";
        let content = {
            bodyStyles: { lineWidth: 0 },
            startY: 45,
            head: [['', '', '']],
            body: [
                ['Fecha Inicio: ' + parametros.fechaInicio, 'Tipo de Elemento:' + elemento, ''],
                ['Fecha Fin   : ' + parametros.fechaFin, '', '']
            ],
            showHead: 'never',
            styles: {
                bodyStyles: {
                    fillColor: "#ffffff"
                }
            },
        };
        pdf.autoTable(content);
        const cuerpoTabla = ExportacionPdf.obtenerTablaReporte(this.state.cabeceraTabla, this.state.cuerpoTabla);
        pdf.text("", marginLeft, 40);
        pdf.autoTable(cuerpoTabla);

        var id = 1;
        await Promise.all(
            registros.map(async registro => {
                var img = await this.ensamblarImagenes(registro);
                pdf.addImage(
                    img,
                    "png",
                    40,
                    400,
                    registro.width,//input.clientWidth,
                    registro.height//input.clientHeight
                    ,
                    'imageId' + id.toString(),
                    'FAST'
                );
                id = id + 1;
                //pdf.addPage();
            })
        );
        pdf.save("chart.pdf");

    };
    render() {
        return (

            <React.Fragment>
                <div>
                    {(this.state.mostrarProductos && this.state.mostrarServicios) &&
                        <Menu productos={this.state.productos} servicios={this.state.servicios} accionEjecutar={this.accionEjecutar}
                            exportarPdf={(parametros) => {
                                const registros = [
                                    { width: 800, height: 200, identificador: "superior" }
                                ];
                                this.exportarPdf(parametros, registros);
                            }}
                            exportarExcel={(registros) => {
                                this.exportarExcel(registros);
                            }}
                        />
                    }
                    <Grid container spacing={1}>
                        <Grid item xs={3}>
                            <Box style={{ maxHeight: "40vh", minHeight: "40vh", overflowX: "scroll" }} width="100%">
                                <Panel header="Fecha" style={{ maxHeight: "40vh", overflow: 'auto', overflowX: "scroll" }}>
                                    <Paper elevation={0} style={{ overflowX: "auto" }}>
                                        <div>
                                            {this.state.mostrarTablaDatos &&
                                                <Expandible cabeceraTabla={this.state.cabeceraTabla} cuerpoTabla={this.state.cuerpoTabla} />
                                            }

                                        </div>
                                    </Paper>
                                </Panel>
                            </Box>
                        </Grid>
                        <Grid item xs={9}>
                            <Box style={{ maxHeight: "40vh", minHeight: "40vh", overflowX: "scroll" }} width="100%">
                                <Panel header="Análisis de Costo por Producto" style={{ maxHeight: "40vh", overflow: 'auto', overflowX: "scroll" }}>
                                    <Paper elevation={0} style={{ overflowX: "auto" }}>
                                        <div>
                                            <Chart
                                                width={'100%'}
                                                height={'300px'}
                                                chartType="Bar"
                                                loader={<div>Loading Chart</div>}
                                                data={[
                                                    ['Producto', 'Costo Total'],
                                                    ['CUENTA DE AHORRO', 1000],
                                                    ['INMOBILIARIO', 1170],
                                                    ['SERVICIO TRANSFER', 660],
                                                    ['TARJETAS DE CREDITO', 1030],
                                                    ['SERVICIO TRJ DÉBITO', 1030],
                                                    ['CONSUMO ORDINARIO', 1030],
                                                    ['CONSUMO PRIORITARIO', 1030],
                                                    ['SERVICIO TR CREDITO', 1030],
                                                    ['COMERCIAL', 1030],
                                                ]}
                                                options={{
                                                    // Material design options
                                                    chart: {
                                                        title: 'Costo por Producto del Activo',
                                                    },
                                                }}
                                                // For tests
                                                rootProps={{ 'data-testid': '2' }}
                                            />
                                        </div>
                                    </Paper>
                                </Panel>
                            </Box>
                        </Grid>
                        <Grid item xs={12} className="superior">
                            <Box style={{ maxHeight: "40vh", minHeight: "40vh" }} width="100%">

                                <Panel header="Rentabilidad Mensual" style={{ maxHeight: "100%", overflow: 'auto', overflowX: "auto", maxWidth: "100%" }}>
                                    <Paper elevation={0} style={{ overflowX: "auto" }}>

                                        <Chart
                                            width={'100%'}
                                            height={'300px'}
                                            chartType="BarChart"
                                            loader={<div>Loading Chart</div>}
                                            data={[
                                                ['City', 'RENTABILIDAD MENSUAL'],
                                                ['CTAS. X COBRAR VARIAS', 20],
                                                ['CONTING. CRED INMOBI', 20],
                                                ['CONSTR MAZ FAC', 33000],
                                                ['COMERCIAL CASAMAZ NUEVA', 105000],
                                                ['CAJA', -20],
                                                ['BIENES REALIZABLES', -11000],
                                                ['BANCOS', 22000],
                                                ['BACK TO BACK', 1000],
                                                ['ANTICIPOS A TERCEROS', -10],
                                            ]}
                                            options={{
                                                title: 'RENTABILIDAD MENSUAL',
                                                chartArea: { width: '50%' },
                                                hAxis: {
                                                    title: 'Rentabilidad Mensual',
                                                    minValue: 0,
                                                },
                                                vAxis: {
                                                    title: 'City',
                                                },
                                            }}
                                            // For tests
                                            rootProps={{ 'data-testid': '1' }}
                                        />

                                    </Paper>
                                </Panel>


                            </Box>
                        </Grid>
                    </Grid>
                </div>
            </React.Fragment>
        );
    };
}
export default EvolutivoMensualProductosServicios;