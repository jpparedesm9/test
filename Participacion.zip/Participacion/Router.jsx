import React, { Component } from 'react';
import { BrowserRouter, Route, Switch} from 'react-router-dom';
import AuthenticatedRoute from './api/VerificarRuta';
import Inicio from './Inicio';
import ModuleTemplate from './modulos/ModuleTemplate';
import DPModeloDeDistribucion from './modulos/submodulos/costos/DistribucionAProducto/ModeloDeDistribucion/ModeloDistribucion';
import DPPonderacionDeCostDriver from './modulos/submodulos/costos/DistribucionAProducto/PonderacionDeCostDriver';
import DPCostDriver from './modulos/submodulos/costos/DistribucionAProducto/CostDriver';
import GCuentaPresupuesto from './modulos/submodulos/costos/General/CuentaPresupuesto';
import GUnidad from './modulos/submodulos/costos/General/Unidad';
import DOCostDriver from './modulos/submodulos/costos/DistribucionOverhead/CostDriver';
import DOPonderacionDeCostDriver from './modulos/submodulos/costos/DistribucionOverhead/PonderacionDeCostDriver';
import DOModeloDeDistribucion from './modulos/submodulos/costos/DistribucionOverhead/ModeloDeDistribucion/ModeloDeDistribucion';
import DOValor  from './modulos/submodulos/costos/DistribucionOverhead/ModeloDeDistribucion/Valor/DOValor';
import ModeloDistribucionProductoValor  from './modulos/submodulos/costos/DistribucionAProducto/ModeloDeDistribucion/Valor/ModeloDistribucionValor';
import CostosTablero from './tableros/costos/CostosTablero';
import JerarquiaDeOficina from './modulos/submodulos/bim/JerarquiaDeOficina';
import FuenteDeInformacion from './modulos/submodulos/bim/FuenteDeInformacion';
import Moneda from './modulos/submodulos/bim/Moneda';
import CotizaCanje from './modulos/submodulos/bim/CotizaCanje';
import Compania from './modulos/submodulos/bim/Compania';
import RegionGeografica from './modulos/submodulos/bim/RegionGeografica';
import Localidad from './modulos/submodulos/bim/Localidad';
import Funcionario from './modulos/submodulos/bim/Funcionario';
import Oficina from './modulos/submodulos/bim/Oficina';
import Unidad from './modulos/submodulos/costos/General/Unidad';
import ProductoRentabilidad from './modulos/submodulos/costos/General/ProductoRentabilidad/ProductoRentabilidad';
import CuentaPresupuesto from './modulos/submodulos/costos/General/CuentaPresupuesto';
import ProductoFinanciero from './modulos/submodulos/bim/ProductoFinanciero';
import Servicio from './modulos/submodulos/bim/Servicio';
import Canal from './modulos/submodulos/bim/Canal';
import TasaReferencial from "./modulos/submodulos/bim/TasaReferencial";
import Esquemas from "./modulos/submodulos/bim/Esquemas";
import ModeloPlazoPIT from "./modulos/submodulos/rentabilidad/ModeloPlazoPIT";
import ModeloMarginal from "./modulos/submodulos/rentabilidad/ModeloMarginal";
import ModeloOfferBid from "./modulos/submodulos/rentabilidad/ModeloOfferBid";
import EstructuraPIT from "./modulos/submodulos/rentabilidad/EstructuraPIT";
import FactoresRentabilidad from "./modulos/submodulos/rentabilidad/Rentabilidad/FactoresRentabilidad";
import ModelosAsignacionProducto from "./modulos/submodulos/rentabilidad/Rentabilidad/ModeloAsignacionProducto";
import CostoCapital from "./modulos/submodulos/rentabilidad/Rentabilidad/CostoCapital";
import AsignacionPatrimonio from "./modulos/submodulos/rentabilidad/Rentabilidad/AsignacionPatrimonio";
import AsignacionPIT from "./modulos/submodulos/rentabilidad/Rentabilidad/AsignacionPIT";
import TipoTransaccion from "./modulos/submodulos/rentabilidad/Rentabilidad/TipoTransaccion";
import ParametrizacionGeneral from "./modulos/submodulos/rentabilidad/Rentabilidad/ParametrizacionGeneral";
import Login from "./modulos/submodulos/Login";
import Indicador1 from "./modulos/submodulos/comun/TablaDinamica/Indicador1";
import ResultadoProductos from "./modulos/submodulos/comun/TablaDinamica/ResultadoProductos";
import Operaciones from "./modulos/submodulos/etl/Operaciones";
import Homologacion from "./modulos/submodulos/etl/Homologacion";
import Configuracion from "./modulos/submodulos/etl/Configuracion";

import CostosOperaciones from "./modulos/submodulos/batch/procesos/CostosOperaciones";
import BatchReporteCosto from "./modulos/submodulos/batch/reportes/BatchReporteCosto";
import BatchReportePit from "./modulos/submodulos/batch/reportes/BatchReportePit";
import ParticipacionSaldo from "./modulos/submodulos/reportes/ParticipacionSaldo";
import EvolutivoMensualProductosServicios from "./modulos/submodulos/reportes/EvolutivoMensualProductosServicios";


class Router extends Component {
    render() {
        return (
            <BrowserRouter>
                <Switch>
                    <Route path="/" exact component={Inicio} />
                    <ModuleTemplate>
                        <Route component={({ match }) =>
                            <div>
                                 <Route path='/login' exact component={Login} />
                                {/* Routes for costos Module */}
                                <Route path='/module/costos' exact component={CostosTablero} />
                                <Route path='/submenu/g_cuenta_presupuesto' exact component={GCuentaPresupuesto} />
                                <Route path='/submenu/g_unidad' exact component={GUnidad} />

                                <Route path="/submenu/do_cost_driver" exact component={DOCostDriver} />
                                <Route path="/submenu/do_ponderacion_de_cost_driver" exact component={DOPonderacionDeCostDriver} />
                                <Route path="/submenu/do_modelo_de_distribucion" exact component={DOModeloDeDistribucion} />
                                <Route path='/submenu/do_modelo_de_distribucion/valor/:id' exact component={DOValor} />
                                <Route path='/submenu/dp_modelo_de_distribucion/valor/:id' exact component={ModeloDistribucionProductoValor} />



                                <Route path='/submenu/dp_cost_driver' exact component={DPCostDriver} />
                                <Route path='/submenu/dp_ponderacion_de_cost_driver' exact component={DPPonderacionDeCostDriver} />
                                <Route path='/submenu/dp_modelo_de_distribucion' exact component={DPModeloDeDistribucion} />


                                <Route path='/submenu/costos/cuenta_presupuesto' exact component={CuentaPresupuesto} />
                                <Route path='/submenu/costos/producto_rentabilidad' exact component={ProductoRentabilidad} />
                                {/* End Routes for costos Module */}

                                {/* bim Routes */}
                                <Route path='/submenu/bim/office_jerarqui' exact component={JerarquiaDeOficina} />
                                <Route path='/submenu/bim/fuente_de_informacion' exact component={FuenteDeInformacion} />
                                <Route path='/submenu/bim/moneda' exact component={Moneda} />
                                <Route path='/submenu/bim/cotizaCanje/:id' exact component={CotizaCanje} />
                                <Route path='/submenu/bim/compania' exact component={Compania} />
                                <Route path='/submenu/bim/region_geografica' exact component={RegionGeografica} />
                                <Route path='/submenu/bim/localidad' exact component={Localidad} />
                                <Route path='/submenu/bim/funcionario' exact component={Funcionario} />
                                <Route path='/submenu/bim/oficina' exact component={Oficina} />
                                <Route path='/submenu/bim/unidad' exact component={Unidad} />
                                
                                <Route path='/submenu/bim/producto_financiero' exact component={ProductoFinanciero} />
                                <Route path='/submenu/bim/servicio' exact component={Servicio} />
                                <Route path='/submenu/bim/canal' exact component={Canal} />
                                <Route path='/submenu/bim/tasa_referencial' exact component={TasaReferencial} />
                                <Route path='/submenu/bim/esquemas' exact component={Esquemas} />
                                {/* End bim RRoutes */}

                                {/* Modulo de Rentabilidad */}
                                {/* PIT */}
                                <Route path='/submenu/rentabilidad/modelo_plazo_pit' exact component={ModeloPlazoPIT} />
                                <Route path='/submenu/rentabilidad/modelo_marginal' exact component={ModeloMarginal} />
                                <Route path='/submenu/rentabilidad/modelo_offer_bid' exact component={ModeloOfferBid} />
                                <Route path='/submenu/rentabilidad/estructura_pit' exact component={EstructuraPIT} />
                                {/* Fin PIT */}

                                {/* Rentabilidad */}
                                <Route path='/submenu/rentabilidad/factores_rentabilidad' exact component={FactoresRentabilidad} />
                                <Route path='/submenu/rentabilidad/modelo_asignacion_producto' exact component={ModelosAsignacionProducto} />
                                <Route path='/submenu/rentabilidad/costo_capital' exact component={CostoCapital} />
                                <Route path='/submenu/rentabilidad/modelo_asignacion_patrimonio' exact component={AsignacionPatrimonio} />
                                <Route path='/submenu/rentabilidad/asignacion_pit' exact component={AsignacionPIT} />

                                <Route path='/submenu/rentabilidad/tipo_transaccion' exact component={TipoTransaccion} />
                                <Route path='/submenu/rentabilidad/parametrizacion_general' exact component={ParametrizacionGeneral} />
                                {/* Fin Modulo de Rentabilidad */}

                                {/* Reportes */}
                                <Route path='/submenu/reportes/indicador1' exact component={Indicador1} />
                                <Route path='/submenu/reportes/resultado_productos' exact component={ResultadoProductos} />
                                <Route path='/submenu/reportes/evolutivo_mensual_productos_servicios' exact component={EvolutivoMensualProductosServicios} />
                                <Route path='/submenu/reportes/reporte_saldo' exact component={ParticipacionSaldo} />

                                {/* Fin Reportes */}

                                {/* Etl */}
                                <Route path='/submenu/etl/operaciones' exact component={Operaciones} />
                                <Route path='/submenu/etl/homologacion' exact component={Homologacion} />
                                <Route path='/submenu/etl/configuracion' exact component={Configuracion} />
                                {/* Fin Etl */}

                                {/* BatchOperaciones */}
                                <Route path='/submenu/batch/procesos/costosOperaciones' exact component={CostosOperaciones} />
                                <Route path='/submenu/batch/reportes/costos' exact component={BatchReporteCosto} />
                                <Route path='/submenu/batch/reportes/pit' exact component={BatchReportePit} />
                                {/* Fin Etl */}
                                
                                


                            </div>
                        } />
                    </ModuleTemplate>
                </Switch>
            </BrowserRouter>
        );
    }

}
export default Router;
