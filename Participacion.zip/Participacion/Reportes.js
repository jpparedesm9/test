import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import FolderOpenIcon from '@material-ui/icons/FolderOpen';
import { Link } from 'react-router-dom';
import '../../../recursos/Style.css';
import MultilineChartIcon from '@material-ui/icons/MultilineChart';

export default function Reportes() {

  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      key="distribucion_a_producto_key"
      className="lateral_menu"
    >
      <ListItem button onClick={handleClick} selected={open}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Reportes" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>
      <List component="div" disablePadding key="reportes_resultado_productos">
          <Link to="/submenu/reportes/indicador1" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Resultado de Productos" />
          </ListItem>
          </Link>

        </List>
        <List component="div" disablePadding key="reportes_rentabilidad">
          {/*<Link to="/submenu/reportes/indicador1" className="lateral_menu">*/}
          <Link to="/submenu/reportes/evolutivo_mensual_productos_servicios" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Rentabilidad" />
          </ListItem>
          </Link>

        </List>
        <List component="div" disablePadding key="participacion_saldo">
          {/*<Link to="/submenu/reportes/indicador1" className="lateral_menu">*/}
          <Link to="/submenu/reportes/reporte_saldo" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Participacion Saldo" />
          </ListItem>
          </Link>

        </List>
        
        
      </Collapse>
    </List>
  );
}
