import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "./menus/Menu";
import SubMenu from "./menus/SubMenu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import TablaDinamica from './TablaDinamica';
var info=[
    {fecha:"2020-08-27",
    itemReporteLista:[
    {identificador:1, valor:3.16},
    {identificador:2, valor:3.17},
    {identificador:3, valor:3.18},
    {identificador:4, valor:3.19}
    ]
    },
    {fecha:"2020-08-28",
    itemReporteLista:[
    {identificador:1, valor:3.16},
    {identificador:4, valor:3.20},
    {identificador:5, valor:3.24},
    {identificador:4, valor:3.27}
    ]
    }
    ];
class Indicador1 extends Component {
    constructor(props) {
        super(props);
        this.state={
            mostrarGrafic:false,
            mostrarTabla:false,
            datosGrafico:[],//this.procesarArreglo(info),,
            productos:[],
            productosFiltrados:[],
            maestroDetalle:[]
        };
        //this.iniciarOperaciones();
    }
    componentDidMount(){
        const productos = [
            {name: 'Producto3', code: 3},
            {name: 'Producto4', code: 4},
            {name: 'Producto5', code: 5},
            {name: 'Producto1', code: 1},
            {name: 'Producto2', code: 2},
            {name: 'ProducPrueba6', code: 6},
        ];
        this.setState({productos},()=>{
            this.procesarArreglo(info);
        });
    }
    procesarArreglo=(arregloBase)=>{
        var resultado=[];
        var maestroDetalle=[];
        var productos=arregloBase.forEach(registro=>{
        const temporal=registro.itemReporteLista.map(producto=>producto.identificador);
        resultado=resultado.concat(temporal);
        });
        const productosFiltrados=[...new Set(resultado)];
        const arregloVacio=productosFiltrados.map(registro=>0);
        const contenido=[];
        const cabecera=[];
        this.state.productos.forEach(registro=>{
            if(productosFiltrados.includes(registro.code))
            cabecera.push(registro.name);
        }  
        );
        contenido.push(["Fecha"].concat(cabecera));
        arregloBase.forEach(registro=>{
        var registroProcesado=[]; registroProcesado.push(registro.fecha);
        var registroMaestro={};
        registroMaestro.fecha=registro.fecha;
        var valores=arregloVacio;
        registro.itemReporteLista.forEach(lista=>{
        valores[productosFiltrados.indexOf(lista.identificador)]=lista.valor;
        registroMaestro["key"+lista.identificador.toString()]=lista.valor;
        });
        contenido.push(registroProcesado.concat(valores));
        maestroDetalle.push(registroMaestro);
        });
        this.setState({datosGrafico:contenido,productosFiltrados,maestroDetalle},()=>{
            this.setState({mostrarGrafic:true,mostrarTabla:true});
        }
        );
    }
    
    obtenerCabecera = () => {
        var cabecera=[];
        cabecera.push({title:"Fecha", field:"fecha"});
        this.state.productosFiltrados.forEach(producto=>{
            var nombreProducto="";
            this.state.productos.forEach(prd=>{
                if(prd.code===producto)nombreProducto=prd.name;
            });
            cabecera.push({title:nombreProducto, field:"key"+producto.toString()});
        });
        return cabecera;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.obtenerCabecera(),
            componente: 'Canal',
            obtenerInformacion: () => {
                return this.state.maestroDetalle;
            },
            objetoValidacion: (objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "canal",
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }
    render() {
        return (
            
            <React.Fragment>
                
            <div>
                <Menu />
                <Grid container spacing={1}>
                    <Grid item xs={6}>
                        <Panel header="Espacio para Datos">
                            {this.state.mostrarTabla&&
                            <TablaDinamica parametros={this.obtenerParametros()} />
                            }
                        </Panel>
                    </Grid>
                    <Grid item xs={6}>
                   
                        <Panel header="Gráfico">
                            {this.state.mostrarGrafico}
                        {this.state.mostrarGrafic&&
                            <Chart
                                width={'500px'}
                                height={'300px'}
                                chartType="AreaChart"
                                loader={<div>Loading Chart</div>}
                                data={this.state.datosGrafico}
                                options={{
                                    title: '',
                                    hAxis: { title: 'Year', titleTextStyle: { color: '#333' } },
                                    vAxis: { minValue: 0 },
                                    // For the legend to fit, we make the chart area smaller
                                    chartArea: { width: '60%'},
                                    // lineWidth: 25
                                }}
                                // For tests
                                rootProps={{ 'data-testid': '1' }}
                            />
                            }
                        </Panel>
                    </Grid>
                </Grid>
                </div>
            </React.Fragment>
        );
    };
}
export default Indicador1;