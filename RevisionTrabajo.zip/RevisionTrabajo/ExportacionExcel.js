/* eslint no-eval: 0 */
import ExcelJS from 'exceljs';
import {LOGO_BASE_64} from '../../../../../recursos/LOGO_BASE_64';
import moment from 'moment';
import {saveAs} from 'file-saver';
import BimServicio from '../../../../../api/BimServicio';
import CostosServicio from '../../../../../api/CostosServicio';
import Helper from '../helper/Helper';

class ExportacionExcel{
    generarPlantilla=async ()=>{
        const oficinaPromise = await BimServicio.ObtenerRegistrosOficina();
        let oficina=[];
        oficinaPromise.data.forEach(registro =>{
            var temp={codigo:registro.codigo, nombre:registro.nombre};
            oficina.push(temp);
        }
        );
        
        const areaPromise = await BimServicio.ObtenerRegistrosArea();
        let area=[];
        areaPromise.data.forEach(registro =>{
            var temp={codigo:registro.codigo, nombre:registro.nombre};
            area.push(temp);
        }
        );
        const wb = new ExcelJS.Workbook()
        const ws = wb.addWorksheet("Hoja1");
        ws.getCell('A1').value = "CODIGO_AREA";
        ws.getCell('B1').value = "CODIGO_OFICINA";
        ws.getCell('C1').value = "VALOR";

        const hojaArea = wb.addWorksheet("AREA");
        hojaArea.getCell('A1').value = "CODIGO_AREA";
        hojaArea.getCell('B1').value = "AREA";
        var i=2;
        area.forEach(registro=>{
            hojaArea.getCell('A'+i.toString()).value = registro.codigo;
            hojaArea.getCell('B'+i.toString()).value = registro.nombre;
            i++;
        });        

        const hojaOficina = wb.addWorksheet("OFICINA");
        hojaOficina.getCell('A1').value = "CODIGO_OFICINA";
        hojaOficina.getCell('B1').value = "OFICINA";
        i=2;
        oficina.forEach(registro=>{
            hojaOficina.getCell('A'+i.toString()).value = registro.codigo;
            hojaOficina.getCell('B'+i.toString()).value = registro.nombre;
            i++;
        });

        const buf = await wb.xlsx.writeBuffer();
        saveAs(new Blob([buf]), 'plantillaBase.xlsx');

    }
    getUniqueArray=(arr=[], compareProps=[])=>{
        let modifiedArray= [];
        if(compareProps.length === 0 && arr.length > 0)
         compareProps.push(...Object.keys(arr[0]));
           arr.map(item=> {
         if(modifiedArray.length === 0){
          modifiedArray.push(item);
         }else {
          if(!modifiedArray.some(item2=> 
          compareProps.every(eachProps=> item2[eachProps] === item[eachProps])
        )){modifiedArray.push(item);}
       }
        });return modifiedArray;
    }
    generarPlantillaDistProducto=async ()=>{
        const UnidadPromise=await CostosServicio.ObtenerRegistrosConfigDOModeloDeDistribucion(3);
        let oficina=[];
        let area=[];
        UnidadPromise.data.forEach(registro =>{
            var areaTemporal={codigo:registro.area.codigo, nombre:registro.area.nombre};
            var oficinaTemporal={codigo:registro.oficina.codigo, nombre:registro.oficina.nombre};
            area.push(areaTemporal);
            oficina.push(oficinaTemporal);
        }
        );
        area=this.getUniqueArray(area);

        const productoPromise = await BimServicio.ObtenerProductoRentabilidad();
        let producto=[];
        productoPromise.data.forEach(registro =>{
            var temp={codigo:registro.codigo, nombre:registro.nombre};
            producto.push(temp);
        }
        );

        const wb = new ExcelJS.Workbook()
        const ws = wb.addWorksheet("Hoja1");
        ws.getCell('A1').value = "CODIGO_AREA";
        ws.getCell('B1').value = "CODIGO_OFICINA";
        ws.getCell('C1').value = "CODIGO_PRODUCTO";
        ws.getCell('D1').value = "VALOR";

        const hojaArea = wb.addWorksheet("AREA");
        hojaArea.getCell('A1').value = "CODIGO_AREA";
        hojaArea.getCell('B1').value = "AREA";
        var i=2;
        area.forEach(registro=>{
            hojaArea.getCell('A'+i.toString()).value = registro.codigo;
            hojaArea.getCell('B'+i.toString()).value = registro.nombre;
            i++;
        });        

        const hojaOficina = wb.addWorksheet("OFICINA");
        hojaOficina.getCell('A1').value = "CODIGO_OFICINA";
        hojaOficina.getCell('B1').value = "OFICINA";
        i=2;
        oficina.forEach(registro=>{
            hojaOficina.getCell('A'+i.toString()).value = registro.codigo;
            hojaOficina.getCell('B'+i.toString()).value = registro.nombre;
            i++;
        });

        const hojaProducto = wb.addWorksheet("PRODUCTO");
        hojaProducto.getCell('A1').value = "CODIGO_PRODUCTO";
        hojaProducto.getCell('B1').value = "PRODUCTO";
        i=2;
        producto.forEach(registro=>{
            hojaProducto.getCell('A'+i.toString()).value = registro.codigo;
            hojaProducto.getCell('B'+i.toString()).value = registro.nombre;
            i++;
        });
        const buf = await wb.xlsx.writeBuffer();
        saveAs(new Blob([buf]), 'plantillaBaseCostDriverDistProducto.xlsx');

    }
    descargarExcelReporte=async (parametros,columns,data)=>{
        data=Helper.formatear(data);
        if(parametros.convertirPorcentaje)
        data=Helper.obtenerPorcentual(data);
        const componente=parametros.componente;
        const nombreArchivo=parametros.nombreArchivo;
        columns=columns.filter(registro=>registro.title!=="");
        const wb = new ExcelJS.Workbook()
        const ws = wb.addWorksheet()
        var imageId2 = wb.addImage({
            base64: `${LOGO_BASE_64}`,
            extension: 'png',
        });
        ws.addImage(imageId2, {
            tl: {col: 0, row: 0},
            ext: {width: 200, height: 58}
        });

        ws.columns = [
            {width: 25}, {width: 20}, {width: 20}
        ];
        ws.getCell('A5').value = "Pantalla:";
        ws.getCell('B5').value = componente;
        ws.getCell('A6').value = 'Fecha Inicial:';
        ws.getCell('B6').value = parametros.fechaInicio;
        ws.getCell('A7').value = 'Fecha Final:';
        ws.getCell('B7').value = parametros.fechaFin;
        ws.getCell('C6').value = 'Tipo de Elemento:';
        ws.getCell('D6').value = (parametros.codigoElemento===1)?"Productos":"Servicios";

        let secuencia = "A";
        let rangoTitulo = [];
        columns.forEach(cabecera => {
            let celda = secuencia + "9";
            rangoTitulo.push(celda);
            ws.getCell(celda).value = cabecera.title;
            secuencia = String.fromCharCode(secuencia.charCodeAt(0) + 1);
        });

        secuencia = "A";
        columns.forEach(key => {
            ws.getCell(secuencia + "9").fill = {
                type: "pattern",
                pattern: "solid",
                fgColor: {
                    argb: "43beac"
                },
                bgColor: {
                    argb: "43beac"
                },
                font: {bold: true, color: {argb: "ffffff"}}
            }
            secuencia = String.fromCharCode(secuencia.charCodeAt(0) + 1);
        });
        data.forEach((registro, index) => {
                secuencia = "A";
                columns.forEach(cabecera => {
                    let campo="";
                    if(typeof parametros.validarParametrizacion!=="undefined" && cabecera.field==="codigoEntidad"){
                    campo=Helper.obtenerValorParametrizacionGeneral(registro,parametros.validarParametrizacion);
                    }
                    else campo = eval("registro."+cabecera.field);
                    if (typeof cabecera.lookup !== 'undefined'&&typeof parametros.validarParametrizacion==="undefined") {
                        let lookupExtraer = cabecera.field.toString();
                        let codigo = 'registro.' + lookupExtraer;
                        campo = cabecera.lookup[eval(codigo)];
                    } else {
                        if (typeof cabecera.type !== "undefined") {
                            if (cabecera.type === "date") {
                                campo = moment(campo).format("DD-MM-YYYY").toString();
                            }
                        }
                    }
                    ws.getCell(secuencia + (index + 10).toString()).value = typeof campo === "boolean" ? campo ? "SI" : "NO" : campo;
                    secuencia = String.fromCharCode(secuencia.charCodeAt(0) + 1);
                });
            }
        );
        ws.addRows(data);
        const buf = await wb.xlsx.writeBuffer();
        saveAs(new Blob([buf]), nombreArchivo + '.xlsx');
    }
    descargarExcel=async (parametros,columns,data)=>{
        data=Helper.formatear(data);
        if(parametros.convertirPorcentaje)
        data=Helper.obtenerPorcentual(data);
        const componente=parametros.componente;
        const nombreArchivo=parametros.nombreArchivo;
        columns=columns.filter(registro=>registro.title!=="");
        const wb = new ExcelJS.Workbook()
        const ws = wb.addWorksheet()
        var imageId2 = wb.addImage({
            base64: `${LOGO_BASE_64}`,
            extension: 'png',
        });
        ws.addImage(imageId2, {
            tl: {col: 0, row: 0},
            ext: {width: 200, height: 58}
        });

        ws.columns = [
            {width: 25}, {width: 20}, {width: 20}
        ];
        ws.getCell('A5').value = "Pantalla:";
        ws.getCell('B5').value = componente;
        ws.getCell('A6').value = 'Fecha:';
        ws.getCell('B6').value = moment().format("DD-MM-YYYY");
        let secuencia = "A";
        let rangoTitulo = [];
        columns.forEach(cabecera => {
            let celda = secuencia + "8";
            rangoTitulo.push(celda);
            ws.getCell(celda).value = cabecera.title;
            secuencia = String.fromCharCode(secuencia.charCodeAt(0) + 1);
        });

        secuencia = "A";
        columns.forEach(key => {
            ws.getCell(secuencia + "8").fill = {
                type: "pattern",
                pattern: "solid",
                fgColor: {
                    argb: "43beac"
                },
                bgColor: {
                    argb: "43beac"
                },
                font: {bold: true, color: {argb: "ffffff"}}
            }
            secuencia = String.fromCharCode(secuencia.charCodeAt(0) + 1);
        });
        data.forEach((registro, index) => {
                secuencia = "A";
                columns.forEach(cabecera => {
                    let campo="";
                    if(typeof parametros.validarParametrizacion!=="undefined" && cabecera.field==="codigoEntidad"){
                    campo=Helper.obtenerValorParametrizacionGeneral(registro,parametros.validarParametrizacion);
                    }
                    else campo = eval("registro."+cabecera.field);
                    if (typeof cabecera.lookup !== 'undefined'&&typeof parametros.validarParametrizacion==="undefined") {
                        let lookupExtraer = cabecera.field.toString();
                        let codigo = 'registro.' + lookupExtraer;
                        campo = cabecera.lookup[eval(codigo)];
                    } else {
                        if (typeof cabecera.type !== "undefined") {
                            if (cabecera.type === "date") {
                                campo = moment(campo).format("DD-MM-YYYY").toString();
                            }
                        }
                    }
                    ws.getCell(secuencia + (index + 9).toString()).value = typeof campo === "boolean" ? campo ? "SI" : "NO" : campo;
                    secuencia = String.fromCharCode(secuencia.charCodeAt(0) + 1);
                });
            }
        );
        ws.addRows(data);
        const buf = await wb.xlsx.writeBuffer();
        saveAs(new Blob([buf]), nombreArchivo + '.xlsx');
    }
}

export default new ExportacionExcel();