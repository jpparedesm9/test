import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "./menus/Menu";
import SubMenu from "./menus/SubMenu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import TablaDinamica from './TablaDinamica';
import ReportesServicio from '../../../../api/ReportesServicio';
import spinner from "../../../../recursos/spinner.gif";
import { NotificationManager } from 'react-notifications';
import Box from '@material-ui/core/Box';
import TablaReporte from "./TablaReporte";
import html2canvas from "html2canvas";
import {LOGO_BASE_64} from "../../../../recursos/LOGO_BASE_64";
import ExportacionExcel from './exportacion/ExportacionExcel';

const pdfConverter = require("jspdf");

class Indicador1 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cabecera: [],
            mostrarGrafic: false,
            mostrarTabla: false,
            graficoSpinner: false,
            tablaSpinner: false,
            ultimaCabecera: [],
            maestroDetalle2: [],
            datosGrafico: [],//this.procesarArreglo(info),,
            productos: [],
            productosFiltrados: [],
            maestroDetalle: [],
            mostrarProductos: false
        };
    }
    componentDidMount() {
        var productos = [];
        const codigoProductos = "codigosTiposConceptos=1&codigosTiposConceptos=2&codigosTiposConceptos=5";
        const productosPromise = ReportesServicio.obtenerNombreConceptos(codigoProductos);
        productosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    productos.push({ name: registro.nombre, code: registro.codigo });
                });
        });

        this.setState({ productos }, () => {
            this.setState({ mostrarProductos: true }, () => {
            });
        });
    }
    accionEjecutar = (registro) => {
        this.setState({
            graficoSpinner: true,
            tablaSpinner: true,
            mostrarTabla: false,
            mostrarGrafic: false
        });
        ReportesServicio.reporteEvolutivoCostoRentabilidadMensual(registro).then(resultado => {
            this.procesarArreglo(resultado.data);
        }, error => {
            NotificationManager.error('Error', "Ha ocurrido un error, intente nuevamente", 5000, () => {
                this.setState({
                    graficoSpinner: false,
                    tablaSpinner: false,
                    mostrarTabla: false,
                    mostrarGrafic: false
                });
            });
        });
    }
    procesarArreglo = (arregloBase) => {
        var resultado = [];
        var maestroDetalle = [];
        var maestroDetalle2 = [];
        var productos = arregloBase.forEach(registro => {
            const temporal = registro.itemReporteLista.map(producto => producto.identificador);
            resultado = resultado.concat(temporal);
        });
        const productosFiltrados = [...new Set(resultado)];
        const arregloVacio = productosFiltrados.map(registro => 0);
        const contenido = [];
        const cabecera = [];
        productosFiltrados.forEach(registro => {
            cabecera.push(this.obtenerNombreProducto(registro));
        }
        );
        var idFecha = 0;
        contenido.push(["Fecha"].concat(cabecera));
        var ultimaCabecera = [{ Header: "Productos", accessor: "producto" }];
        arregloBase.forEach(registro => {
            ultimaCabecera.push({ Header: registro.fecha, accessor: "key" + idFecha.toString() });
            var registroProcesado = []; registroProcesado.push(registro.fecha);
            var registroMaestro = {};
            registroMaestro.fecha = registro.fecha;
            var valores = arregloVacio;
            registro.itemReporteLista.forEach(lista => {
                var registroMaestro2 = {};
                if (typeof maestroDetalle2["key" + lista.identificador] !== "undefined") registroMaestro2 = maestroDetalle2["key" + lista.identificador];
                registroMaestro2.producto = this.obtenerNombreProducto(lista.identificador);
                registroMaestro2["key" + idFecha.toString()] = parseFloat(lista.valor).toFixed(2);
                valores[productosFiltrados.indexOf(lista.identificador)] = lista.valor;
                registroMaestro["key" + lista.identificador.toString()] = lista.valor;
                maestroDetalle2["key" + lista.identificador] = registroMaestro2;
            });

            idFecha = idFecha + 1;
            contenido.push(registroProcesado.concat(valores));
            maestroDetalle.push(registroMaestro);
        });
        this.setState({ datosGrafico: contenido, productosFiltrados, maestroDetalle, ultimaCabecera, maestroDetalle2: Object.values(maestroDetalle2) }, () => {
            this.setState({ mostrarGrafic: true, mostrarTabla: true, tablaSpinner: false, graficoSpinner: false });
        }
        );
    }
    obtenerNombreProducto = (codigo) => {
        var nombreProducto = "";
        this.state.productos.forEach(prd => {
            if (prd.code === codigo) nombreProducto = prd.name;
        });
        return nombreProducto;
    }
    obtenerCabecera = () => {
        var cabecera = [];
        cabecera.push({ title: "Fecha", field: "fecha" });
        this.state.productosFiltrados.forEach(producto => {
            var nombreProducto = "";
            this.state.productos.forEach(prd => {
                if (prd.code === producto) nombreProducto = prd.name;
            });
            cabecera.push({ title: nombreProducto, field: "key" + producto.toString() });
        });
        return cabecera;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.state.ultimaCabecera,//this.obtenerCabecera(),
            componente: 'Canal',
            obtenerInformacion: () => {
                return this.state.maestroDetalle2;
            },
            objetoValidacion: (objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "canal",
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }
    ensamblarImagenes=async(registro)=>{
        let input = window.document.getElementsByClassName(registro.identificador)[0];
        const canvas=await html2canvas(input);
        var img = canvas.toDataURL("image/png");
        return img;
    }
    exportarExcel=(parametros)=>{
        parametros.componente="Reporte Base de Prueba";
        parametros.nombreArchivo="reporte_base";
        const columnas=[
            { title: "Productos", field: "producto" },
            { title: "Cabecera Prueba1", field: "cabecera1" },
            { title: "Cabecera Prueba2", field: "cabecera2" }
        ]
        const  data=
            [
                { producto: "Productos", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos2", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos3", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos4", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos5", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos6", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos7", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos8", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos9", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos10", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos11", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos12", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos13", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos14", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos15", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos16", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos17", cabecera1: "1", cabecera2: "2"},
                { producto: "Productos18", cabecera1: "1", cabecera2: "2"},
                
            ];
        ExportacionExcel.descargarExcelReporte(parametros,columnas,data);
    }
    exportarPdf =async (parametros,registros) => {
        const pdf = new pdfConverter("l", "pt");
        const marginLeft = 20;
        var imgData = `${LOGO_BASE_64}`;
        pdf.addImage(imgData, 'JPEG', 40, 0, 190, 43);
        const elemento=(parametros.codigoElemento===1)?"Productos":"Servicios";
        let content = {
            bodyStyles: {lineWidth: 0},
            startY: 45,
            head: [['', '', '']],
            body: [
              ['Fecha Inicio: '+parametros.fechaInicio, 'Tipo de Elemento:'+elemento, 'Sweden'],
              ['Fecha Fin   : '+parametros.fechaFin, '', '']
            ],
            showHead: 'never',
            styles: {
                bodyStyles:{
                    fillColor:"#ffffff"
                }
            },
        };
        
        pdf.autoTable(content);

        var id=1;
        await Promise.all(
        registros.map(async registro=>{
          var img=await this.ensamblarImagenes(registro);
          pdf.addImage(
            img,
            "png",
            40,
            100,
            registro.width,//input.clientWidth,
            registro.height//input.clientHeight
            , 
            'imageId'+id.toString(), 
            'FAST'
          );
          id=id+1;
          //pdf.addPage();
        })
        );
        pdf.save("chart.pdf");
        
    };    
    render() {
        return (

            <React.Fragment>
                <div>
                    {this.state.mostrarProductos &&
                        <Menu productos={this.state.productos} accionEjecutar={this.accionEjecutar} 
                        exportarPdf={(parametros)=>{
                            const registros=[
                                {width:650, height:400, identificador:"superior"}
                            ];
                            this.exportarPdf(parametros,registros);
                        }} 
                        exportarExcel={(registros)=>{
                            this.exportarExcel(registros);
                        }}
                        />
                    }
                    <Grid container spacing={1} className="superior">
                        <Grid item xs={6}>
                            <Box height="40vh" width="100%">
                                <Panel header="Fecha" style={{ maxHeight: "100%", overflow: 'auto' }}>                                
                                        <div>
                                            {/*<TablaDinamica parametros={this.obtenerParametros()} />*/}
                                            <TablaReporte columns={
                                                [
                                                    { Header: "Productos", accessor: "producto" },
                                                    { Header: "Cabecera Prueba1", accessor: "cabecera1" },
                                                    { Header: "Cabecera Prueba2", accessor: "cabecera2" }
                                                ]
                                                } data={
                                                    [
                                                        { producto: "Productos", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos2", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos3", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos4", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos5", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos6", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos7", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos8", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos9", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos10", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos11", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos12", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos13", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos14", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos15", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos16", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos17", cabecera1: "1", cabecera2: "2"},
                                                        { producto: "Productos18", cabecera1: "1", cabecera2: "2"},
                                                        
                                                    ]
                                                } />
                                        </div>

                                </Panel>
                            </Box>
                        </Grid>
                        <Grid item xs={6}>
                            <Box height="40vh" width="100%">
                                <Panel header="Analisis de Costo por Producto" style={{ maxHeight: "100%", overflow: 'auto' }}>
                                   
                                    <Chart
                                        width={'100%'}
                                        height={'400px'}
                                        chartType="Bar"
                                        loader={<div>Loading Chart</div>}
                                        data={[
                                            ['Year', 'Sales', 'Expenses', 'Profit'],
                                            ['2014', 1000, 400, 200],
                                            ['2015', 1170, 460, 250],
                                            ['2016', 660, 1120, 300],
                                            ['2017', 1030, 540, 350],
                                        ]}
                                        options={{
                                            // Material design options
                                            chart: {
                                                title: 'Company Performance',
                                                subtitle: 'Sales, Expenses, and Profit: 2014-2017',
                                            },
                                        }}
                                        // For tests
                                        rootProps={{ 'data-testid': '2' }}
                                    />
                                </Panel>
                                
                            </Box>
                        </Grid>
                        <Grid item xs={12}>
                            <Box height="40vh" width="100%">
                            
                                <Panel header="Rentabilidad Mensual" style={{ maxHeight: "100%", overflow: 'auto' }}>
                                <div className="inferior">
                                    <Chart
                                        width={'100%'}
                                        height={'400px'}
                                        chartType="BarChart"
                                        loader={<div>Loading Chart</div>}
                                        data={[
                                            ['City', '2010 Population', '2000 Population'],
                                            ['New York City, NY', 8175000, 8008000],
                                            ['Los Angeles, CA', 3792000, 3694000],
                                            ['Chicago, IL', 2695000, 2896000],
                                            ['Houston, TX', 2099000, 1953000],
                                            ['Philadelphia, PA', 1526000, 1517000],
                                        ]}
                                        options={{
                                            title: 'Population of Largest U.S. Cities',
                                            chartArea: { width: '80%' },
                                            hAxis: {
                                                title: 'Total Population',
                                                minValue: 0,
                                            },
                                            vAxis: {
                                                title: 'City',
                                            },
                                        }}
                                        // For tests
                                        rootProps={{ 'data-testid': '1' }}
                                    />
                                    </div>
                                </Panel>

                                
                            </Box>
                        </Grid>
                    </Grid>
                </div>
            </React.Fragment>
        );
    };
}
export default Indicador1;