const defaultState={module:""};
function reducer(state= defaultState, {type, payload})
{
    switch(type){
        case 'updateModule':{
            return {
            ...state,
            module: payload
            }
        }
        default:
            return state;
    }
}

export default reducer;