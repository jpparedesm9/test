const defaultState={json:[]};
function reducer(state= defaultState, {type, payload})
{
    switch(type){
        case 'actualizarJson':{
            return {
            ...state,
            json: payload
            }
        }
        default:
            return state;
    }
}

export default reducer;