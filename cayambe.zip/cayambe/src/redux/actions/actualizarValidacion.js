export const ACTUALIZAR_VALIDACION_CORRECTO= 'actualizarValidacionCorrecto';
export const ACTUALIZAR_VALIDACION_INCORRECTO= 'actualizarValidacionIncorrecto';
function actualizarValidacionCorrecto(validacionCorrecto){
    return{
        type: ACTUALIZAR_VALIDACION_CORRECTO,
        payload: {validacionCorrecto},
    }
}
function actualizarValidacionIncorrecto(validacionIncorrecto){
    return{
        type:ACTUALIZAR_VALIDACION_INCORRECTO,
        payload: {validacionIncorrecto},
    }
}
//export default actualizarFecha;
export const actualizarValidacion = {
    actualizarValidacionCorrecto,
    actualizarValidacionIncorrecto,
  };