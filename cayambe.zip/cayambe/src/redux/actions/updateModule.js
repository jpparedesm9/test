export const type = 'updateModule';
const updateModule = (module) => ({
  type,
  payload: module,
});
export default updateModule;
