export const ACTUALIZAR_FECHA= 'actualizarFecha';
export const ACTUALIZAR_FECHA_ORIGEN= 'actualizarFechaOrigen';
function actualizarFecha(fecha){
    return{
        type: ACTUALIZAR_FECHA,
        payload: {fecha},
    }
}
function actualizarFechaOrigen(fechaOrigen){
    return{
        type:ACTUALIZAR_FECHA_ORIGEN,
        payload: {fechaOrigen},
    }
}
//export default actualizarFecha;
export const actualizar = {
    actualizarFecha,
    actualizarFechaOrigen,
  };