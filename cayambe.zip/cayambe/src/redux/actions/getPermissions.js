export const type = 'getPermissions';
const getPermissions = (permissions) => ({
  type,
  payload: permissions,
});
export default getPermissions;
