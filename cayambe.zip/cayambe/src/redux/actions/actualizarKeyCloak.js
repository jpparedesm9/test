export const type= 'actualizarKeyCloak';
const actualizarKeyCloak=(keyCloack)=>{
    return{
        type,
        payload: keyCloack,
    }
}
export default actualizarKeyCloak;