import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import InputBase from '@material-ui/core/InputBase';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import DirectionsIcon from '@material-ui/icons/Directions';
import Grid from '@material-ui/core/Grid';
import { Dropdown } from 'primereact/dropdown';


const useStyles = makeStyles((theme) => ({
    root: {
        padding: '2px 4px',
        display: 'flex',
        alignItems: 'center',
        width: 400,
    },
    input: {
        marginLeft: theme.spacing(1),
        flex: 1,
    },
    iconButton: {
        padding: 10,
    },
    divider: {
        height: 28,
        margin: 4,
    },
}));
const options = [
    { name: 'Predio', code: 'predio' },
    { name: 'Cédula', code: 'cedula' },
    { name: 'Clave Catastral', code: 'claveCatastral' }
];
export default function SearchPredio(props) {
    const classes = useStyles();
    const [predio,setPredio]= React.useState("");
    const [selectedOption,setOption]= React.useState(null);

    const optionChange=(e)=>{
        setOption(e.value);
    }
    return (
        <React.Fragment>
<div style={{ display: 'inline-flex' }}>
<div style={{marginTop:"auto", marginBottom:"auto"}}>
Datos Cliente: (*) &nbsp; &nbsp;
</div>
<div>
                <Paper component="form" className={classes.root}>
                        <InputBase
                            className={classes.input}
                            placeholder="Ingrese número"
                            inputProps={{ 'aria-label': 'Ingrese número'}}
                            value={predio}
                            onChange={(e)=>{
                                setPredio(e.target.value);
                            }}
                        />
                        <Dropdown value={selectedOption} options={options} onChange={optionChange} optionLabel="name" placeholder="Buscar por:" />
                        <IconButton className={classes.iconButton} aria-label="buscar" onClick={()=>{props.searchAction(predio,(selectedOption!==null)?selectedOption.code:"");}}>
                            <SearchIcon />
                        </IconButton>
                        
                    </Paper>
                    
</div>
<div style={{marginTop:"auto", marginBottom:"auto"}}>

</div>
</div>
           
        </React.Fragment>
    );
}