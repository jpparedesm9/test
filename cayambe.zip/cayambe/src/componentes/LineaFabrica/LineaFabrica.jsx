import React,{Component} from 'react';
import "./generalStyle.css";
import SearchPredio from './SearchPredio';
import Predio from './Finder/Predio';
import BusquedaCedula from './Finder/BusquedaCedula';
import BusquedaCatastral from './Finder/BusquedaCatastral';

class LineaFabrica extends Component{
    constructor(props){
        super(props);
        this.state={
            userData:[],
            showInfo:false,
            id:null,
            option:"default",
            valor:null,
            renderInterface:false
        }
    }
    componentDidMount=()=>{

       
    }
    processPredio=(predio)=>{
        this.setState({showInfo:false,id:predio},()=>{
            this.setState({showInfo:true});
        });
    }
    searchAction=(valor,option)=>{
        this.setState({valor,option,renderInterface:false},()=>{
            this.setState({renderInterface:true});
        }); 
    }
    renderResult=(option)=>{
        switch(option){
            case "predio":{
                return <Predio id={this.state.valor} />
            break;
            }
            case "default":{
                return <div></div>
            break;
            }
            case "cedula":{
                return <BusquedaCedula id={this.state.valor} searchAction={this.searchAction} type={1}/>
                break;
            }
            case "claveCatastral":{
                return <BusquedaCedula id={this.state.valor} searchAction={this.searchAction} type={2}/>
                //return <BusquedaCatastral id={this.state.valor} searchAction={this.searchAction} type={2}/>
                break;
            }
            default: break;
        }
    }
    render(){
        return(
        <React.Fragment>
        <SearchPredio searchAction={this.searchAction}/>
        {this.state.renderInterface&&
        <div>
        {this.renderResult(this.state.option)}
        </div>
        } 
        </React.Fragment>
        );
    }
}
export default LineaFabrica;