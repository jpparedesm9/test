import React, { useEffect } from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import FinanwareLogo from '../../recursos/logo.png';
import {Link} from 'react-router-dom';
import DynamicLateralMenu from '../menus/MenuLateral';
import BreadCrumb from '../../global/BreadCrumb';
import { useHistory } from "react-router";
import { connect } from "react-redux";
import PerfilUsuario from "../submodulos/comun/PerfilUsuario";
const drawerWidth = 300;


const useStyles = makeStyles(theme => ({
  button: {
    width: 8 * theme.spacing.unit,
    height: 8 * theme.spacing.unit,
    color: theme.palette.primary.main,
    "&$buttonDisabled": {
        color: theme.palette.grey[900]
    }},
  listItem: {
    "&$selected, &$selected:hover, &$selected:focus": {
      backgroundColor: "#43beac",
      color: "#ffffff"
    }
  },
  selected: {},
  customBar:{
    flexGrow: 1,
    boxShadow: "none",
    backgroundColor: "#ffffff",
    color: "#3c4248"
  },
  title: {
    flexGrow: 1,
  },
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: theme.spacing(2)
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    backgroundColor: "#939597",

    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    backgroundColor: "#939597",
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(2),
  },
}));

function MainDrawer(props) {
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);
  let history = useHistory();
  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };
  useEffect(() => {
    
    if (props.module_name.length<=0)
    {
      history.push("/");
    }
  
  }, []);
  return (
    
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        }, classes.customBar)}
      >
        <Toolbar style={{backgroundColor:"#939597", color:"#ffffff"}}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open,
            })}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap>
             <BreadCrumb componente={props.breadcrumb2} modulo={props.module_name}/>
          </Typography>
          <Typography variant="h6" className={classes.title}>
          </Typography>
          <div>
              <PerfilUsuario color={"#ffffff"}/>
            </div>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
        key="mi_contenedor"
        style={{backgroundColor:"#ffffff"}} 
      >
        <div className={classes.toolbar} style={{backgroundColor:"#ffffff"}}>
          <Typography variant="h6" noWrap>
            <Link to="/">
            <img src={FinanwareLogo} alt="Home Page" width="200px" />
            </Link>
          </Typography>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </div>
        <Divider />
        <DynamicLateralMenu key="menulateraldinamico" />  
      </Drawer>
      <main className={classes.content}>
        <div className={classes.toolbar} />
        
        {props.holder}
      </main>
    </div>
  );
}
const mapStateToProps = state => ({
  breadcrumb2: state.breadcrumb.breadcrumb
});
export default connect(mapStateToProps)(MainDrawer);
