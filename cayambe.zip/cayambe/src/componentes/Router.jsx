import React, { Component } from 'react';
import { BrowserRouter, Route, Switch} from 'react-router-dom';
import ModuleTemplate from './modulos/ModuleTemplate';
import Map from './Charts/Map';
import Home from './Home';
import ConsultaDeuda from './ConsultaDeuda/ConsultaDeuda';
import LineaFabrica from './LineaFabrica/LineaFabrica';
 
class Router extends Component {
    render() {
        return (
            <BrowserRouter>
                <Switch>
                    <ModuleTemplate>
                        <Route component={({ match }) =>
                            <div>
                                <Route path='/' exact component={Home} />
                                <Route path='/mapa' exact component={Map} />
                                <Route path='/consulta_deuda' exact component={ConsultaDeuda} />
                                <Route path='/linea_fabrica' exact component={LineaFabrica} />
                            </div>
                        } />
                    </ModuleTemplate>
                </Switch>
            </BrowserRouter>
        );
    }

}
export default Router;
