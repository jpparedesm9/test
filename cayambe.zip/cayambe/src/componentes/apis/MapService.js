import axios from 'axios';
class MapService{
    /*************************BATCH PIT **************************************/
    obtenerListaFuente=()=>{
        return axios.get(`http://181.39.104.154/catastro/rest/v1.0/consultas/listaFuente`);
    }
    
    /*********************FIN BATCH PIT **************************************/

}
export default new MapService();

