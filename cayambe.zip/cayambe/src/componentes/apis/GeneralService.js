import axios from 'axios';
class GeneralService{
    /*************************BATCH PIT **************************************/
    getDebts=(id)=>{
        return axios.get(`http://181.39.104.154/cajaunica/rest/caja/recaudacion/${id}`);
    }
    obtenerPredio=(id)=>{
      return axios.get(`http://181.39.104.154/planificacionTerritorial/rest/irc/predio/${id}`);
    }
    busquedaCedula=(cedula)=>{
      return axios.get(`http://181.39.104.154/planificacionTerritorial/rest/irc/cedula/${cedula}`);
    }
    busquedaCatastral=(catastro)=>{
      return axios.get(`http://181.39.104.154/planificacionTerritorial/rest/irc/claveCatastral/${catastro}`);
    }
    
    
    /*********************FIN BATCH PIT **************************************/

}
export default new GeneralService();

