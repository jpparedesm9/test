package com.formos.test;

import java.util.HashMap;
import java.util.Map;

public class MainMenu {
	public static void main(String[] args) {
		
		Map<String, Ingredient> inventory = new HashMap<String, Ingredient>();
		inventory.put("Strawberry",new Ingredient("Strawberry",20.0,Measure.g));
		inventory.put("Banana",new Ingredient("Banana",20.0,Measure.g));
		inventory.put("Mango",new Ingredient("Mango",20.0,Measure.g));
		inventory.put("Condensed Milk",new Ingredient("Condensed Milk",20.0,Measure.g));
		inventory.put("Sugar",new Ingredient("Sugar",20.0,Measure.g));
		inventory.put("Ice",new Ingredient("Ice",20.0,Measure.g));
		
		 //System.out.println(inventory.get("Strawberry").getName()); 
		
		int swValue;
	    System.out.println("|          MAIN MENU       |");
	    System.out.println("| Options:                 |");
	    System.out.println("|      1. Inventory        |");
	    System.out.println("|      2. Sell a Drink     |");
	    System.out.println("|      3. Exit             |");
	    swValue = Validator.inInt(" Select option: ");

	    // Switch construct
	    switch (swValue) {
	    case 1:
	      System.out.println("Option 1 selected");
	      break;
	    case 2:
	      System.out.println("Option 2 selected");
	      break;
	    case 3:
	      System.out.println("Exit selected");
	      break;
	    default:
	      System.out.println("Invalid selection");
	      break; // This break is not really necessary
	    }
	}
}

