package com.formos.test;


public class Ingredient {
	String name="";
	Double quantity=0.0; 
	Measure unitMeasure;
	Ingredient(String name_p, Double quantity_p, Measure unitMeasure_p){
		setName(name_p);
		setQuantity(quantity_p);
		setUnitMeasure(unitMeasure_p);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Measure getUnitMeasure() {
		return unitMeasure;
	}

	public void setUnitMeasure(Measure unitMeasure) {
		this.unitMeasure = unitMeasure;
	}

}
