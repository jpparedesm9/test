import React, { Component } from 'react';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
//import '../../../../recursos/Style.css';
import { connect } from 'react-redux';
import { Toolbar } from 'primereact/toolbar';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { MultiSelect } from 'primereact/multiselect';
//import './MultiSelectDemo.scss';
import BimServicio from '../../../../../api/BimServicio';
import moment from "moment";
import {SplitButton} from 'primereact/splitbutton';

class MenuBarComponent extends Component {

    constructor(props) {
        super(props);
        let itemsIniciales = [
            {
                label: 'Actualizar',
                icon: 'pi pi-fw pi-refresh',
                command: () => {
                    //this.props.nuevoRegistroAccion();
                }
            },
            {
                label: 'Exportar',
                icon: 'pi pi-fw pi-upload',
                items: [
                    {
                        label: 'Excel',
                        icon: 'pi pi-fw pi-file-excel',
                        command: () => {
                            //this.props.excelExportAction();
                        }
                    },
                    {
                        label: 'Pdf',
                        icon: 'pi pi-fw pi-file-pdf',
                        command: () => {
                            //this.props.pdfExportAction();
                        }
                    },
                ]
            },
            {
                label: 'Ejecutar',
                icon: 'pi pi-fw pi-cog',
                items: [
                    {
                        label: 'Excel',
                        icon: 'pi pi-fw pi-file-excel',
                        command: () => {
                            ///this.props.excelExportAction();
                        }
                    },
                ]
            }
        ];

        this.state = {
            productosSeleccionados: null,
            serviciosSeleccionados: null,
            oficinasSeleccionadas:null,
            oficinas:[],
            areasSeleccionadas:null,
            areas:[],
            fechaPivotSeleccionada: null,
            items: itemsIniciales,
            fechaInicio: null,
            fechaFin: null,
            elementoSeleccionado: null,
            codigoElemento:null,
            productos:props.productos,
            servicios:props.servicios,
            ejecutar:[
                {
                    label:'Resumen',
                    command: () => {
                      // this.props.exportarExcelExtraccion(); 
                    }
                },
                {
                    label:'Detalle',
                    command: () => {
                        //this.props.exportarExcelDetalle();
                    }
                },
             ]
        };
        this.elementos = [
            { name: 'Producto', code: '1' },
            { name: 'Servicio', code: '2' }
        ];

        const listaPuntosAtencionPromise=BimServicio.ObtenerRegistrosOficina();
        listaPuntosAtencionPromise.then(registro=>{
            var oficinas=[];
            registro.data.forEach(registro=>{
                oficinas.push({name:registro.nombre, code:registro.codigo});
            }
            );
            this.setState({oficinas});
        });

        const areasPromise=BimServicio.ObtenerRegistrosArea();
        areasPromise.then(registro=>{
            var areas=[];
            registro.data.forEach(registro=>{
                areas.push({name:registro.nombre, code:registro.codigo});
            }
            );
            this.setState({areas});
        });
        this.items = [
            {
                label: 'Excel',
                icon: 'pi pi-file-excel',
                command: () => {
                    alert("Excel");
                }
            },
            {
                label: 'Pdf',
                icon: 'pi pi-file-pdf',
                command: () => {
                    alert("pdf");
                }
            }
        ];

        this.save = this.save.bind(this);

    }
    validarEliminacionComponente(breadcrumb){
        var activo=false;
        switch(breadcrumb){
            case "operaciones":
            case "valorFrenCarga":
            case "factorRentabilidad":{
                activo=true;
                break;
            }
            default:break;
        }
        return activo;
    }
    cambioFechaPivot = (e) => {
        this.setState({
            fechaPivotSeleccionada: e.target.value
        }, () => {
        });
    };
    procesarEjecucion=()=>{
        const productosSeleccionados=(this.state.productosSeleccionados!==null)?this.state.productosSeleccionados.map(registro=>registro.code):[];
        const oficinaLista=(this.state.oficinasSeleccionadas!==null)?this.state.oficinasSeleccionadas.map(registro=>registro.code):[];
        const areasLista=(this.state.areasSeleccionadas!==null)?this.state.areasSeleccionadas.map(registro=>registro.code):[];
        const fechaInicio=moment(new Date(this.state.fechaInicio)).format("YYYYMMDD");
        const fechaFin=moment(new Date(this.state.fechaFin)).format("YYYYMMDD");
        var registro={
            "indice": "RENTABILIDAD",
            "fechaInicio": fechaInicio,
            "fechaFin": fechaFin,
            "idConceptoLista": productosSeleccionados,
            "idOficinaLista": oficinaLista,
            "idAreaLista": areasLista
        };
        this.props.accionEjecutar(registro);
    }
    cambioElemento=(e)=>{
        this.setState({ elementoSeleccionado: e.value, codigoElemento:parseInt(e.value.code)});
    }
    save() {
    }
    render() {


        return (
            <React.Fragment>
                <Toolbar style={{backgroundColor:'white'}} style={{ textAlign: 'left' }}>
                    <div className="p-toolbar-group-left">
                            <Button label="Fecha Inicio:" icon="pi pi-calendar" className="p-button-secondary" 
                            style={{borderColor:'white', backgroundColor:'white'}}></Button>
                            <Calendar dateFormat="yy/mm/dd" value={this.state.fechaInicio} onChange={(e) => {
                                this.setState({ fechaInicio: e.value });
                               // this.props.setFecha(e.value);
                                }
                                }/>
                            <Button label="Fecha Fin:" icon="pi pi-calendar" className="p-button-secondary" 
                            style={{borderColor:'white', backgroundColor:'white'}}></Button>
                            <Calendar dateFormat="yy/mm/dd" value={this.state.fechaFin} onChange={(e) => {
                                this.setState({ fechaFin: e.value });
                               // this.props.setFecha(e.value);
                                }
                                }/>
                                &nbsp;&nbsp;Tipo de Elemento:&nbsp;&nbsp;
                        <Dropdown value={this.state.elementoSeleccionado} options={this.elementos} onChange={this.cambioElemento} optionLabel="name" placeholder="Seleccione un elemento" />
                        &nbsp; &nbsp;
                        <SplitButton label="Exportar" icon="pi pi-download" onClick={this.save} model={this.items} className="p-button-secondary" style={{borderColor:'white', backgroundColor:'white'}}></SplitButton>
                        &nbsp; &nbsp;
                    <Button label="Ejecutar" icon="pi pi-cog" onClick={()=>{
                                this.procesarEjecucion();
                            }} className="p-button-secondary" 
                        style={{borderColor:'white', backgroundColor:'white'}}></Button>

                    </div>
                </Toolbar>
                <Toolbar style={{backgroundColor:'white'}} style={{ textAlign: 'left' }}>
                <div className="multiselect-demo">
                    <div className="p-toolbar-group-left">
                    {(this.state.codigoElemento===1)&&
                    <MultiSelect value={this.state.productosSeleccionados} options={this.state.productos} onChange={(e) => this.setState({ productosSeleccionados: e.value })} 
                    optionLabel="name" placeholder="Seleccione un producto" />
                    }
                    {(this.state.codigoElemento===2)&&
                    <MultiSelect value={this.state.serviciosSeleccionados} options={this.state.servicios} onChange={(e) => this.setState({ serviciosSeleccionados: e.value })} 
                    optionLabel="name" placeholder="Seleccione un servicio" />
                    }
                    &nbsp; &nbsp;
                    <MultiSelect value={this.state.oficinasSeleccionadas} options={this.state.oficinas} onChange={(e) => this.setState({ oficinasSeleccionadas: e.value })} 
                    optionLabel="name" placeholder="Seleccione Oficinas" />
                    &nbsp; &nbsp;
                    <MultiSelect value={this.state.areasSeleccionadas} options={this.state.areas} onChange={(e) => this.setState({ areasSeleccionadas: e.value })} 
                    optionLabel="name" placeholder="Seleccione Areas" />


                    </div>
                    </div>
                </Toolbar>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        validacionCorrecto: state.validacion.validacionCorrecto,
        validacionIncorrecto: state.validacion.validacionIncorrecto,
        breadcrumb: state.breadcrumb
    };
}

export default connect(mapStateToProps)(MenuBarComponent);