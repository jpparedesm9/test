import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "./menus/Menu";
import SubMenu from "./menus/SubMenu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import TablaDinamica from './TablaDinamica';
import ReportesServicio from '../../../../api/ReportesServicio';
import spinner from "../../../../recursos/spinner.gif";
import { NotificationManager } from 'react-notifications';
import Box from '@material-ui/core/Box';
import TablaReporte from "./TablaReporte";

class Indicador1 extends Component {
    constructor(props) {
        super(props);
        this.state={
            cabecera:[],
            mostrarGrafic:false,
            mostrarTabla:false,
            graficoSpinner:false,
            tablaSpinner:false,
            ultimaCabecera:[],
            maestroDetalle2:[],
            datosGrafico:[],//this.procesarArreglo(info),,
            productos:[],
            servicios:[],
            productosFiltrados:[],
            maestroDetalle:[],
            mostrarProductos:false,
            mostrarServicios:false
        };
    }
    componentDidMount(){
        var productos=[];
        var servicios=[];
        const codigoProductos="codigosTiposConceptos=1&codigosTiposConceptos=2&codigosTiposConceptos=5";
        const productosPromise=ReportesServicio.obtenerNombreConceptos(codigoProductos);
        productosPromise.then(resultado=>{
            if(typeof resultado.data!=="undefined")
            resultado.data.forEach(registro=>{
                productos.push({name:registro.nombre, code:registro.codigo});
            });
            this.setState({productos},()=>{
                this.setState({mostrarProductos:true},()=>{
                });
            });

        });
        const codigoServicios="codigosTiposConceptos=4";
        const serviciosPromise=ReportesServicio.obtenerNombreConceptos(codigoServicios);
        serviciosPromise.then(resultado=>{
            if(typeof resultado.data!=="undefined")
            resultado.data.forEach(registro=>{
                servicios.push({name:registro.nombre, code:registro.codigo});
            });
            this.setState({servicios},()=>{
                this.setState({mostrarServicios:true},()=>{
                });
            });
        });
        

    }
    accionEjecutar=(registro)=>{
        this.setState({
            graficoSpinner:true,
            tablaSpinner:true,
            mostrarTabla:false,
            mostrarGrafic:false
        });
        ReportesServicio.reporteEvolutivoCostoRentabilidadMensual(registro).then(resultado=>
        {   
            this.procesarArreglo(resultado.data);
        },error=>{
            NotificationManager.error('Error', "Ha ocurrido un error, intente nuevamente", 5000, () => {
                this.setState({
                    graficoSpinner:false,
                    tablaSpinner:false,
                    mostrarTabla:false,
                    mostrarGrafic:false
                });
            });
        });
    }
    procesarArreglo=(arregloBase)=>{
        var resultado=[];
        var maestroDetalle=[];
        var maestroDetalle2=[];
        var productos=arregloBase.forEach(registro=>{
        const temporal=registro.itemReporteLista.map(producto=>producto.identificador);
        resultado=resultado.concat(temporal);
        });
        const productosFiltrados=[...new Set(resultado)];
        const arregloVacio=productosFiltrados.map(registro=>0);
        const contenido=[];
        const cabecera=[];
        productosFiltrados.forEach(registro=>{
            cabecera.push(this.obtenerNombreProducto(registro));
        }  
        );
        var idFecha=0;
        contenido.push(["Fecha"].concat(cabecera));
        var ultimaCabecera=[{Header:"Productos",accessor:"producto"}];
        arregloBase.forEach(registro=>{
        ultimaCabecera.push({Header:registro.fecha, accessor:"key"+idFecha.toString()});
        var registroProcesado=[]; registroProcesado.push(registro.fecha);
        var registroMaestro={};
        registroMaestro.fecha=registro.fecha;
        var valores=arregloVacio;
        registro.itemReporteLista.forEach(lista=>{
            var registroMaestro2={};
            if(typeof maestroDetalle2["key"+lista.identificador]!=="undefined")registroMaestro2=maestroDetalle2["key"+lista.identificador];
            registroMaestro2.producto=this.obtenerNombreProducto(lista.identificador);
            registroMaestro2["key"+idFecha.toString()]=parseFloat(lista.valor).toFixed(2);
        valores[productosFiltrados.indexOf(lista.identificador)]=lista.valor;
        registroMaestro["key"+lista.identificador.toString()]=lista.valor;
        maestroDetalle2["key"+lista.identificador]=registroMaestro2;
        });
        
        idFecha=idFecha+1;
        contenido.push(registroProcesado.concat(valores));
        maestroDetalle.push(registroMaestro);
        });
        this.setState({datosGrafico:contenido,productosFiltrados,maestroDetalle,ultimaCabecera,maestroDetalle2:Object.values(maestroDetalle2)},()=>{
            this.setState({mostrarGrafic:true,mostrarTabla:true,tablaSpinner:false,graficoSpinner:false});
        }
        );
    }
    obtenerNombreProducto=(codigo)=>{
        var nombreProducto="";
        this.state.productos.forEach(prd=>{
            if(prd.code===codigo)nombreProducto=prd.name;
        });
        return nombreProducto;
    }
    obtenerCabecera = () => {
        var cabecera=[];
        cabecera.push({title:"Fecha", field:"fecha"});
        this.state.productosFiltrados.forEach(producto=>{
            var nombreProducto="";
            this.state.productos.forEach(prd=>{
                if(prd.code===producto)nombreProducto=prd.name;
            });
            cabecera.push({title:nombreProducto, field:"key"+producto.toString()});
        });
        return cabecera;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.state.ultimaCabecera,//this.obtenerCabecera(),
            componente: 'Canal',
            obtenerInformacion: () => {
                return this.state.maestroDetalle2;
            },
            objetoValidacion: (objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "canal",
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }
    render() {
        return (
            
            <React.Fragment>
                
            <div>
                {(this.state.mostrarProductos&&this.state.mostrarServicios)&&
                <Menu productos={this.state.productos} servicios={this.state.servicios} accionEjecutar={this.accionEjecutar}/>
                }
                <Grid container spacing={1}>
                
                    <Grid item xs={12}>
                    <Box height="40vh" width="100%">
                        <Panel header="Espacio para Datos" style={{maxHeight: "100%", overflow: 'auto'}}>
                        
                            {this.state.tablaSpinner&&<img src={spinner} width="40px" />}
                            {this.state.mostrarTabla&&
                                <div>
                                {/*<TablaDinamica parametros={this.obtenerParametros()} />*/}
                                <TablaReporte columns={this.state.ultimaCabecera} data={this.state.maestroDetalle2}/>
                                </div>
                            }
                       
                        </Panel>
                        </Box>
                    </Grid>
                    <Grid item xs={12}>
                    <Box height="40vh" width="100%">
                        <Panel header="Gráfico" style={{maxHeight: "100%", overflow: 'auto'}}>
                        {this.state.graficoSpinner&&<img src={spinner} width="40px" />}
                        {this.state.mostrarGrafic&&
                            <Chart
                                width={'100%'}
                                height={'30vh'}
                                chartType="AreaChart"
                                loader={<div>Cargando Información</div>}
                                data={this.state.datosGrafico}
                                options={{
                                    title: 'RENTABILIDAD',
                                    hAxis: { title: 'Fecha', titleTextStyle: { color: '#333' } },
                                    vAxis: { minValue: 0 },
                                    // For the legend to fit, we make the chart area smaller
                                    chartArea: { width: '80%'},
                                    // lineWidth: 25
                                }}
                                // For tests
                                rootProps={{ 'data-testid': '1' }}
                            />
                            }
                        </Panel>
                        </Box>
                    </Grid>
                </Grid>
                </div>
            </React.Fragment>
        );
    };
}
export default Indicador1;