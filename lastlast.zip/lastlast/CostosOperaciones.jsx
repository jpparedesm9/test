import React, { Component, createRef } from 'react';
import TablaDinamica from '../../../submodulos/comun/TablaDinamica/TablaDinamica';
import Grid from '@material-ui/core/Grid';
import {Panel} from 'primereact/panel';
import {connect} from 'react-redux';
import BatchServicio from '../../../../api/BatchServicio';
import MenuBarBatchComponent from './comun/MenuBarBatchComponent';
import { NotificationManager } from 'react-notifications';

class CostosOperaciones extends Component {
    constructor(props){
        super(props);
        this.subdetalleRef=new createRef();
        this.state={
           treeData:[],
           selectedNodeKey:null,
           mostrarOperaciones:false,
           operaciones:[],
           mostrarSubdetalle:false,
           subdetalleCabecera:[],
           contenidoSubdetalle:[],
           detalle:[],
           detalleCabecera:[],
           mostrarDetalle:false,
           activarSubDetalle:false,
           fecha:null
        };
    }

    obtenerObjetoValidacion = () => {
        return [];
    }
    obtenerParametros=()=>
    {
        const parametros={
            cabecera:this.state.subdetalleCabecera,
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{return this.state.contenidoSubdetalle;},
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false
        };
        return parametros;
    }
    obtenerCabeceraDetalle= () => {
        const cabecera = [
            { title: 'Fecha Pivot', field: 'codigo' }
        ];

        return cabecera;
    }
    obtenerCostoDetalle
    ObtenerParametrosDetalle=()=>{
        const parametros={
            cabecera:this.obtenerCabeceraDetalle(),
            componente:'ComponenteDinamico',
            obtenerInformacion:BatchServicio.obtenerFechasCostos,
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false,
            paging:false,
            clickFila: (evt, selectedRow) => {
                const fecha=selectedRow.codigo.replace(/-/g,"");
                this.setState({fecha,activarSubDetalle:true},()=>{
                    this.subdetalleRef.current.refrescar();
                });
            },
        };
        return parametros;      
    }

    ejecutar=()=>{
        BatchServicio.ejecutarBatchCosto().then(resultado=>{
            NotificationManager.success(`Proceso Ejecutado`);
        },error=>{
            NotificationManager.error('Error', "Fallo en la ejecución", 5000, () => {});
        });
    }
    actualizar=()=>{
        if (this.state.feca!==null){
        BatchServicio.actualizarBatchCosto(this.state.fecha).then(resultado=>{
            NotificationManager.success(`Actualización Correcta`);
            this.subdetalleRef.current.refrescar();
            
        },error=>{
            NotificationManager.error('Error', "Actualización Fallida", 5000, () => {});
        });
    }
    }
    obtenerCabeceraSubDetalle= () => {
        const cabecera = [
            { title: 'Código', field: 'codigo' },
            { title: 'Descripción', field: 'descripcion' },
            { title: 'Duración (Seg)', field: 'duracion' },
            { title: 'Mensaje', field: 'mensaje' },
        ];

        return cabecera;
    }
    ObtenerParametrosSubDetalle=()=>{
        const parametros={
            cabecera:this.obtenerCabeceraSubDetalle(),
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{return BatchServicio.obtenerCostoDetalle(this.state.fecha);},
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false,
            paging:false
        };
        return parametros;      
    }
    shouldComponentUpdate(nextProps, nextState)
    {
        if(this.props.breadcrumb.breadcrumb!==nextProps.breadcrumb.breadcrumb)
        {
            this.setState(
                {
                    activarSubdetalle:false,
                    mostrarDetalle:false
                },()=>{
                    this.iniciarOperaciones(this.obtenerCodigoComponente(nextProps.breadcrumb.breadcrumb)); 
                }
            );
        }
        return true;
    }
    render() {
        return (
            <React.Fragment>
                <MenuBarBatchComponent ejecutar={this.ejecutar} actualizar={this.actualizar}/>
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        <Panel header={this.props.breadcrumb.breadcrumb} style={{height:'50%'}}>
                            {this.state.mostrarDetalle&&
                            <TablaDinamica parametros={this.ObtenerParametrosDetalle()}/>
                            }
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        </Panel>
                        
                        <Panel header={"Procesos ejecutados:"+this.state.fecha} style={{height: '100px'}}>
                        {this.state.activarSubDetalle&&
                            <TablaDinamica ref={this.subdetalleRef} parametros={this.ObtenerParametrosSubDetalle()}/>
                        }
                        </Panel>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        breadcrumb: state.breadcrumb
     };
}

const mapDispatchToProps = {
}


export default connect(mapStateToProps, mapDispatchToProps)(CostosOperaciones);