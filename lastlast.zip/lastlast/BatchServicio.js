import axios from 'axios';
import { JPA_API_URL } from '../../Constantes';

class BatchServicio {
    /*********************BATCH COSTOS **************************************/
    obtenerFechasCostos=()=>{
        return axios.get(`${JPA_API_URL}/costos/fechaPresupuestada/lista`);
    }
    obtenerCostoDetalle=(fecha)=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchCosto/listaCombinaCostoDetalle/${fecha}`);
    }
    ejecutarBatchCosto=()=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchCosto/ejecutarBatchCosto`);
    }
    actualizarBatchCosto=(fecha)=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchCosto/actualizarBatchCosto/${fecha}`);
    }
    /*****************Fin Operaciones ************************************/
}
export default new BatchServicio();

