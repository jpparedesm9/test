import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import FolderOpenIcon from '@material-ui/icons/FolderOpen';
import { Link } from 'react-router-dom';
import '../../../recursos/Style.css';
import MultilineChartIcon from '@material-ui/icons/MultilineChart';
import { useDispatch } from "react-redux";
import actualizarBreadCrumb from '../../../../redux/actions/actualizarBreadCrumb';

export default function Reportes() {

  const [open, setOpen] = React.useState(false);
  const dispatch = useDispatch();
  const handleClick = () => {
    setOpen(!open);
  };
  function actualizarOperacion(nombre){
    dispatch(actualizarBreadCrumb(nombre));
  }
  return (
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      key="distribucion_a_producto_key"
      className="lateral_menu"
    >
      <ListItem button onClick={handleClick} selected={open}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Procesos Batch" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding key="factores_rentabilidad">
          <Link to="/submenu/batch/procesos/costosOperaciones" className="lateral_menu">
          <ListItem button onClick={()=>{actualizarOperacion("Costos");}}>
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Costos" />
          </ListItem>
          </Link>
          <Link to="/submenu/reportes/indicador1" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Rentabilidad" />
          </ListItem>
          </Link>

        </List>
      </Collapse>

      <ListItem button onClick={handleClick} selected={open}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Reportes" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding key="factores_rentabilidad">
          <Link to="/submenu/reportes/indicador1" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Costos" />
          </ListItem>
          </Link>
          <Link to="/submenu/reportes/indicador1" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="Rentabilidad" />
          </ListItem>
          </Link>
          <Link to="/submenu/reportes/indicador1" className="lateral_menu">
          <ListItem button >
            <ListItemIcon>
              <MultilineChartIcon style={{ color:'#ffffff' }} />
            </ListItemIcon>
            <ListItemText primary="PIT" />
          </ListItem>
          </Link>

        </List>
      </Collapse>
    </List>
  );
}
