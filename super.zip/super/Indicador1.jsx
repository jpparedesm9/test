import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "./menus/Menu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import TablaDinamica from './TablaDinamica';

class Indicador1 extends Component {
    constructor(props) {
        super(props);
    }
    obtenerCabecera = () => {
        const cabecera = [
            { title: "Nombre", field: 'nombre' },
            { title: "Descripción", field: 'descripcion' },    
        ];

        return cabecera;
    }
    obtenerParametros=()=>{
        const parametros={
        cabecera:this.obtenerCabecera(),
        componente:'Canal',
        //nuevoRegistro:(registro) => { return BimCrud.RegistrarCanal(registro) },
        //editarRegistro:(registroanterior, registro) => { return BimCrud.ActualizarCanal(registro) },
        //eliminarRegistro:(registro) => { return BimCrud.EliminarCanal(registro) },
        obtenerInformacion:()=>{
            return [
                {nombre:"Dato de prueba 1",descripcion:"Descripción 1"},
                {nombre:"Dato de prueba 1",descripcion:"Descripción 1"},
                {nombre:"Dato de prueba 1",descripcion:"Descripción 1"},
            ];
        },
        objetoValidacion:(objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
        excluirFunciones:["Copiar","Importar"],
        nombreArchivo:"canal",
        botonesEdicion:{editar:false,eliminar:false},
        activarToolBar:false
        };
        return parametros;
    }
    render() {
        return (
            <React.Fragment>
                <Menu />
                <Grid container spacing={1}>
                    <Grid item xs={6}>
                        <Panel header="Espacio para Datos">
                            <TablaDinamica parametros={this.obtenerParametros()}/>

                        </Panel>
                    </Grid>
                    <Grid item xs={6}>
                        <Panel header="Gráfico">
                            <Chart
                                width={'500px'}
                                height={'300px'}
                                chartType="PieChart"
                                loader={<div>Cargando gráfico</div>}
                                data={[
                                    ['Task', 'Hours per Day'],
                                    ['Work', 11],
                                    ['Eat', 2],
                                    ['Commute', 2],
                                    ['Watch TV', 2],
                                    ['Sleep', 7],
                                ]}
                                options={{
                                    title: 'My Daily Activities',
                                    // Just add this option
                                    is3D: true,
                                }}
                                rootProps={{ 'data-testid': '2' }}
                            />
                        </Panel>
                    </Grid>
                </Grid>

            </React.Fragment>
        );
    };
}
export default Indicador1;