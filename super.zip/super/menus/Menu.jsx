import React, { Component } from 'react';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
//import '../../../../recursos/Style.css';
import { connect } from 'react-redux';
import { Toolbar } from 'primereact/toolbar';
import { Button } from 'primereact/button';
import {TieredMenu} from 'primereact/tieredmenu';
import { Calendar } from 'primereact/calendar';

class MenuBarComponent extends Component {

    constructor(props) {
        super(props);
        let itemsIniciales = [
            {
                label: 'Actualizar',
                icon: 'pi pi-fw pi-refresh',
                command: () => {
                    //this.props.nuevoRegistroAccion();
                }
            },
            {
                label: 'Ejecutar',
                icon: 'pi pi-fw pi-cog',
                items: [
                    {
                        label: 'Excel',
                        icon: 'pi pi-fw pi-file-excel',
                        command: () => {
                            ///this.props.excelExportAction();
                        }
                    },
                ]
            }
        ];

        this.state = {
            fechaPivotSeleccionada: null,
            items: itemsIniciales,
            date3: null,
            ejecutar:[
                {
                    label:'Resumen',
                    command: () => {
                      // this.props.exportarExcelExtraccion(); 
                    }
                },
                {
                    label:'Detalle',
                    command: () => {
                        //this.props.exportarExcelDetalle();
                    }
                },
             ]
        };
    }
    validarEliminacionComponente(breadcrumb){
        var activo=false;
        switch(breadcrumb){
            case "operaciones":
            case "valorFrenCarga":
            case "factorRentabilidad":{
                activo=true;
                break;
            }
            default:break;
        }
        return activo;
    }
    cambioFechaPivot = (e) => {
        this.setState({
            fechaPivotSeleccionada: e.target.value
        }, () => {
        });
    };
    render() {


        return (
            <React.Fragment>
                <Toolbar style={{backgroundColor:'white'}} style={{ textAlign: 'left' }}>
                    <div className="p-toolbar-group-left">
                            <Button label="Fecha Pivot:" icon="pi pi-calendar" className="p-button-secondary" 
                            style={{borderColor:'white', backgroundColor:'white'}}></Button>
                            <Calendar dateFormat="yy/mm/dd" value={this.state.date3} onChange={(e) => {
                                this.setState({ date3: e.value });
                               // this.props.setFecha(e.value);
                                }
                                }/>
                            &nbsp;
                            <Button label="Actualizar" icon="pi pi-refresh" onClick={()=>{
                                //this.props.actualizar();
                            }} className="p-button-secondary" 
                        style={{borderColor:'white', backgroundColor:'white'}}></Button>
                            <TieredMenu model={this.state.ejecutar} popup={true} ref={el => this.menu = el} />
                            <Button label="Ejecutar" icon="pi pi-cog" onClick={()=>{
                                this.props.ejecutar();
                            }} className="p-button-secondary" 
                        style={{borderColor:'white', backgroundColor:'white'}}></Button>

                    </div>
                </Toolbar>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        validacionCorrecto: state.validacion.validacionCorrecto,
        validacionIncorrecto: state.validacion.validacionIncorrecto,
        breadcrumb: state.breadcrumb
    };
}

export default connect(mapStateToProps)(MenuBarComponent);
