import React from 'react'
import styled from 'styled-components'
import { useTable, useRowSelect } from 'react-table'

const Styles = styled.div`
  padding: 1rem;

  table {
    border-spacing: 0;
    border: 1px solid black;

    tr {
      :last-child {
        td {
          border-bottom: 0;
        }
      }
    }

    th,
    td {
      margin: 0;
      padding: 0.5rem;
      border-bottom: 1px solid black;
      border-right: 1px solid black;

      :last-child {
        border-right: 0;
      }
    }
  }
`

const IndeterminateCheckbox = React.forwardRef(
  ({ indeterminate, ...rest }, ref) => {
    const defaultRef = React.useRef()
    const resolvedRef = ref || defaultRef

    React.useEffect(() => {
      resolvedRef.current.indeterminate = indeterminate
    }, [resolvedRef, indeterminate])

    return (
      <>
        <input type="checkbox" ref={resolvedRef} {...rest} />
      </>
    )
  }
)

function Table({ columns, data, props }) {
  // Use the state and functions returned from useTable to build your UI
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    selectedFlatRows,
    state: { selectedRowIds },
  } = useTable(
    {
      columns,
      data,
    },
    useRowSelect,
    hooks => {
      hooks.visibleColumns.push(columns => [
        // Let's make a column for selection
        {
          id: 'selection',
          // The header can use the table's getToggleAllRowsSelectedProps method
          // to render a checkbox
          Header: ({ getToggleAllRowsSelectedProps }) => (
            <div>
            </div>
          ),
          // The cell can use the individual row's getToggleRowSelectedProps method
          // to the render a checkbox
          Cell: ({ row }) => (
            <div>
              <IndeterminateCheckbox 
              onClick={() => {
                var seleccionadas=[];
                var globalSeleccionada=false;
                rows.forEach(fila=>{
                  if(fila.isSelected&&(fila.original.pivote!==row.original.pivote)){
                    globalSeleccionada=true;
                    alert("es seleccionable");
                  }
                });
                if(!row.isSelected||globalSeleccionada)
                rows.forEach(fila=>{
                  if(fila.original.pivote===row.original.pivote)seleccionadas.push(fila.original);
                  else
                  if(fila.isSelected)seleccionadas.push(fila.original);
                });
                props.eventoFilaSeleccionada(seleccionadas);
              }}
              {...row.getToggleRowSelectedProps()} 
              />
            </div>
          ),
        },
        ...columns,
      ])
    }
  )

  // Render the UI for your table
  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.slice(0, 10).map((row, i) => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => {
                  return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                })}
              </tr>
            )
          })}
        </tbody>
      </table>
      <p>Selected Rows: {Object.keys(selectedRowIds).length}</p>
      <pre>
        <code>
          {JSON.stringify(
            {
              selectedRowIds: selectedRowIds,
              'selectedFlatRows[].original': selectedFlatRows.map(
                d => d.original
              ),
            },
            null,
            2
          )}
        </code>
      </pre>
    </>
  )
}

function App(props) {
  const columns = React.useMemo(
    () => [
      {
        Header: 'Name',
        columns: [
          {
            "Header": "Fecha",
            "accessor": "pivote"
          },
          {
            "Header": "CREDITOS",
            "accessor": "CREDITOS"
          },
          {
            "Header": "FORTALECER",
            "accessor": "FORTALECER"
          },
          {
            "Header": "OTROS EGRESOS",
            "accessor": "OTROS EGRESOS"
          },
          {
            "Header": "PRD CONTINGENTES",
            "accessor": "PRD CONTINGENTES"
          },
          {
            "Header": "PRD JOVEN MUJER ARTESANO",
            "accessor": "PRD JOVEN MUJER ARTESANO"
          },
          {
            "Header": "PRD OTROS ACTIVOS",
            "accessor": "PRD OTROS ACTIVOS"
          },
          {
            "Header": "PROD AGRICOLA",
            "accessor": "PROD AGRICOLA"
          },
          {
            "Header": "PROD AHORROS",
            "accessor": "PROD AHORROS"
          },
          {
            "Header": "PROD CAJA",
            "accessor": "PROD CAJA"
          },
          {
            "Header": "PROD CORRIENTES",
            "accessor": "PROD CORRIENTES"
          },
          {
            "Header": "PROD DEPOSITOS",
            "accessor": "PROD DEPOSITOS"
          },
          {
            "Header": "PROD INVERSIONES",
            "accessor": "PROD INVERSIONES"
          },
          {
            "Header": "PROD ORGANIZACIONES",
            "accessor": "PROD ORGANIZACIONES"
          },
          {
            "Header": "PROD OTROS PASIVOS",
            "accessor": "PROD OTROS PASIVOS"
          },
          {
            "Header": "PROD TURISMO",
            "accessor": "PROD TURISMO"
          },
          {
            "Header": "total",
            "accessor": "total"
          }
        ],
      }
    ],
    []
  )

  const data = React.useMemo(() => [
    {
      "id":"22",
      "pivote": "2019-09-01",
      "CREDITOS": "6,389.93",
      "FORTALECER": "19,627.00",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "4,853.47",
      "PRD JOVEN MUJER ARTESANO": "390,016.00",
      "PRD OTROS ACTIVOS": "5,877.01",
      "PROD AGRICOLA": "39,025.27",
      "PROD AHORROS": "7,243.44",
      "PROD CAJA": "151.61",
      "PROD CORRIENTES": "579.89",
      "PROD DEPOSITOS": "133.84",
      "PROD INVERSIONES": "3,976.14",
      "PROD ORGANIZACIONES": "75,468.38",
      "PROD OTROS PASIVOS": "34,974.18",
      "PROD TURISMO": "7,635.97",
      "total": "595,952.12"
    },
    {
      "id":"33",
      "pivote": "2019-10-01",
      "CREDITOS": "16,560.83",
      "FORTALECER": "40,548.40",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "3,152.29",
      "PRD JOVEN MUJER ARTESANO": "987,766.11",
      "PRD OTROS ACTIVOS": "15,043.79",
      "PROD AGRICOLA": "100,638.24",
      "PROD AHORROS": "21,989.60",
      "PROD CAJA": "2,755.95",
      "PROD CORRIENTES": "286.08",
      "PROD DEPOSITOS": "240.90",
      "PROD INVERSIONES": "74.35",
      "PROD ORGANIZACIONES": "178,112.74",
      "PROD OTROS PASIVOS": "97,780.61",
      "PROD TURISMO": "14,636.60",
      "total": "1,479,586.49"
    },
    {
      "pivote": "2019-11-01",
      "CREDITOS": "13,218.04",
      "FORTALECER": "48,053.17",
      "OTROS EGRESOS": "241.87",
      "PRD CONTINGENTES": "5,595.12",
      "PRD JOVEN MUJER ARTESANO": "961,281.13",
      "PRD OTROS ACTIVOS": "11,397.52",
      "PROD AGRICOLA": "126,852.32",
      "PROD AHORROS": "17,732.18",
      "PROD CAJA": "2,337.69",
      "PROD CORRIENTES": "534.11",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "307.83",
      "PROD ORGANIZACIONES": "182,076.94",
      "PROD OTROS PASIVOS": "106,236.81",
      "PROD TURISMO": "23,265.14",
      "total": "1,499,129.88"
    },
    {
      "pivote": "2019-12-01",
      "CREDITOS": "15,001.10",
      "FORTALECER": "30,120.37",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "2,802.87",
      "PRD JOVEN MUJER ARTESANO": "968,416.59",
      "PRD OTROS ACTIVOS": "21,228.23",
      "PROD AGRICOLA": "113,379.48",
      "PROD AHORROS": "14,431.01",
      "PROD CAJA": "3,628.15",
      "PROD CORRIENTES": "563.08",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "42.51",
      "PROD ORGANIZACIONES": "225,532.74",
      "PROD OTROS PASIVOS": "84,486.49",
      "PROD TURISMO": "7,052.83",
      "total": "1,486,685.45"
    },
    {
      "pivote": "2020-01-01",
      "CREDITOS": "15,224.54",
      "FORTALECER": "11,052.03",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "1,002.04",
      "PRD JOVEN MUJER ARTESANO": "1,107,633.59",
      "PRD OTROS ACTIVOS": "12,286.35",
      "PROD AGRICOLA": "92,260.03",
      "PROD AHORROS": "16,045.48",
      "PROD CAJA": "855.80",
      "PROD CORRIENTES": "180.12",
      "PROD DEPOSITOS": "106.77",
      "PROD INVERSIONES": "9.86",
      "PROD ORGANIZACIONES": "230,316.14",
      "PROD OTROS PASIVOS": "62,726.60",
      "PROD TURISMO": "2,449.40",
      "total": "1,552,148.75"
    },
    {
      "pivote": "2020-02-02",
      "CREDITOS": "55,008.88",
      "FORTALECER": "14,742.58",
      "OTROS EGRESOS": "289.66",
      "PRD CONTINGENTES": "7,952.34",
      "PRD JOVEN MUJER ARTESANO": "1,150,606.93",
      "PRD OTROS ACTIVOS": "8,454.62",
      "PROD AGRICOLA": "81,536.07",
      "PROD AHORROS": "18,949.86",
      "PROD CAJA": "241.71",
      "PROD CORRIENTES": "740.62",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "10,458.47",
      "PROD ORGANIZACIONES": "193,389.59",
      "PROD OTROS PASIVOS": "30,372.46",
      "PROD TURISMO": "10,702.59",
      "total": "1,583,446.37"
    },
    {
      "pivote": "2020-03-02",
      "CREDITOS": "23,270.73",
      "FORTALECER": "66,785.46",
      "OTROS EGRESOS": "730.69",
      "PRD CONTINGENTES": "12,777.29",
      "PRD JOVEN MUJER ARTESANO": "1,381,620.07",
      "PRD OTROS ACTIVOS": "9,765.94",
      "PROD AGRICOLA": "131,565.09",
      "PROD AHORROS": "37,052.28",
      "PROD CAJA": "2,020.15",
      "PROD CORRIENTES": "817.45",
      "PROD DEPOSITOS": "776.25",
      "PROD INVERSIONES": "132.80",
      "PROD ORGANIZACIONES": "235,231.94",
      "PROD OTROS PASIVOS": "141,017.34",
      "PROD TURISMO": "40,696.37",
      "total": "2,084,259.85"
    },
    {
      "pivote": "2020-04-23",
      "CREDITOS": "2,425.68",
      "FORTALECER": "8,278.84",
      "OTROS EGRESOS": "6.72",
      "PRD CONTINGENTES": "144.20",
      "PRD JOVEN MUJER ARTESANO": "152,200.62",
      "PRD OTROS ACTIVOS": "2,079.24",
      "PROD AGRICOLA": "15,620.42",
      "PROD AHORROS": "7,962.86",
      "PROD CAJA": "56.84",
      "PROD CORRIENTES": "905.67",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "6,731.12",
      "PROD ORGANIZACIONES": "24,404.04",
      "PROD OTROS PASIVOS": "13,309.90",
      "PROD TURISMO": "1,157.81",
      "total": "235,283.95"
    },
    {
      "pivote": "2020-05-31",
      "CREDITOS": "0.00",
      "FORTALECER": "468.20",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "0.00",
      "PRD JOVEN MUJER ARTESANO": "1,617.52",
      "PRD OTROS ACTIVOS": "0.00",
      "PROD AGRICOLA": "199.93",
      "PROD AHORROS": "10,480.44",
      "PROD CAJA": "0.00",
      "PROD CORRIENTES": "135.66",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "8,172.96",
      "PROD ORGANIZACIONES": "0.00",
      "PROD OTROS PASIVOS": "35.73",
      "PROD TURISMO": "0.00",
      "total": "21,110.44"
    },
    {
      "pivote": "2020-06-30",
      "CREDITOS": "0.00",
      "FORTALECER": "682.37",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "275.08",
      "PRD JOVEN MUJER ARTESANO": "23,445.54",
      "PRD OTROS ACTIVOS": "0.00",
      "PROD AGRICOLA": "3,042.78",
      "PROD AHORROS": "24,876.98",
      "PROD CAJA": "0.00",
      "PROD CORRIENTES": "1,244.66",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "901,396.34",
      "PROD ORGANIZACIONES": "59.11",
      "PROD OTROS PASIVOS": "87.91",
      "PROD TURISMO": "961.37",
      "total": "956,072.14"
    },
    {
      "pivote": "2020-07-20",
      "CREDITOS": "0.00",
      "FORTALECER": "247.63",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "0.00",
      "PRD JOVEN MUJER ARTESANO": "4,081.89",
      "PRD OTROS ACTIVOS": "0.00",
      "PROD AGRICOLA": "203.34",
      "PROD AHORROS": "23,586.51",
      "PROD CAJA": "310.49",
      "PROD CORRIENTES": "1,095.96",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "9,635.69",
      "PROD ORGANIZACIONES": "0.00",
      "PROD OTROS PASIVOS": "70.50",
      "PROD TURISMO": "45.60",
      "total": "39,277.61"
    },
    {
      "pivote": "2020-08-21",
      "CREDITOS": "0.00",
      "FORTALECER": "342.00",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "0.00",
      "PRD JOVEN MUJER ARTESANO": "2,931.87",
      "PRD OTROS ACTIVOS": "0.00",
      "PROD AGRICOLA": "438.87",
      "PROD AHORROS": "15,081.38",
      "PROD CAJA": "700.25",
      "PROD CORRIENTES": "3,042.08",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "0.00",
      "PROD ORGANIZACIONES": "0.00",
      "PROD OTROS PASIVOS": "48.60",
      "PROD TURISMO": "439.20",
      "total": "23,024.25"
    },
    {
      "pivote": "2020-09-15",
      "CREDITOS": "0.00",
      "FORTALECER": "501.90",
      "OTROS EGRESOS": "0.00",
      "PRD CONTINGENTES": "0.00",
      "PRD JOVEN MUJER ARTESANO": "3,487.19",
      "PRD OTROS ACTIVOS": "0.00",
      "PROD AGRICOLA": "356.54",
      "PROD AHORROS": "9,759.70",
      "PROD CAJA": "0.00",
      "PROD CORRIENTES": "1,230.63",
      "PROD DEPOSITOS": "0.00",
      "PROD INVERSIONES": "10,226.56",
      "PROD ORGANIZACIONES": "76.46",
      "PROD OTROS PASIVOS": "0.00",
      "PROD TURISMO": "0.00",
      "total": "25,638.98"
    }
  ], [])

  return (
    <Styles>
      <Table columns={columns} data={data} props={props} />
    </Styles>
  )
}

export default App


