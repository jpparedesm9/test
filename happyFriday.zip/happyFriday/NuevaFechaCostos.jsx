import React, {Component} from 'react';

class NuevaFechaCostos extends Component
{
    constructor(props){
        super(props);
    }
render(){
    return(
        <React.Fragment>
            Pruebas de adicion de Fecha
        </React.Fragment>
    );
}
}

export default NuevaFechaCostos;