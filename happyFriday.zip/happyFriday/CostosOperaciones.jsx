import React, { Component, createRef } from 'react';
import TablaDinamica from '../../../submodulos/comun/TablaDinamica/TablaDinamica';
import Grid from '@material-ui/core/Grid';
import {Panel} from 'primereact/panel';
import {connect} from 'react-redux';
import BatchServicio from '../../../../api/BatchServicio';
import MenuBarBatchComponent from './comun/MenuBarBatchComponent';
import { NotificationManager } from 'react-notifications';
import moment from "moment";
import VentanaModal from "../../comun/VentanaModal";
import NuevaFechaCostos from "./NuevaFechaCostos";

class CostosOperaciones extends Component {
    constructor(props){
        super(props);
        this.subdetalleRef=new createRef();
        this.detalleRef=new createRef();
        this.ventanaModalRef= new createRef();
        this.state={
           treeData:[],
           selectedNodeKey:null,
           mostrarOperaciones:false,
           operaciones:[],
           mostrarSubdetalle:false,
           subdetalleCabecera:[],
           contenidoSubdetalle:[],
           detalle:[],
           detalleCabecera:[],
           mostrarDetalle:false,
           activarSubDetalle:false,
           fecha:null,
           cabeceraGeneral: null
        };
    }
    componentDidMount(){
        this.refrescarDetalle();
    }
    obtenerObjetoValidacion = () => {
        return [];
    }
    
    obtenerParametros=()=>
    {
        const parametros={
            cabecera:this.state.subdetalleCabecera,
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{return this.state.contenidoSubdetalle;},
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false
        };
        return parametros;
    }
    refrescarDetalle= () => {
        this.setState({ mostrarDetalle: false, mostrarSubdetalle:false },
            () => {
                let cabeceraGeneral = [];
                switch (this.props.breadcrumb.breadcrumb) {
                    case "Costos": {
                        cabeceraGeneral = [
                            { title: 'Fecha Pivot', field: 'codigo',  }
                        ];
                        break;
                    }
                    case "Rentabilidad": {
                        cabeceraGeneral = [
                            { title: 'Fecha Pivot', field: 'fechaPivot.fecha',render:(rowData)=>{
                               // alert(new Date(rowData.fechaPivot.fecha.replace("[UTC]", '')));
                                return moment(new Date(rowData.fechaPivot.fecha.replace("[UTC]", ''))).format("YYYYY-MM-DD")
                            } }
                        ];
                        break;
                    }
                }
                this.setState({
                    cabeceraGeneral,
                    mostrarDetalle: true
                });
            }
        );
    }
    formatDate=(d)=>{
        //var d = new Date(date),
            var month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
        return [year, month, day].join('-');
    }
    ObtenerParametrosDetalle=()=>{
        const parametros={
            cabecera:this.state.cabeceraGeneral,
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{
            
            switch(this.props.breadcrumb.breadcrumb){
                case "Costos":{
                    return BatchServicio.obtenerFechasCostos();
                }
                case "Rentabilidad":{
                    return BatchServicio.obtenerFechasRentabilidad();
                }
                default:break;
            }
            return [];
            }
            ,
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false,
            paging:false,
            clickFila: (evt, selectedRow) => {

                const fecha=selectedRow.codigo.replace(/-/g,"");

                this.setState({fecha,activarSubDetalle:true},()=>{
                    this.subdetalleRef.current.refrescar();
                });
            },
        };
        return parametros;      
    }

    ejecutar=()=>{
        let  ejecucion=null;
        switch(this.props.breadcrumb.breadcrumb){
            case "Costos":{
                ejecucion=BatchServicio.ejecutarBatchCosto();
                break;
            }
            case "Rentabilidad":{
                ejecucion=BatchServicio.ejecutarBatchRentabilidad();
                break;
            }
            default: break;
        }
        
        if (ejecucion!==null)
        ejecucion.then(resultado=>{
            NotificationManager.success(`Proceso Ejecutado`);
        },error=>{
            NotificationManager.error('Error', "Fallo en la ejecución", 5000, () => {});
        });
    }
    actualizar=()=>{
        if (this.state.fecha!==null){
            let actualizar=null;
            switch(this.props.breadcrumb.breadcrumb){
                case "Costos":{
                    actualizar=BatchServicio.actualizarBatchCosto(this.state.fecha);
                    break;
                }
                case "Rentabilidad":{
                    actualizar=BatchServicio.actualizarBatchRentabilidad(this.state.fecha);
                    break;
                }
                default:break;
            }
            if(actualizar!==null)
            actualizar.then(resultado=>{


            NotificationManager.success(`Actualización Correcta`);
            this.subdetalleRef.current.refrescar();
            
        },error=>{
            NotificationManager.error('Error', "Actualización Fallida", 5000, () => {});
        });
    }
    }
    obtenerCabeceraSubDetalle= () => {
        const cabecera = [
            { title: 'Código', field: 'codigo' },
            { title: 'Descripción', field: 'descripcion' },
            { title: 'Duración (Seg)', field: 'duracion' },
            { title: 'Mensaje', field: 'mensaje' },
        ];

        return cabecera;
    }
    ObtenerParametrosSubDetalle=()=>{
        const parametros={
            cabecera:this.obtenerCabeceraSubDetalle(),
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{
               
                switch(this.props.breadcrumb.breadcrumb){
                    case "Costos":{
                        return BatchServicio.obtenerCostoDetalle(this.state.fecha);
                    }
                    case "Rentabilidad":{
                        return BatchServicio.obtenerRentabilidadDetalle(this.state.fecha);
                    }
                    default:break;
                }
            },
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false,
            paging:false
        };
        return parametros;      
    }
    shouldComponentUpdate(nextProps, nextState)
    {
        if(this.props.breadcrumb.breadcrumb!==nextProps.breadcrumb.breadcrumb)
        {
            this.setState(
                {
                    activarSubdetalle:false
                },()=>{
                     this.refrescarDetalle();
                }
            );
        }
        return true;
    }
    nuevoCosto=()=>{
        this.ventanaModalRef.current.abrirVentana("confirmacion", "Escoja una fecha para añadir", []);
    }
    render() {
        return (
            <React.Fragment>
                <VentanaModal ref={this.ventanaModalRef} componente={NuevaFechaCostos} refrescarComponente={() => { }} />
                <MenuBarBatchComponent ejecutar={this.ejecutar} actualizar={this.actualizar} nuevoCosto={this.nuevoCosto}/>
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        <Panel header={this.props.breadcrumb.breadcrumb} style={{height:'50%'}}>
                            {this.state.mostrarDetalle&&
                            <TablaDinamica ref={this.detalleRef} parametros={this.ObtenerParametrosDetalle()}/>
                            }
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        </Panel>
                        
                        <Panel header={"Procesos ejecutados:"+this.state.fecha} style={{height: '100px'}}>
                        {this.state.activarSubDetalle&&
                            <TablaDinamica ref={this.subdetalleRef} parametros={this.ObtenerParametrosSubDetalle()}/>
                        }
                        </Panel>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        breadcrumb: state.breadcrumb
     };
}

const mapDispatchToProps = {
}


export default connect(mapStateToProps, mapDispatchToProps)(CostosOperaciones);