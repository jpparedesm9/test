import React, { Component } from 'react';
import TablaDinamica from '../comun/TablaDinamica/TablaDinamica';
import BimCrud from '../../../api/BimCrud';
import * as Yup from 'yup';
import mensajes from "../../../global/Mensajes";
import BimServicio from "../../../api/BimServicio";
import SettingsIcon from '@material-ui/icons/Settings';
import ConfiguracionEsquema from './ConfiguracionEsquema';

let msn = mensajes();
class Esquemas extends Component {
    constructor(props){
        super(props);
        this.state={
            mostrarEsquema:false,
            tipoEsquemas:{},
            esquemaEscogido:null,
            descripcionEsquema:null,
            nombreEsquemaSeleccion:"",
            mostrarConfiguracionEsquema:true
        }
        const tipoEsquemasPromise=BimServicio.ObtenerTipoEsquemas();
        tipoEsquemasPromise.then(resultado=>{
            const informacion=resultado.data;
            var tipoEsquemas={};
            informacion.forEach(registro=>{
                tipoEsquemas[registro.codigo]=registro.nombre;
            });
            this.setState({
                mostrarEsquema:true,
                tipoEsquemas
            });
        });
    }

    obtenerObjetoValidacion = () => {
        const objetoValidacion = Yup.object().shape({
            nombre: Yup.string()
                .required(msn.msnCampoRequerido),
            descripcion: Yup.string()
                .required(msn.msnCampoRequerido),
            tipoEsquema: Yup.object().shape({
                codigo: Yup.number()
                .required(msn.msnCampoRequerido),
            })
        });
        return objetoValidacion;
    }

    obtenerParametros=()=>{
        const parametros={
            cabecera:[
                { title: msn.msnNombre, field: 'nombre'},
                { title: msn.msnDescripcion, field: 'descripcion' },
                { title: "Tipo", field: 'tipoEsquema.codigo', lookup:this.state.tipoEsquemas},
                {title: "Estado", field: 'control', type: 'boolean',
                cellStyle: {
                    textAlign: 'center'
                },
                width: '10px'}
            ],
            componente:'Esquemas',
            clickFila: (evt, selectedRow) => {
                alert(selectedRow.descripcion);
                this.setState({
                    esquemaEscogido:selectedRow.codigo,
                    descripcionEsquema:selectedRow.codigo,
                    mostrarConfiguracionEsquema:false,
                    nombreEsquemaSeleccion:selectedRow.nombre
                },()=>{
                    this.setState({
                        mostrarConfiguracionEsquema:false
                    },()=>{
                        this.setState({
                            mostrarConfiguracionEsquema:true
                        });                      
                    }
                    );
                })
            },
            nuevoRegistro:(registro)=>{return BimCrud.RegistrarJerarquiaDeOFicina(registro)},
            editarRegistro:(registroanterior,registro)=>{return BimCrud.ActualizarEsquema(registro)}, 
            eliminarRegistro:(registro)=>{return BimCrud.EliminarJerarquiaDeOFicina(registro)},
            obtenerInformacion:BimServicio.ObtenerEsquemas,
            objetoValidacion:this.obtenerObjetoValidacion,
            excluirFunciones:["Copiar","Importar","Nuevo"],
            nombreArchivo:"jerarquía_de_oficina",
            botonesEdicion:{editar:true,eliminar:false},
            activarToolBar:true,
            validarObjeto: true,
            paging:false,
            estiloSeleccion: true,
        };
        return parametros;
    }
    render() {
        return (
            <div>
            {this.state.mostrarEsquema&&
            <TablaDinamica parametros={this.obtenerParametros()}/>
            }
            <br />
            {this.state.mostrarConfiguracionEsquema&&
                <ConfiguracionEsquema codigoEsquema={this.state.esquemaEscogido} descripcionEsquema={this.state.descripcionEsquema} nombreEsquema={this.state.nombreEsquemaSeleccion}/>
            }
            </div>
        );
    }
}

export default Esquemas;
