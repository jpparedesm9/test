import React, { Component, createRef } from "react";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import TablaDinamica from '../comun/TablaDinamica/TablaDinamica';
import VentanaModal from "../comun/VentanaModal";
import BimCrud from '../../../api/BimCrud';
import BimServicio from "../../../api/BimServicio";
import CostosServicio from "../../../api/CostosServicio";
import * as Yup from 'yup';
import EtlServicio from "../../../api/EtlServicio";
import mensajes from '../../../global/Mensajes';
import { Tree } from 'primereact/tree';
import ProcesarProductos from './ProcesarProductos';
import ProcesarCuentaGasto from './ProcesarCuentaGasto';
import { connect } from 'react-redux';
import { NotificationManager } from 'react-notifications';
import actualizarJson from '../../../../redux/actions/actualizarJson';

class ConfiguracionEsquema extends Component {
    constructor(props) {
        super(props);
        this.detalleRef = new createRef();
        this.ventanaModalRef = new createRef();
        this.cuentaGastoModalRef=new createRef();
        this.state = {
            seleccionTipoEsquema: {},
            mostrarTipoEsquema: false,
            msn: mensajes(),
            nivelActual: 1,
            menu_lateral: [],
            rawMenu: {},
            esquemaActual: 0,
            mostrarDetalle: false,
            estructuraFiltrada: [],
            registrosPorPadre: [],
            tipoEstructuraEsquema: [],
            producto:[],
            cuentaGastos:[],
            mostrarCuentaGastos:false,
            mostrarProducto:false
        };
        const tipoEstructuraPromise = EtlServicio.obtenerCatalogoPorTipo("TIPO_ESTRUCTURA_ESQUEMA");
        tipoEstructuraPromise.then(resultado => {
            const tipoEstructuraEsquema = resultado.data;
            var seleccionTipoEsquema = {};
            tipoEstructuraEsquema.forEach(registro => {
                if(this.props.descripcionEsquema===registro.descripcion||registro.descripcion==="CARPETA")
                seleccionTipoEsquema[registro.valor] = registro.descripcion;
            });
            this.setState({
                seleccionTipoEsquema,
                mostrarTipoEsquema: true,
                tipoEstructuraEsquema
            });
        });
        const productoPromise=BimServicio.ObtenerRegistrosProductoFinanciero();
       
        productoPromise.then(resultado=>{
            var productoProcesado=[];
            resultado.data.forEach(registro=>{
                  let provisional={
                      codigo:registro.codigo,
                      nombre:registro.nombre
                  }
                  productoProcesado.push(provisional)
                }
            );
            this.setState({
                producto: productoProcesado,
                mostrarProducto: true
            });
        }
        );

        const cuentaGastoPromise=CostosServicio.ObtenerCuentaPresupuestoPorTipo(1);
        cuentaGastoPromise.then(resultado=>{
            var cuentaGastosProcesado=[];
            resultado.data.forEach(registro=>{
                  let provisional={
                      codigo:registro.codigo,
                      nombre:registro.nombre
                  }
                  cuentaGastosProcesado.push(provisional)
                }
            );
            this.setState({
                cuentaGastos: cuentaGastosProcesado,
                mostrarCuentaGastos: true
            });
        }
        );


        this.iniciarOperaciones();
    }
    obtenerRegistrosPorNivel = (padre, nivelActual) => {
        var registrosProcesados = [];
        registrosProcesados = this.state.grupoNiveles[nivelActual].filter(registro => {
            if (typeof registro.codigoPadre !== "undefined")
                return registro.codigoPadre === padre;
            return false;
        });
        return registrosProcesados;
    }
    iniciarOperaciones = async () => {
        const menusPromise = await BimServicio.ObtenerConfiguracionEsquema(this.props.codigoEsquema);
        const rawMenu = menusPromise.data;
        this.setState({
            rawMenu,
            estructuraFiltrada: []
        }, () => {
            this.setState({
                menu_lateral: this.obtenerMenuPrincipal()
            }, () => {

            });
        });
        if(this.detalleRef.current!==null)
        this.detalleRef.current.refrescar();
    }
    obtenerObjetoValidacion = () => {
        return Yup.object().shape({
            codigoTipoEstructuraEsquema: Yup.number()
                .required(this.state.msn.msnCampoRequerido),
            nombre: Yup.string()
                .required(this.state.msn.msnCampoRequerido),
        });
    }


    obtenerMenuEsquema = (nodoRecorrer) => {
        var menuFinal = [];
        nodoRecorrer.forEach(nodo => {
            var children = [];
            if (typeof nodo.hijosSet !== "undefined")
                children = this.obtenerMenuEsquema(nodo.hijosSet);
            var temporal = {
                key: nodo.codigo.toString() + "-" + nodo.nivel.toString(),
                label: nodo.nombre,
                data: 'Documents Folder',
                icon: 'pi pi-fw pi-folder',
                children
            };
            if(nodo.codigoTipoEstructuraEsquema===1)
            menuFinal.push(temporal);

            var estructuraFiltrada = this.state.estructuraFiltrada;
            var temporal = {
                "codigo": nodo.codigo,
                "codigoPadre": nodo.codigoPadre,
                "codigoTipoEstructuraEsquema": nodo.codigoTipoEstructuraEsquema,
                "esquemaCodigo": nodo.esquemaCodigo,
                "nivel": nodo.nivel,
                "nombre": nodo.nombre
            };
            estructuraFiltrada.push(temporal);
            this.setState({ estructuraFiltrada });
        });
        return menuFinal;
    }
    agruparNiveles = () => {
        const groupBy = key => array =>
            array.reduce((objectsByKeyValue, obj) => {
                const value = obj[key];
                objectsByKeyValue[value] = (objectsByKeyValue[value] || []).concat(obj);
                return objectsByKeyValue;
            }, {});
        const agruparNiveles = groupBy('codigoPadre');
        var registrosPorPadre = agruparNiveles(this.state.estructuraFiltrada);
        this.setState({ registrosPorPadre });
    }
    procesarProductos = () => {
        const codigosSeleccionados = this.props.generalJson.json.registros;
        const resultadoBusqueda = this.state.estructuraFiltrada.filter(valor => parseInt(valor.codigo) === parseInt(this.state.esquemaActual));
        var registroPadre = resultadoBusqueda[0];
        registroPadre["hijosSet"] = [];
        var tipoEstructuraValor=null;
        this.state.tipoEstructuraEsquema.forEach(registro => {
            if (registro.descripcion === "PRODUCTO_RENTABILIDAD") tipoEstructuraValor = registro.valor;
        });

        codigosSeleccionados.forEach(registro=>{
            var productoSeleccionado=this.state.producto.filter(valor=>valor.codigo===registro);
            var infoRegistro = {
                "codigoTipoEstructuraEsquema": tipoEstructuraValor,
                "esquemaCodigo": this.props.codigoEsquema,
                "nivel": this.state.nivelActual,
                "nombre": productoSeleccionado[0].nombre,
            };
            if (this.state.nivelActual > 1) infoRegistro["codigoPadre"] = this.state.esquemaActual;
            registroPadre["hijosSet"].push(infoRegistro);
        });

        BimCrud.ActualizarConfiguracionEsquema(registroPadre).then(resultado=>{
            NotificationManager.success("Actualizado correctamente");
            this.iniciarOperaciones();
        },error=>{
            NotificationManager.error('Error', "Error en el procesamiento, intente nuevamente.", 5000, () => {
            });
        });

    }
    procesarCuentaGastos = () => {
        const codigosSeleccionados = this.props.generalJson.json.registros;
        const resultadoBusqueda = this.state.estructuraFiltrada.filter(valor => parseInt(valor.codigo) === parseInt(this.state.esquemaActual));
        var registroPadre = resultadoBusqueda[0];
        registroPadre["hijosSet"] = [];
        var tipoEstructuraValor=null;
        this.state.tipoEstructuraEsquema.forEach(registro => {
            if (registro.descripcion === "CUENTA_GASTO") tipoEstructuraValor = registro.valor;
        });

        codigosSeleccionados.forEach(registro=>{
            var cuentaGastoSeleccionado=this.state.cuentaGastos.filter(valor=>valor.codigo===registro);
            var infoRegistro = {
                "codigoTipoEstructuraEsquema": tipoEstructuraValor,
                "esquemaCodigo": this.props.codigoEsquema,
                "nivel": this.state.nivelActual,
                "nombre": cuentaGastoSeleccionado[0].nombre,
            };
            if (this.state.nivelActual > 1) infoRegistro["codigoPadre"] = this.state.esquemaActual;
            registroPadre["hijosSet"].push(infoRegistro);
        });

        BimCrud.ActualizarConfiguracionEsquema(registroPadre).then(resultado=>{
            NotificationManager.success("Actualizado correctamente");
            this.iniciarOperaciones();
            this.detalleRef.current.refrescar();
        },error=>{
            NotificationManager.error('Error', "Error en el procesamiento, intente nuevamente.", 5000, () => {
            });
        });

    }
    nuevoProducto = async () => {
        const cuentasPorPadrePromise=await BimServicio.ObtenerCuentasPorProductoPadre(this.state.esquemaActual);
        const cuentasPorPadre=cuentasPorPadrePromise.data;
        var nombreSeleccionados=cuentasPorPadre.map(registro=>registro.nombre);
        var productosSeleccionado=this.state.producto.filter(registro=>nombreSeleccionados.includes(registro.nombre));
        const codigoProductos=productosSeleccionado.map(registro=>registro.codigo);
        this.props.actualizarJson({registros:codigoProductos});

        this.ventanaModalRef.current.abrirVentana("confirmacion", "Agrupar Productos | RML", [
            {
                nombre: "Crear", accion: this.procesarProductos, cerrarVentana: () => {
                }
            }
        ]);
    } 
    nuevoCuentaGasto = async () => {
        const cuentasPorPadrePromise=await BimServicio.ObtenerCuentasPorProductoPadre(this.state.esquemaActual);
        const cuentasPorPadre=cuentasPorPadrePromise.data;
        var nombreSeleccionados=cuentasPorPadre.map(registro=>registro.nombre);
        var cuentasSeleccionado=this.state.cuentaGastos.filter(registro=>nombreSeleccionados.includes(registro.nombre));
        const codigoCuentas=cuentasSeleccionado.map(registro=>registro.codigo);
        this.props.actualizarJson({registros:codigoCuentas});

        this.cuentaGastoModalRef.current.abrirVentana("confirmacion", "Agrupar Cuenta Gastos | RML", [
            {
                nombre: "Crear", accion: this.procesarCuentaGastos, cerrarVentana: () => {
                }
            }
        ]);
    }
    obtenerMenuPrincipal = () => {
        let menuPrincipal = [{
            key: "0-0",
            label: "Esquemas",
            data: 'Documents Folder',
            icon: 'pi pi-fw pi-folder',
            children: this.obtenerMenuEsquema(this.state.rawMenu)
        }];
        this.agruparNiveles();
        return menuPrincipal;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: [
                {
                    title: "Tipo", field: 'codigoTipoEstructuraEsquema', lookup: this.state.seleccionTipoEsquema, onChange: (rowData) => {
                        var codigoProducto = 0;
                        var codigoCuentaGasto=0;
                        this.state.tipoEstructuraEsquema.forEach(registro => {
                            if (registro.descripcion === "PRODUCTO_RENTABILIDAD") codigoProducto = registro.valor;
                            if (registro.descripcion === "CUENTA_GASTO") codigoCuentaGasto = registro.valor;
                        });
                        if (codigoProducto === rowData) this.nuevoProducto();
                        if (codigoCuentaGasto === rowData) this.nuevoCuentaGasto();
                    },
                    editable: (columnDef, data) => {
                        var valorEscogido=(typeof data.codigoTipoEstructuraEsquema!=="undefined")?data.codigoTipoEstructuraEsquema:0;
                        var esEditable = true;
                        this.state.tipoEstructuraEsquema.forEach(registro => {
                            if ((valorEscogido === "CARPETA")&&(registro.codigo===valorEscogido)) esEditable = false;
                        });
                        return esEditable;
                    }
                }
                ,
                {
                    title: "Nombre", field: 'nombre', editable: (columnDef, data) => {
                        return true;
                    }
                },
            ],
            componente: 'Configuraci\u00f3n Esquema',
            nuevoRegistro: (registro) => {
                const infoRegistro = {
                    "codigoTipoEstructuraEsquema": registro.codigoTipoEstructuraEsquema,
                    "esquemaCodigo": this.props.codigoEsquema,
                    "nivel": this.state.nivelActual,
                    "nombre": registro.nombre,
                };
                if (this.state.nivelActual > 1) infoRegistro["codigoPadre"] = this.state.esquemaActual;
                if (this.state.nivelActual > 6) return BimCrud.InsertarConfiguracionEsquema({});

                return BimCrud.InsertarConfiguracionEsquema(infoRegistro);
            },
            editarRegistro: (registroanterior, registro) => {
                const resultadoBusqueda = this.state.estructuraFiltrada.filter(valor => valor.codigo === registro.codigoPadre);
                var registroPadre = resultadoBusqueda[0];
                registroPadre["hijosSet"] = [];
                registro["hijosSet"] = this.state.registrosPorPadre[registro.codigo];
                registroPadre["hijosSet"].push(registro);
                return BimCrud.ActualizarConfiguracionEsquema(registroPadre);
            },
            nuevoCallback: () => {
                this.iniciarOperaciones();
            },
            borrarCallback: () => {
                this.iniciarOperaciones();
            },
            eliminarRegistro: (registro) => {

                return BimCrud.BorrarConfiguracionEsquema(registro.codigo, this.props.codigoEsquema)
            },
            obtenerInformacion: () => {
                var resultado = this.state.registrosPorPadre[this.state.esquemaActual];
                if (typeof resultado === "undefined") return [];
                return resultado;
            },
            objetoValidacion: this.obtenerObjetoValidacion,
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "configuracion_esquema",
            botonesEdicion: { editar: true, eliminar: true },
            activarToolBar: true,
            validarObjeto: true
        };
        return parametros;
    }
    render() {
        return (
            <React.Fragment>
                <VentanaModal ref={this.ventanaModalRef} componente={ProcesarProductos} refrescarComponente={() => {
                }} />
                <VentanaModal ref={this.cuentaGastoModalRef} componente={ProcesarCuentaGasto} refrescarComponente={() => {

                    this.setState({
                        mostrarDetalle: false
                    }, () => {
                        this.setState({ mostrarDetalle: true });
                    });
                }} />

                <Grid container spacing={1}>
                    <Grid item xs={3}>
                        <Panel header="Esquema">
                            <Tree style={{ textAlign: 'left', border: '0px', width: '270px' }}
                                value={this.state.menu_lateral}
                                selectionMode="single"
                                onSelectionChange={(e) => {
                                    var codigos = e.value.split("-");
                                    this.setState({
                                        esquemaActual: codigos[0],
                                        nivelActual: parseInt(codigos[1]) + 1,
                                        mostrarDetalle: true
                                    }, () => {
                                        this.detalleRef.current.refrescar();
                                    });
                                }}
                                filter={true}
                            />
                        </Panel>
                    </Grid>
                    <Grid item xs={9}>
                        <Panel header={"Configuración de "+this.props.nombreEsquema}>
                            {(this.state.mostrarTipoEsquema && this.state.mostrarDetalle&&this.state.mostrarProducto&&this.state.mostrarCuentaGastos) &&
                                <TablaDinamica ref={this.detalleRef} parametros={this.obtenerParametros()} />
                            }
                        </Panel>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        generalJson: state.generalJson
    };
}
const mapDispatchToProps = {
    actualizarJson
}
export default connect(mapStateToProps, mapDispatchToProps)(ConfiguracionEsquema);