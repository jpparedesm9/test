import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import AssessmentIcon from '@material-ui/icons/Assessment';
import Collapse from '@material-ui/core/Collapse';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import FolderOpenIcon from '@material-ui/icons/FolderOpen';
import { Link } from 'react-router-dom';
import '../../../recursos/Style.css';
import MultilineChartIcon from '@material-ui/icons/MultilineChart';

export default function Reportes() {

  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(!open);
  };

  return (
<React.Fragment>

    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      className="lateral_menu" key="productosServicios"
    >
      <ListItem button onClick={handleClick}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Productos y Servicios" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>


        <List component="div" disablePadding key="reportes_resultado_productos">
          <Link to="/submenu/reportes/resultado_productos" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="701 Resultado de Productos" />
            </ListItem>
          </Link>

        </List>
        <List component="div" disablePadding key="reportes_rentabilidad">
          {/*<Link to="/submenu/reportes/indicador1" className="lateral_menu">*/}
          <Link to="/submenu/reportes/evolutivo_mensual_productos_servicios" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <AssessmentIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="702 Evolutivo Productos y Servicios" />
            </ListItem>
          </Link>

        </List>
        <List component="div" disablePadding key="participacion_saldo">
          {/*<Link to="/submenu/reportes/indicador1" className="lateral_menu">*/}
          <Link to="/submenu/reportes/reporte_saldo" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="703 Participacion Saldo" />
            </ListItem>
          </Link>

        </List>
        <List component="div" disablePadding key="precio_transferencia">
          <Link to="/submenu/reportes/704_precio_transferencia" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="704 Precio Interno Transferencia" />
            </ListItem>
          </Link>
        </List>

        <List component="div" disablePadding key="indicadores_costos">
          <Link to="/submenu/reportes/705_indicadores_costos" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="705 Indicadores de Costos" />
            </ListItem>
          </Link>
        </List>
        <List component="div" disablePadding key="clasificacion_canales">
          <Link to="/submenu/reportes/706_clasificacion_canales" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="706 Clasificación Canales" />
            </ListItem>
          </Link>
        </List>    
        <List component="div" disablePadding key="ranking_canales">
          <Link to="/submenu/reportes/707_ranking_canales" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="707 Ranking Canales" />
            </ListItem>
          </Link>
        </List>   
        <List component="div" disablePadding key="participacion_aporte_ingresos">
          <Link to="/submenu/reportes/708_participacion_aporte_ingresos" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="708 Participación Aporte Ingresos" />
            </ListItem>
          </Link>
        </List>  
        <List component="div" disablePadding key="indicador_costos">
          <Link to="/submenu/reportes/709_indicador_costos" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="709 Indicadores de Costos" />
            </ListItem>
          </Link>
        </List>  
        <List component="div" disablePadding key="clasificacion_de_agencia">
          <Link to="/submenu/reportes/710_clasificacion_de_agencia" className="lateral_menu">
            <ListItem button >
              <ListItemIcon>
                <MultilineChartIcon style={{ color: '#ffffff' }} />
              </ListItemIcon>
              <ListItemText primary="710 Clasificación de Agencia" />
            </ListItem>
          </Link>
        </List>  

      </Collapse>
    </List>

     
     <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      className="lateral_menu" key="rentabilidadProductosServicios"
    >
      <ListItem button onClick={handleClick}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Canales" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>



      </Collapse>
    </List>


    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      className="lateral_menu" key="rentabilidadProductosServicios"
    >
      <ListItem button onClick={handleClick}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Oficina" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>


       




      </Collapse>
    </List>

    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      className="lateral_menu" key="rentabilidadProductosServicios"
    >
      <ListItem button onClick={handleClick}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Productividad y Eficiencia" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>


      </Collapse>
    </List>

    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      className="lateral_menu" key="rentabilidadProductosServicios"
    >
      <ListItem button onClick={handleClick}>
        <ListItemIcon>
          <FolderOpenIcon />
        </ListItemIcon>
        <ListItemText primary="Análisis Zonales" />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>


       




      </Collapse>
    </List>

    </React.Fragment>

  );
}
