import React, { Component } from 'react';
import { Tree } from 'primereact/tree';
import { OverlayPanel } from 'primereact/overlaypanel';
import { Button } from 'primereact/button';
import BimServicio from "../../../../api/BimServicio";
import GeneralHelper from "../../../../api/GeneralHelper";
import {SplitButton} from 'primereact/splitbutton';


class MenuProductoRecursivo extends Component {

    constructor(props) {
        super(props);
        this.state = {
            nodes: null,
            selectedKey: null,
            selectedKeys1: null,
            selectedKeys2: null,
            selectedKeys3: null,
             menu_lateral: [],
            oficinaActual: 0,
            mostrarProductos:false
        };
        this.onNodeSelect = this.onNodeSelect.bind(this);
        this.onNodeUnselect = this.onNodeUnselect.bind(this);
    }  
    preseleccionElementos=(nodes)=>{
        var seleccion={};
        nodes.forEach(registro=>{
            seleccion[registro.key]={ checked: true, partialChecked: false };
            if(typeof registro.children!=="undefined"){
                const hijos=this.preseleccionElementos(registro.children);
                const merged={...seleccion, ...hijos};
                seleccion={};
                seleccion=merged;
            }
        });
        return seleccion;
    }
    componentDidMount() {
        const productoRentabilidad=BimServicio.ObtenerConfiguracionEsquema(2);
        productoRentabilidad.then(resultado => {
            const registros = resultado.data;
            const nodes=GeneralHelper.obtenerEsquemaMenuDesdeArbol(registros);
            var seleccion=this.preseleccionElementos(nodes);
            this.setState({
                nodes,
                selectedKeys3:seleccion,
                mostrarProductos:true
            },()=>{
                this.procesarSeleccion();
            });
        });
    }
    onNodeSelect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Selected', detail: node.label, life: 3000 });
    }
    onNodeUnselect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Unselected', detail: node.label, life: 3000 });
    }
    procesarSeleccion=()=>{
        var seleccion=[];
        Object.keys(this.state.selectedKeys3).forEach(registro=>
        {
            const clave=registro.split('-');
            if(parseInt(clave[1])===3)seleccion.push(clave[0]);
        }
        );
        this.props.cambioProductoEsquema(seleccion);
    }
    render() {
        return (
            <React.Fragment>
                {this.state.mostrarProductos&&
                <div style={{display:"block", float:"right"}}>
                    &nbsp;&nbsp;
                    <Button label="Productos" icon="pi pi-chevron-down" onClick={(e)=>{
                     this.op.toggle(e);
                            }} className="p-button-secondary" style={{borderColor:'white', backgroundColor:'white', display:"block", float:"right", marginTop:"5px"}}/>

                <OverlayPanel ref={(el) => this.op = el}>
                    <Tree value={this.state.nodes} 
                    selectionMode="checkbox" 
                    selectionKeys={this.state.selectedKeys3} 
                    onSelectionChange={e => 
                    {
                    this.setState({ selectedKeys3: e.value },()=>{
                        this.procesarSeleccion();
                    });
                    }
                    } 
                    filter={true}
                    />
                </OverlayPanel>
                </div>
                }
            </React.Fragment>
        )
    }
}


export default MenuProductoRecursivo;