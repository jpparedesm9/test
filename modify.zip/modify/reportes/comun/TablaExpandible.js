import React from 'react'
import styled from 'styled-components'
import { useTable, useExpanded } from 'react-table'

const Styles = styled.div`
  padding: 1rem;
  table {
    border-spacing: 0;
    border: 1px solid black;
    width:"100%",
    tr {
      :last-child {
        td {
          border-bottom: 0;
        }
      }
    }
    tbody{
      text-align: right;
    }
    tbody>tr>:nth-child(2){
     text-align: left;
     }
    tbody>tr>:nth-child(1){
    text-align: left;
    width:20px;
    font-size: 12pt;
    }
    th,
    td {
      margin: 0;
      padding: 0.5rem;
      border-bottom: 1px solid black;
      border-right: 1px solid black;
      :last-child {
        border-right: 0;
      }
    }
  }
`

function Table({ columns: userColumns, data }) {
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    state: { expanded },
  } = useTable(
    {
      columns: userColumns,
      data,
    },
    useExpanded // Use the useExpanded plugin hook
  )

  return (
    <>
      <table {...getTableProps()} width="100%">
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map((row, i) => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => {
                  return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                })}
              </tr>
            )
          })}
        </tbody>
      </table>
    </>
  )
}

function App(props) {
  const columns = React.useMemo(
    () => {
    var retorno=[
      {
        // Build our expander column
        id: 'expander', // Make sure it has an ID
        Header: ({ getToggleAllRowsExpandedProps, isAllRowsExpanded }) => (
          <span {...getToggleAllRowsExpandedProps()}>
            {isAllRowsExpanded ? '-' : '+'}
          </span>
        ),
        Cell: ({ row }) =>
          row.canExpand ? (
            <span
              {...row.getToggleRowExpandedProps({
                style: {
                  paddingLeft: `${row.depth * 2}rem`,
                },
              })}
            >
              {row.isExpanded ? '-' : '+'}
            </span>
          ) : null,
      }
    ];

    props.cabeceraTabla.forEach(registro=>{
      retorno.push(registro);
    });
 
    return retorno;
  }
    ,
    []
  )

  const data = React.useMemo(() =>
  props.cuerpoTabla, [])
  return (
    <Styles>
      <Table columns={columns} data={data} style={{width:"100%"}}/>
    </Styles>
  )
}

export default App;