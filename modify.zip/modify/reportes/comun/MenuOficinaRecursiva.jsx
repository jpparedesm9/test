import React, { Component } from 'react';
import { Tree } from 'primereact/tree';
import { OverlayPanel } from 'primereact/overlaypanel';
import { Button } from 'primereact/button';
import BimServicio from "../../../../api/BimServicio";
import GeneralHelper from "../../../../api/GeneralHelper";
import AccessTimeIcon from '@material-ui/icons/AccessTime';
import Icon from '@material-ui/core/Icon';
import {SplitButton} from 'primereact/splitbutton';

 


class MenuOficinaRecursiva extends Component {

    constructor(props) {
        super(props);
        this.state = {
            nodes: null,
            productos:null,
            selectedKey: null,
            selectedKeys1: null,
            selectedKeys2: null,
            selectedKeys3: null,
             menu_lateral: [],
            oficinaActual: 0,
            mostrarOficinas:false
        };
        this.onNodeSelect = this.onNodeSelect.bind(this);
        this.onNodeUnselect = this.onNodeUnselect.bind(this);
    }  
    preseleccionElementos=(nodes)=>{
        var seleccion={};
        nodes.forEach(registro=>{
            seleccion[registro.key]={ checked: true, partialChecked: false };
            if(typeof registro.children!=="undefined"){
                const hijos=this.preseleccionElementos(registro.children);
                const merged={...seleccion, ...hijos};
                seleccion={};
                seleccion=merged;
            }
        });
        return seleccion;
    }
    componentDidMount() {
        const oficinas = BimServicio.ObtenerRegistrosOficina();
        oficinas.then(resultado => {
            const registros = resultado.data;
            const nodes=GeneralHelper.obtenerFormatoMenu(registros);
            var seleccion=this.preseleccionElementos(nodes);
            this.setState({
                    nodes,
                    selectedKeys3:seleccion,
                    mostrarOficinas:true
                },()=>{
                    this.procesarSeleccion();
                });
        });
    }
    onNodeSelect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Selected', detail: node.label, life: 3000 });
    }
    onNodeUnselect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Unselected', detail: node.label, life: 3000 });
    }
    procesarSeleccion=()=>{
        var seleccion=[];
        Object.keys(this.state.selectedKeys3).forEach(registro=>
        {
            seleccion.push(registro);
        }
        );
        this.props.cambioOficinas(seleccion);
    }
    render() {
        return (
            <React.Fragment>

                {this.state.mostrarOficinas&&
                <div style={{display:"inline-block", float:'left'}}>
                <Button label="Oficina" icon="pi pi-chevron-down" onClick={(e)=>{
                     this.op.toggle(e);
                            }} className="p-button-secondary" style={{borderColor:'white', backgroundColor:'white', display:"block", float:"right", marginTop:"5px"}}/>
                <OverlayPanel ref={(el) => this.op = el}  style={{ maxHeight: "300px", overflow: 'auto' }}>
                    <Tree value={this.state.nodes} 
                    selectionMode="checkbox" 
                    selectionKeys={this.state.selectedKeys3} 
                    onSelectionChange={e => this.setState({ selectedKeys3: e.value },
                    ()=>{
                        this.procesarSeleccion();
                    })} 
                    filter={true}
                    />
                </OverlayPanel>
                </div>
                }
            </React.Fragment>
        )
    }
}


export default MenuOficinaRecursiva;