import React, { Component } from 'react';
import { Tree } from 'primereact/tree';
import { OverlayPanel } from 'primereact/overlaypanel';
import { Button } from 'primereact/button';
import BimServicio from '../../../../api/BimServicio';
import GeneralHelper from "../../../../api/GeneralHelper";
import FilterNoneIcon from '@material-ui/icons/FilterNone';
import {SplitButton} from 'primereact/splitbutton';

class MenuAreaRecursivo extends Component {

    constructor(props) {
        super(props);
        this.state = {
            nodes: null,
            productos:null,
            selectedKey: null,
            selectedKeys1: null,
            selectedKeys2: null,
            selectedKeys3: null,
             menu_lateral: [],
            oficinaActual: 0,
            mostrarInfo:true,
        };
        this.onNodeSelect = this.onNodeSelect.bind(this);
        this.onNodeUnselect = this.onNodeUnselect.bind(this);
    }  
    componentDidMount() {
        const areasPromise=BimServicio.ObtenerRegistrosArea();
        areasPromise.then(resultado => {
            const registros = resultado.data;
            const nodes=GeneralHelper.obtenerMenuDesdeArbol(registros);
            const seleccion={};
            nodes.forEach(registro=>{
                seleccion[registro.key]={ checked: true, partialChecked: false };
                //{ checked: true, partialChecked: false }
            });
            this.setState({
                    nodes,selectedKeys3:seleccion
                },()=>{
                    this.procesarSeleccion();
                });
        });
    }
    onNodeSelect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Selected', detail: node.label, life: 3000 });
    }
    onNodeUnselect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Unselected', detail: node.label, life: 3000 });
    }    
    procesarSeleccion=()=>{
        var seleccion=[];
        Object.keys(this.state.selectedKeys3).forEach(registro=>
        {
            seleccion.push(registro);
        }
        );
        this.props.cambioAreas(seleccion);
    }

    render() {
        return (
            <React.Fragment>
                <Button label="Areas" icon="pi pi-chevron-down" onClick={(e)=>{
                     this.op.toggle(e);
                            }} className="p-button-secondary" style={{borderColor:'white', backgroundColor:'white', display:"block", float:"right", marginTop:"5px"}}/>
                
                <OverlayPanel ref={(el) => this.op = el}>
                    <Tree value={this.state.nodes} 
                    selectionMode="checkbox" 
                    selectionKeys={this.state.selectedKeys3} 
                    onSelectionChange={e => {
                        console.log(e.value);
                        this.setState({ selectedKeys3: e.value },()=>{
                            this.procesarSeleccion();
                        });
                    }} 
                    filter={true}
                    />
                </OverlayPanel>
            </React.Fragment>
        )
    }
}


export default MenuAreaRecursivo;