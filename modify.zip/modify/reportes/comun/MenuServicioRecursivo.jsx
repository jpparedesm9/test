import React, { Component } from 'react';
import { Tree } from 'primereact/tree';
import { OverlayPanel } from 'primereact/overlaypanel';
import { Button } from 'primereact/button';
import ReportesServicio from "../../../../api/ReportesServicio";
import GeneralHelper from "../../../../api/GeneralHelper";
import {SplitButton} from 'primereact/splitbutton';


class MenuServicioRecursivo extends Component {

    constructor(props) {
        super(props);
        this.state = {
            nodes: null,
            productos:null,
            selectedKey: null,
            selectedKeys1: null,
            selectedKeys2: null,
            selectedKeys3: null,
             menu_lateral: [],
            oficinaActual: 0,
        };
        this.onNodeSelect = this.onNodeSelect.bind(this);
        this.onNodeUnselect = this.onNodeUnselect.bind(this);
    }  
    componentDidMount() {
        const codigoServicios="codigosTiposConceptos=10";
        const oficinas = ReportesServicio.obtenerNombreConceptos(codigoServicios);
        oficinas.then(resultado => {
            const registros = resultado.data;
            const seleccion={};
            const nodes=GeneralHelper.convertirFormatoSeleccion(registros);
            nodes.forEach(registro=>{
                seleccion[registro.key]={ checked: true, partialChecked: false };
                //{ checked: true, partialChecked: false }
            });
            this.setState({
                    nodes,
                    selectedKeys3:seleccion
                },()=>{
                    this.procesarSeleccion();
                });
        });
    }
    onNodeSelect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Selected', detail: node.label, life: 3000 });
    }
    onNodeUnselect(node) {
        this.toast.show({ severity: 'success', summary: 'Node Unselected', detail: node.label, life: 3000 });
    }
    procesarSeleccion=()=>{
        var seleccion=[];
        Object.keys(this.state.selectedKeys3).forEach(registro=>
        {
            seleccion.push(registro);
        }
        );
        this.props.cambioServicios(seleccion);
    }
    render() {
        return (
            <React.Fragment>
                <div style={{display:"block", float:"right"}}>
                    &nbsp;&nbsp;
                    <Button label="Servicios" icon="pi pi-chevron-down" onClick={(e)=>{
                     this.op.toggle(e);
                            }} className="p-button-secondary" style={{borderColor:'white', backgroundColor:'white', display:"block", float:"right", marginTop:"5px"}}/>

                <OverlayPanel ref={(el) => this.op = el}>
                    <Tree value={this.state.nodes} 
                    selectionMode="checkbox" 
                    selectionKeys={this.state.selectedKeys3} 
                    onSelectionChange={e => {
                        this.setState({ selectedKeys3: e.value },()=>{
                            this.procesarSeleccion();
                        });
                    } 
                    }
                    filter={true}
                     />
                </OverlayPanel>
                </div>
            </React.Fragment>
        )
    }
}


export default MenuServicioRecursivo;