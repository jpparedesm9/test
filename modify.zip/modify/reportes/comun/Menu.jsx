import React, { Component } from 'react';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
//import '../../../../recursos/Style.css';
import { connect } from 'react-redux';
import { Toolbar } from 'primereact/toolbar';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { MultiSelect } from 'primereact/multiselect';
//import './MultiSelectDemo.scss';
import BimServicio from '../../../../api/BimServicio';
import moment from "moment";
import { SplitButton } from 'primereact/splitbutton';
import MenuOficinaRecursiva from './MenuOficinaRecursiva';
import MenuAreaRecursivo from './MenuAreaRecursivo';
import MenuServicioRecursivo from './MenuServicioRecursivo';
import MenuProductoRecursivo from './MenuProductoRecursivo';

class MenuBarComponent extends Component {

    constructor(props) {
        super(props);
        let itemsIniciales = [
            {
                label: 'Actualizar',
                icon: 'pi pi-fw pi-refresh',
                command: () => {
                    //this.props.nuevoRegistroAccion();
                }
            },
            {
                label: 'Exportar',
                icon: 'pi pi-fw pi-upload',
                items: []
            },
            {
                label: 'Ejecutar',
                icon: 'pi pi-fw pi-cog',
                items: [
                    {
                        label: 'Excel',
                        icon: 'pi pi-fw pi-file-excel',
                        command: () => {
                            ///this.props.excelExportAction();
                        }
                    },
                ]
            }
        ];

        this.state = {
            productosSeleccionados: props.productos,
            serviciosSeleccionados: [],
            oficinasSeleccionadas: [],
            oficinas: [],
            areasSeleccionadas: [],
            areas: [],
            productoEsquema: [],
            fechaPivotSeleccionada: null,
            items: itemsIniciales,
            fechaInicio: null,
            fechaFin: null,
            elementoSeleccionado: null,
            codigoElemento: null,
            productos: props.productos,
            servicios: props.servicios,
            metricaSeleccionada: null,
            codigoMetricaSeleccionada: null,
            ejecutar: [
                {
                    label: 'Resumen',
                    command: () => {
                        // this.props.exportarExcelExtraccion(); 
                    }
                },
                {
                    label: 'Detalle',
                    command: () => {
                        //this.props.exportarExcelDetalle();
                    }
                },
            ]
        };
        this.elementos = [
            { name: 'Producto', code: '1' },
            { name: 'Servicio', code: '10' }
        ];
        this.metricas = [
            { name: 'Costo', code: 'COSTO' },
            { name: 'Rentabilidad', code: 'RENTABILIDAD' }
        ];
      
        this.items = [
            {
                label: 'Excel',
                icon: 'pi pi-file-excel',
                command: () => {
                    this.exportarExcel();
                }
            },
            {
                label: 'Pdf',
                icon: 'pi pi-file-pdf',
                command: () => {
                    this.exportarPdf();
                }
            }
        ];

        this.save = this.save.bind(this);


    }
    componentDidMount() {
        this.setState({ metricaSeleccionada: { name: 'Costo', code: 'COSTO' }, });

    }
    exportarExcel = () => {
        var parametrosSeleccionados = this.extraerParametrosSeleccionados();
        parametrosSeleccionados.fechaInicio = moment(new Date(this.state.fechaInicio)).format("YYYY-MM-DD");;
        parametrosSeleccionados.fechaFin = moment(new Date(this.state.fechaFin)).format("YYYY-MM-DD");;
        this.props.exportarExcel(parametrosSeleccionados);
    }
    exportarPdf = () => {
        var parametrosSeleccionados = this.extraerParametrosSeleccionados();
        parametrosSeleccionados.fechaInicio = moment(new Date(this.state.fechaInicio)).format("YYYY-MM-DD");;
        parametrosSeleccionados.fechaFin = moment(new Date(this.state.fechaFin)).format("YYYY-MM-DD");;
        this.props.exportarPdf(parametrosSeleccionados);
    }
    validarEliminacionComponente(breadcrumb) {
        var activo = false;
        switch (breadcrumb) {
            case "operaciones":
            case "valorFrenCarga":
            case "factorRentabilidad": {
                activo = true;
                break;
            }
            default: break;
        }
        return activo;
    }
    cambioFechaPivot = (e) => {
        this.setState({
            fechaPivotSeleccionada: e.target.value
        }, () => {
        });
    };
    cambioProductoEsquema = (productoEsquema) => {
        this.setState({ productoEsquema });
    }

    cambioServicios = (serviciosSeleccionados) => {
        this.setState({ serviciosSeleccionados });
    }
    cambioAreas = (areasSeleccionadas) => {
        this.setState({ areasSeleccionadas });
    }
    cambioOficinas = (oficinasSeleccionadas) => {        
        this.setState({ oficinasSeleccionadas });
    }

    extraerParametrosSeleccionados = () => {
        const registro = {
            "tipo": this.state.elementoSeleccionado.code.toString(),
            "metrica": this.state.metricaSeleccionada.code.toString(),
            "fechaDesde": "20170101",
            "fechaHasta": "20201201",
            "productosIn": this.state.productoEsquema,
            "areasIn": this.state.areasSeleccionadas,
            "oficinasIn": this.state.oficinasSeleccionadas,
            "conceptosIn": this.state.serviciosSeleccionados
        };
        return registro;
    }
    procesarEjecucion = () => {
        var parametrosSeleccionados = this.extraerParametrosSeleccionados();
        parametrosSeleccionados.fechaDesde = moment(new Date(this.state.fechaInicio)).format("YYYYMMDD");  //20170101
        parametrosSeleccionados.fechaHasta = moment(new Date(this.state.fechaFin)).format("YYYYMMDD");     //20201201
        this.props.accionEjecutar(parametrosSeleccionados);
    }
    cambioElemento = (e) => {
        this.setState({ elementoSeleccionado: e.value, codigoElemento: parseInt(e.value.code) });
    }
    cambioMetrica = (e) => {
        this.setState({ metricaSeleccionada: e.value, codigoMetricaSeleccionada: parseInt(e.value.code) });
    }
    save() {
    }
    render() {


        return (
            <React.Fragment>
                <Toolbar style={{ backgroundColor: 'white' }} style={{ textAlign: 'left' }}>
                    <div className="p-toolbar-group-left">

                        <Button label="Fecha Inicio:" icon="pi pi-calendar" className="p-button-secondary"
                            style={{ borderColor: 'white', backgroundColor: 'white' }}></Button>
                        <Calendar dateFormat="yy-mm-dd" value={this.state.fechaInicio} onChange={(e) => {
                            this.setState({ fechaInicio: e.value });
                            // this.props.setFecha(e.value);
                        }
                        } />
                        {this.props.parametros.fechaFin &&
                            <div style={{ display: "inline-block" }}>
                                <Button label="Fecha Fin:" icon="pi pi-calendar" className="p-button-secondary"
                                    style={{ borderColor: 'white', backgroundColor: 'white' }}></Button>
                                <Calendar dateFormat="yy-mm-dd" value={this.state.fechaFin} onChange={(e) => {
                                    this.setState({ fechaFin: e.value });
                                    // this.props.setFecha(e.value);
                                }
                                } />
                            </div>
                        }
                                &nbsp;&nbsp;Tipo de Elemento:&nbsp;&nbsp;
                        <Dropdown value={this.state.elementoSeleccionado} options={this.elementos} onChange={this.cambioElemento} optionLabel="name"
                            placeholder="Seleccione un elemento" style={{ width: "200px" }} />
                        &nbsp; &nbsp;
                        <SplitButton label="Exportar" icon="pi pi-download" onClick={this.save} model={this.items} className="p-button-secondary" style={{ borderColor: 'white', backgroundColor: 'white' }}></SplitButton>
                        &nbsp; &nbsp;
                    <Button label="Ejecutar" icon="pi pi-cog" onClick={() => {
                            this.procesarEjecucion();
                        }} className="p-button-secondary"
                            style={{ borderColor: 'white', backgroundColor: 'white' }}></Button>

                    </div>
                </Toolbar>
                <Toolbar style={{ backgroundColor: 'white' }} style={{ textAlign: 'left' }}>
                    <div className="multiselect-demo">
                        <div className="p-toolbar-group-left">
                            {(this.state.codigoElemento === 1) &&
                                <MenuProductoRecursivo cambioProductoEsquema={this.cambioProductoEsquema} />
                            }
                            {(this.state.codigoElemento === 10) &&
                                <MenuServicioRecursivo cambioServicios={this.cambioServicios} />
                            }
                    &nbsp; &nbsp;
                    <MenuOficinaRecursiva cambioOficinas={this.cambioOficinas} />
                            <MenuAreaRecursivo cambioAreas={this.cambioAreas} />

                        </div>
                        <div style={{ display: "inline-block", float: "left", marginTop: "5px" }}>
                            &nbsp;&nbsp;M&eacute;tricas:&nbsp;&nbsp;
                    <Dropdown value={this.state.metricaSeleccionada} options={this.metricas} onChange={this.cambioMetrica}
                                optionLabel="name" placeholder="Seleccione un elemento" style={{ width: "200px" }} />
                        </div>
                    </div>
                </Toolbar>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        validacionCorrecto: state.validacion.validacionCorrecto,
        validacionIncorrecto: state.validacion.validacionIncorrecto,
        breadcrumb: state.breadcrumb
    };
}

export default connect(mapStateToProps)(MenuBarComponent);