import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "../comun/Menu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import ReportesServicio from '../../../../api/ReportesServicio';
import GeneralHelper from '../../../../api/GeneralHelper';
import BimServicio from '../../../../api/BimServicio'
import { NotificationManager } from 'react-notifications';
import Box from '@material-ui/core/Box';
import html2canvas from "html2canvas";
import { LOGO_BASE_64 } from "../../../../recursos/LOGO_BASE_64";
import ExportacionExcel from '../../comun/TablaDinamica/exportacion/ExportacionExcel';
import ExportacionPdf from '../../comun/TablaDinamica/exportacion/ExportacionPdf';
import Expandible from "../comun/TablaExpandible";
import Paper from '@material-ui/core/Paper';
import actualizarBreadCrumb from '../../../../../redux/actions/actualizarBreadCrumb';
import {connect} from 'react-redux';
import TablaSeleccionable from '../comun/TablaSeleccionable';


const pdfConverter = require("jspdf");

class ParticipacionSaldo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cabecera: [],
            mostrarGrafic: false,
            mostrarTabla: false,
            graficoSpinner: false,
            tablaSpinner: false,
            servicios: [],
            ultimaCabecera: [],
            maestroDetalle2: [],
            datosGrafico: [],//this.procesarArreglo(info),,
            productos: [],
            productosFiltrados: [],
            maestroDetalle: [],
            mostrarProductos: true,
            fechaTitulo:"",
            mostrarServicios: true,
            cabeceraTabla: [],
            cuerpoTabla: [],
            mostrarTablaDatos: false,
            cabeceraGchart:[],
            cuerpoGchart:[],
            cuerpoLineaGchart:[],
            mostrarLineaGchart:false,
            mostrarCabeceraGchart:false,
            mostrarCuerpoGchart:false,
            registrosPrimerNivel:[],
            tituloSuperior:"",
            tituloInferior:"",
            leyendaEjeY:""
        };

    }
    componentDidMount() {
        
        var productos = [];
        var servicios = [];
        const productosPromise = BimServicio.ObtenerProductoRentabilidad();
        productosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    productos.push({ name: registro.nombre, code: registro.codigo });
                });
        });

        this.setState({ productos }, () => {
            this.setState({ mostrarProductos: true }, () => {
            });
        });

        const codigoServicios = "codigosTiposConceptos=11";
        const serviciosPromise = ReportesServicio.obtenerNombreConceptos(codigoServicios);
        serviciosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    servicios.push({ name: registro.nombre, code: registro.codigo });
                });
            this.setState({ servicios }, () => {
                this.setState({ mostrarServicios: true }, () => {
                });
            });
        });
        
        this.iniciarOperaciones();
    }
    iniciarOperaciones=()=>{
        this.props.actualizarBreadCrumb("ReporteEvolutivoMensual");
    }
    accionEjecutar = (parametros) => {
        parametros["identificador"]="703";
        parametros["categoria"]="12011";
        parametros["ejecucion"]="1";
        parametros["metrica"]="SALDO";
        this.setState({
            graficoSpinner: true,
            tablaSpinner: true,
            mostrarTabla: false,
            mostrarGrafic: false
        });
        //this.procesarArreglo(parametros,dataquemada);
        
        ReportesServicio.obtenerReporteEvolutivoCostoRentabilidadMensual(parametros).then(resultado => {
            
            this.procesarArreglo(parametros,resultado.data);
        }, error => {
            NotificationManager.error('Error', "Ha ocurrido un error, intente nuevamente", 5000, () => {
                this.setState({
                    graficoSpinner: false,
                    tablaSpinner: false,
                    mostrarTabla: false,
                    mostrarGrafic: false
                });
            });
        });
        
    }
    procesarArreglo = (parametros,registros) => {
        const tipo=(parametros.tipo.toString()==="1")?"PRODUCTO":"SERVICIO";
        var tituloSuperior=parametros.metrica.toString()+" POR "+tipo;
        const tituloInferior="EVOLUTIVO "+tituloSuperior;
        this.setState({tituloSuperior,tituloInferior});
        var provisional=registros;
        this.setState({
            mostrarTablaDatos: false, mostrarCuerpoGchart:false 
        },()=>{

            if(parseInt(parametros.tipo)===1){
            const cabeceraTabla = ReportesServicio.convertirFormatoTablaCabecera([{ Header: 'Fecha', accessor: 'pivote' }], registros[0]);
            var cuerpoLineaGchart= ReportesServicio.obtenerCuerpoGchart(cabeceraTabla,registros);
            console.log("linea",cuerpoLineaGchart);
            const cuerpoTabla = ReportesServicio.obtenerRegistrosFormatoTablaPlana(registros);
            var registrosPrimerNivel=registros;
            this.setState({
                cuerpoTabla, cabeceraTabla,registrosPrimerNivel,leyendaEjeY:GeneralHelper.capitalizeFirstLetter(parametros.metrica.toLowerCase()),cuerpoLineaGchart
            }, () => {
                this.setState({ mostrarTablaDatos: true ,mostrarLineaGchart:true});
            });
        }
        else{
            const cabeceraTabla = ReportesServicio.convertirFormatoTablaCabecera([{ Header: 'Servicio', accessor: 'pivote' }], registros[0]);
            var cuerpoGchart= ReportesServicio.obtenerServicioCuerpoGchart(cabeceraTabla,provisional);
            const cuerpoTabla = ReportesServicio.convertirServicioTablaCuerpo(registros);

            const cabeceraGchart= ReportesServicio.obtenerCabeceraFormatoGchart(cabeceraTabla);
            
            var registrosPrimerNivel=registros;
            this.setState({
                cuerpoTabla, cabeceraTabla,cabeceraGchart,cuerpoGchart,registrosPrimerNivel
            }, () => {
                this.setState({ mostrarTablaDatos: true, mostrarCuerpoGchart:true });
            });
        }
        });
    }
    obtenerNombreProducto = (codigo) => {
        var nombreProducto = "";
        this.state.productos.forEach(prd => {
            if (prd.code === codigo) nombreProducto = prd.name;
        });
        return nombreProducto;
    }
    obtenerCabecera = () => {
        var cabecera = [];
        cabecera.push({ title: "Fecha", field: "fecha" });
        this.state.productosFiltrados.forEach(producto => {
            var nombreProducto = "";
            this.state.productos.forEach(prd => {
                if (prd.code === producto) nombreProducto = prd.name;
            });
            cabecera.push({ title: nombreProducto, field: "key" + producto.toString() });
        });
        return cabecera;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.state.ultimaCabecera,//this.obtenerCabecera(),
            componente: 'Canal',
            obtenerInformacion: () => {
                return this.state.maestroDetalle2;
            },
            objetoValidacion: (objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "canal",
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }
    ensamblarImagenes = async (registro) => {
        let input = window.document.getElementsByClassName(registro.identificador)[0];
        const canvas = await html2canvas(input);
        var img = canvas.toDataURL("image/png");
        return img;
    }
    exportarExcel = (parametros) => {
        parametros.componente = "Evolutivo Mensual por Productos y Servicios";
        parametros.nombreArchivo = "reporte_base";
        ExportacionExcel.descargarExcelReporte(parametros, this.state.cabeceraTabla, ExportacionPdf.obtenerFilasReporte(this.state.cuerpoTabla));
    }
    exportarPdf = async (parametros, registros) => {
        const pdf = new pdfConverter("l", "pt");
        const marginLeft = 20;
        var imgData = `${LOGO_BASE_64}`;
        pdf.addImage(imgData, 'JPEG', 40, 20, 190, 43);
        var id = 1;
        await Promise.all(
            registros.map(async registro => {

                var img = await this.ensamblarImagenes(registro);
                pdf.addImage(
                    img,
                    "png",
                    40,
                    (this.state.mostrarCuerpoGchart)?registro.distanciaVertical:120,
                    760,//input.clientWidth,
                    registro.height,//input.clientHeight,
                    'imageId' + id.toString(),
                    'FAST'
                );

                id = id + 1;

            })
        );
        const elemento = (parametros.codigoElemento === 1) ? "Productos" : "Servicios";
        let content = {
            bodyStyles: { lineWidth: 0 },
            startY: 65,
            head: [['', '', '']],
            body: [
                ['Fecha Inicio: ' + parametros.fechaInicio, 'Tipo de Elemento: ' + elemento, ''],
                   ['Fecha Fin   : ' + parametros.fechaFin, 'Métrica                : ' + GeneralHelper.capitalizeFirstLetter(parametros.metrica.toLowerCase()), '']
            ],
            showHead: 'never',
            styles: {
                bodyStyles: {
                    fillColor: "#ffffff"
                }
            },
            didParseCell: function(data) {
                    data.cell.styles.fillColor='#ffffff';
            },
        };
        pdf.autoTable(content);
        const result=ExportacionPdf.obtenerTablaReporte(this.state.cabeceraTabla,this.state.cuerpoTabla);
        pdf.text("", marginLeft, 40);
        if(this.state.mostrarCuerpoGchart){
            result.options["startY"]=40;
            pdf.addPage();
        }
        pdf.autoTable(result.columns,result.rows,result.options);
        pdf.save("chart.pdf");

    };
    eventoFilaSeleccionada=(filas)=>{
        this.setState({mostrarCuerpoGchart:false},()=>{
            if(filas.length===1){
                var procesados=[];
                procesados.push(['Producto','Valor']);
                const registro=filas[0];
                this.setState({fechaTitulo:registro["pivote"]});
                Object.keys(registro).forEach(function(key) {
                    if((key!=="pivote")&&(key!=="total")&&(key!=="id")){
                    var value = ReportesServicio.reverseFormatNumber(registro[key],"en");
                    var valores=[];
                    valores.push(key);
                    valores.push(parseFloat(value));
                    procesados.push(valores);
                }
                });
                this.setState({
                    mostrarCuerpoGchart:true,
                    cuerpoGchart:procesados
                });
            }
        });
    }
    render() {
        return (

            <React.Fragment>
                <div>
                    {(this.state.mostrarProductos && this.state.mostrarServicios) &&
                        <Menu productos={this.state.productos} servicios={this.state.servicios} accionEjecutar={this.accionEjecutar}
                        parametros={{
                            fechaFin:true
                        }}
                            exportarPdf={(parametros) => {
                                const registros = [
                                    { width: 800, height: 200, identificador: "pie" ,distanciaVertical:120},
                                    { width: 800, height: 200, identificador: "superior",distanciaVertical:320 }
                                ];
                                this.exportarPdf(parametros, registros);
                            }}
                            exportarExcel={(registros) => {
                                this.exportarExcel(registros);
                            }}
                        />
                    }
                    <Grid container spacing={1}>
                        <Grid item xs={6}>
                            <Box style={{ maxHeight: "35vh",minHeight: "35vh"}} width="100%">
                                <Panel header={this.state.tituloSuperior} style={{ maxHeight: "35vh",minHeight: "35vh", overflow: 'auto',overflowX: "scroll"}}>
                               
                                <div style={{position:"relative",width:"80vw"}}>
                                {this.state.mostrarTablaDatos &&
                                <TablaSeleccionable eventoFilaSeleccionada={this.eventoFilaSeleccionada} cabeceraTabla={this.state.cabeceraTabla} cuerpoTabla={this.state.cuerpoTabla} />
                                }
                                </div>
                                </Panel>
                            </Box>
                        </Grid>
                        <Grid item xs={6}>
                            <Box style={{ maxHeight: "35vh",minHeight: "35vh"}} width="100%">
                                <Panel header={this.state.tituloSuperior} style={{ maxHeight: "35vh",minHeight: "35vh", overflow: 'auto',overflowX: "scroll"}} className="pie">
                                
                                <div style={{position:"relative",width:"100%"}}>
                                {(this.state.mostrarCuerpoGchart)&&
                                        <div style={{position:"relative", margin:"auto",width:"100%"}}>
                                            <Chart
                                                width={'100%'}
                                                height={'300px'}
                                                chartType="PieChart"
                                                loader={<div>Loading Chart</div>}
                                                data={this.state.cuerpoGchart}
                                                options={{
                                                    legend: {position: 'top', maxLines: 20, textStyle: {fontSize: 12}},
                                                    title: this.state.fechaTitulo,
                                                    // Just add this option
                                                    is3D: true,
                                                }}
                                                rootProps={{ 'data-testid': '2' }}
                                            />
                                        </div>
                                    }
                                </div>
                                </Panel>
                            </Box>
                        </Grid>
                        <Grid item xs={12}>
                            <Box style={{ maxHeight: "40vh",minHeight: "40vh"}} width="100%">
                            
                                <Panel header={this.state.tituloInferior} style={{ maxHeight: "100%", overflow: 'auto', overflowX:"auto", maxWidth:"100%"}} className="superior">
                                <Paper elevation={0} style={{overflowX:"auto"}}>
                                {this.state.mostrarLineaGchart&&
                                <div style={{position:"relative", margin:"auto",width:"80vw"}}>
                                        <Chart
                                            width={'100%'}
                                            height={'350px'}
                                            chartType="Line"
                                            loader={<div>Loading Chart</div>}
                                            data={this.state.cuerpoLineaGchart}
                                            options={{
                                                legend: {position: 'top', maxLines: 20, textStyle: {fontSize: 12}},
                                                chart: {
                                                    
                                                },
                                                width: "100%",
                                                height: "350px",
                                                series: {
                                                    // Gives each series an axis name that matches the Y-axis below.
                                                    0: { axis: 'Temps' },
                                                    1: { axis: 'Daylight' },
                                                },
                                                axes: {
                                                    // Adds labels to each axis; they don't have to match the axis names.
                                                    y: {
                                                        Temps: { label: '' },
                                                        Daylight: { label: 'Daylight' },
                                                    },
                                                },
                                            }}
                                            rootProps={{ 'data-testid': '4' }}
                                        />
                                        </div>
                                    }
                                     </Paper>
                                </Panel>
                           

                            </Box>
                        </Grid>
                    </Grid>
                </div>
            </React.Fragment>
        );
    };
}

const mapStateToProps=(state)=>{
    return {
       breadcrumb: state.breadcrumb,
    };
 }
 const mapDispatchToProps = {
    actualizarBreadCrumb
}
 
 export default connect(mapStateToProps,mapDispatchToProps)(ParticipacionSaldo);