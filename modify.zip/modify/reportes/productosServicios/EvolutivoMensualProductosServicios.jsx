import React, { Component } from 'react';
import Chart from "react-google-charts";
import Menu from "../comun/Menu";
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import ReportesServicio from '../../../../api/ReportesServicio';
import GeneralHelper from '../../../../api/GeneralHelper';
import BimServicio from '../../../../api/BimServicio';
import { NotificationManager } from 'react-notifications';
import Box from '@material-ui/core/Box';
import html2canvas from "html2canvas";
import { LOGO_BASE_64 } from "../../../../recursos/LOGO_BASE_64";
import ExportacionExcel from '../../comun/TablaDinamica/exportacion/ExportacionExcel';
import ExportacionPdf from '../../comun/TablaDinamica/exportacion/ExportacionPdf';
import Expandible from "../comun/TablaExpandible";
import Paper from '@material-ui/core/Paper';
import actualizarBreadCrumb from '../../../../../redux/actions/actualizarBreadCrumb';
import {connect} from 'react-redux';


const pdfConverter = require("jspdf");

class EvolutivoMensualProductosServicios extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cabecera: [],
            mostrarGrafic: false,
            mostrarTabla: false,
            graficoSpinner: false,
            tablaSpinner: false,
            servicios: [],
            ultimaCabecera: [],
            maestroDetalle2: [],
            datosGrafico: [],//this.procesarArreglo(info),,
            productos: [],
            productosFiltrados: [],
            maestroDetalle: [],
            mostrarProductos: true,
            mostrarServicios: true,
            cabeceraTabla: [],
            cuerpoTabla: [],
            mostrarTablaDatos: false,
            cabeceraGchart:[],
            cuerpoGchart:[],
            mostrarCabeceraGchart:false,
            mostrarCuerpoGchart:false,
            registrosPrimerNivel:[],
            tituloSuperior:"",
            tituloInferior:"",
            leyendaEjeY:""
        };

    }
    componentDidMount() {
        var productos = [];
        var servicios = [];
        const productosPromise = BimServicio.ObtenerProductoRentabilidad();
        productosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    productos.push({ name: registro.nombre, code: registro.codigo });
                });
        });

        this.setState({ productos }, () => {
            this.setState({ mostrarProductos: true }, () => {
            });
        });

        const codigoServicios = "codigosTiposConceptos=11";
        const serviciosPromise = ReportesServicio.obtenerNombreConceptos(codigoServicios);
        serviciosPromise.then(resultado => {
            if (typeof resultado.data !== "undefined")
                resultado.data.forEach(registro => {
                    servicios.push({ name: registro.nombre, code: registro.codigo });
                });
            this.setState({ servicios }, () => {
                this.setState({ mostrarServicios: true }, () => {
                });
            });
        });
        this.iniciarOperaciones();
    }
    iniciarOperaciones=()=>{
        this.props.actualizarBreadCrumb("ReporteEvolutivoMensual");
    }
    accionEjecutar = (parametros) => {
        parametros["identificador"]="702";
        parametros["categoria"]= (parametros.tipo.toString()==="1")?"11212":"12012";
        parametros["ejecucion"]="1";
        //parametros["conceptosIn"]=[47,48,49,51,52,53,55,56,57,58,59,60,61,62,63,64,65,66,67,68,70,71,72,73,74,75,76,77,114,115];
        this.setState({
            graficoSpinner: true,
            tablaSpinner: true,
            mostrarTabla: false,
            mostrarGrafic: false
        });
        //this.procesarArreglo(parametros,dataquemada);
        
        ReportesServicio.obtenerReporteEvolutivoCostoRentabilidadMensual(parametros).then(resultado => {
            
            this.procesarArreglo(parametros,resultado.data);
        }, error => {
            NotificationManager.error('Error', "Ha ocurrido un error, intente nuevamente", 5000, () => {
                this.setState({
                    graficoSpinner: false,
                    tablaSpinner: false,
                    mostrarTabla: false,
                    mostrarGrafic: false
                });
            });
        });
        
    }
    procesarArreglo = (parametros,registros) => {
        const tipo=(parametros.tipo.toString()==="1")?"PRODUCTO":"SERVICIO";
        var tituloSuperior=parametros.metrica.toString()+" POR "+tipo;
        const tituloInferior="EVOLUTIVO "+tituloSuperior;
        this.setState({tituloSuperior,tituloInferior});
        var provisional=registros;
        this.setState({
            mostrarTablaDatos: false, mostrarCuerpoGchart:false 
        },()=>{

            if(parseInt(parametros.tipo)===1){
            const cabeceraTabla = ReportesServicio.convertirFormatoTablaCabecera([{ Header: 'Producto', accessor: 'ee_nombre' }], registros[0]);
            const filtrado=registros.filter(registro=>registro.ee_tipo===3);
            var cuerpoGchart= ReportesServicio.obtenerCuerpoGchart(cabeceraTabla,filtrado);
            const cuerpoTabla = ReportesServicio.convertirFormatoTablaCuerpo(registros);


            const cabeceraGchart= ReportesServicio.obtenerCabeceraFormatoGchart(cabeceraTabla);
            var registrosPrimerNivel=ReportesServicio.obtenerRegistrosPrimerNivel();
            this.setState({
                cuerpoTabla, cabeceraTabla,cabeceraGchart,cuerpoGchart,registrosPrimerNivel,leyendaEjeY:GeneralHelper.capitalizeFirstLetter(parametros.metrica.toLowerCase())
            }, () => {
                this.setState({ mostrarTablaDatos: true, mostrarCuerpoGchart:true });
            });
        }
        else{
            const cabeceraTabla = ReportesServicio.convertirFormatoTablaCabecera([{ Header: 'Servicio', accessor: 'pivote' }], registros[0]);
            var cuerpoGchart= ReportesServicio.obtenerServicioCuerpoGchart(cabeceraTabla,provisional);
            const cuerpoTabla = ReportesServicio.convertirServicioTablaCuerpo(registros);

            const cabeceraGchart= ReportesServicio.obtenerCabeceraFormatoGchart(cabeceraTabla);
            
            var registrosPrimerNivel=registros;
            this.setState({
                cuerpoTabla, cabeceraTabla,cabeceraGchart,cuerpoGchart,registrosPrimerNivel
            }, () => {
                this.setState({ mostrarTablaDatos: true, mostrarCuerpoGchart:true });
            });
        }
        });
    }
    obtenerNombreProducto = (codigo) => {
        var nombreProducto = "";
        this.state.productos.forEach(prd => {
            if (prd.code === codigo) nombreProducto = prd.name;
        });
        return nombreProducto;
    }
    obtenerCabecera = () => {
        var cabecera = [];
        cabecera.push({ title: "Fecha", field: "fecha" });
        this.state.productosFiltrados.forEach(producto => {
            var nombreProducto = "";
            this.state.productos.forEach(prd => {
                if (prd.code === producto) nombreProducto = prd.name;
            });
            cabecera.push({ title: nombreProducto, field: "key" + producto.toString() });
        });
        return cabecera;
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.state.ultimaCabecera,//this.obtenerCabecera(),
            componente: 'Canal',
            obtenerInformacion: () => {
                return this.state.maestroDetalle2;
            },
            objetoValidacion: (objeto, registros) => { return this.obtenerObjetoValidacion(objeto, registros) },
            excluirFunciones: ["Copiar", "Importar"],
            nombreArchivo: "canal",
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }
    ensamblarImagenes = async (registro) => {
        let input = window.document.getElementsByClassName(registro.identificador)[0];
        const canvas = await html2canvas(input);
        var img = canvas.toDataURL("image/png");
        return img;
    }
    exportarExcel = (parametros) => {
        parametros.componente = "Evolutivo Mensual por Productos y Servicios";
        parametros.nombreArchivo = "reporte_base";
        ExportacionExcel.descargarExcelReporte(parametros, this.state.cabeceraTabla, ExportacionPdf.obtenerFilasReporte(this.state.cuerpoTabla));
    }
    exportarPdf = async (parametros, registros) => {
        const pdf = new pdfConverter("l", "pt");
        const marginLeft = 20;
        var imgData = `${LOGO_BASE_64}`;
        pdf.addImage(imgData, 'JPEG', 40, 20, 190, 43);
        var id = 1;
        await Promise.all(
            registros.map(async registro => {
                var img = await this.ensamblarImagenes(registro);
                pdf.addImage(
                    img,
                    "png",
                    40,
                    120,
                    760,//input.clientWidth,
                    registro.height,//input.clientHeight,
                    'imageId' + id.toString(),
                    'FAST'
                );
                id = id + 1;
            })
        );
        const elemento = (parametros.codigoElemento === 1) ? "Productos" : "Servicios";
        let content = {
            bodyStyles: { lineWidth: 0 },
            startY: 65,
            head: [['', '', '']],
            body: [
                ['Fecha Inicio: ' + parametros.fechaInicio, 'Tipo de Elemento: ' + elemento, ''],
                   ['Fecha Fin   : ' + parametros.fechaFin, 'Métrica                : ' + GeneralHelper.capitalizeFirstLetter(parametros.metrica.toLowerCase()), '']
            ],
            showHead: 'never',
            styles: {
                bodyStyles: {
                    fillColor: "#ffffff"
                }
            },
            didParseCell: function(data) {
                    data.cell.styles.fillColor='#ffffff';
            },
        };
        pdf.autoTable(content);
        const result=ExportacionPdf.obtenerTablaReporte(this.state.cabeceraTabla,this.state.cuerpoTabla);
        pdf.text("", marginLeft, 40);
        pdf.autoTable(result.columns,result.rows,result.options);
        pdf.save("chart.pdf");

    };
    render() {
        return (

            <React.Fragment>
                <div>
                    {(this.state.mostrarProductos && this.state.mostrarServicios) &&
                        <Menu productos={this.state.productos} servicios={this.state.servicios} accionEjecutar={this.accionEjecutar}
                        parametros={{
                            fechaFin:true
                        }}
                            exportarPdf={(parametros) => {
                                const registros = [
                                    { width: 800, height: 200, identificador: "superior" }
                                ];
                                this.exportarPdf(parametros, registros);
                            }}
                            exportarExcel={(registros) => {
                                this.exportarExcel(registros);
                            }}
                        />
                    }
                    <Grid container spacing={1}>
                        <Grid item xs={12}>
                            <Box style={{ maxHeight: "35vh",minHeight: "35vh"}} width="100%">
                                <Panel header={this.state.tituloSuperior} style={{ maxHeight: "35vh",minHeight: "35vh", overflow: 'auto',overflowX: "scroll"}}>
                                <Paper elevation={0} style={{overflowX:"auto",maxHeight: "35vh",minHeight: "35vh"}}>
                                <div style={{position:"relative",width:"80vw"}}>
                                        {this.state.mostrarTablaDatos &&
                                            <Expandible cabeceraTabla={this.state.cabeceraTabla} cuerpoTabla={this.state.cuerpoTabla} />
                                        }

                                    </div>
                                </Paper>
                                </Panel>
                            </Box>
                        </Grid>
                        <Grid item xs={12}>
                            <Box style={{ maxHeight: "40vh",minHeight: "40vh"}} width="100%">
                            
                                <Panel header={this.state.tituloInferior} style={{ maxHeight: "100%", overflow: 'auto', overflowX:"auto", maxWidth:"100%"}} className="superior">
                                <Paper elevation={0} style={{overflowX:"auto"}}>
                                        {(this.state.mostrarCuerpoGchart)&&
                                        <div style={{position:"relative", margin:"auto",width:"80vw"}}>
                                        <Chart
                                            width={'100%'}
                                            style={{ maxHeight: "35vh",minHeight: "35vh"}}
                                            chartType="AreaChart"
                                            loader={<div>Loading Chart</div>}
                                            data={this.state.cuerpoGchart}
                                            explorer={{axis: 'horizontal'}}
                                            options={{
                                                legend: {position: 'top', maxLines: 20, textStyle: {fontSize: 12}},
                                                hAxis: { title: 'Fecha', titleTextStyle: { color: '#333' },direction:-1, slantedText:true, slantedTextAngle:15, textStyle: {fontSize: 12}},
                                                vAxis: {  title: this.state.leyendaEjeY,minValue: 0, textStyle: {fontSize: 12} },
                                                // For the legend to fit, we make the chart area smaller
                                                chartArea: { width: '80%', height: '50vh' },
                                                explorer: {
                                                    actions: ['dragToZoom', 'rightClickToReset'],
                                                    axis: 'horizontal',
                                                    keepInBounds: true,
                                                    maxZoomIn: 100
                                                  },
                                                // lineWidth: 25
                                            }}
                                            // For tests
                                            rootProps={{ 'data-testid': '1' }}
                                        />
                                        </div>
                                    }
                                     </Paper>
                                </Panel>
                           

                            </Box>
                        </Grid>
                    </Grid>
                </div>
            </React.Fragment>
        );
    };
}

const mapStateToProps=(state)=>{
    return {
       breadcrumb: state.breadcrumb,
    };
 }
 const mapDispatchToProps = {
    actualizarBreadCrumb
}
 
 export default connect(mapStateToProps,mapDispatchToProps)(EvolutivoMensualProductosServicios);