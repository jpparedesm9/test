export const type = 'getmenus';
const getmenus = (menus) => ({
  type,
  payload: menus,
});
export default getmenus;
