export const type = 'actualizarTituloModal';
const actualizarTituloModal = (tituloModal) => ({
  type,
  payload: tituloModal,
});
export default actualizarTituloModal;
