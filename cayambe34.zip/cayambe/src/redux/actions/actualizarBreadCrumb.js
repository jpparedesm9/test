export const type= 'actualizarBreadCrumb';
const actualizarBreadCrumb=(breadcrumb)=>{
    return{
        type,
        payload: breadcrumb,
    }
}
export default actualizarBreadCrumb;