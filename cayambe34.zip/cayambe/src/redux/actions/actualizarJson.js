export const type= 'actualizarJson';
const actualizarJson=(generalJson)=>{
    return{
        type,
        payload: generalJson,
    }
}
export default actualizarJson;