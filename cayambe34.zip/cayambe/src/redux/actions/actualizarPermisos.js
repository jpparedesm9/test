export const type = 'actualizarPermisos';
const actualizarPermisos = (permissions) => ({
  type,
  payload: permissions,
});
export default actualizarPermisos;
