const defaultState={keyCloak:[]};
function reducer(state= defaultState, {type, payload})
{
    switch(type){
        case 'actualizarKeyCloak':{
            return {
            ...state,
            keyCloak: payload
            }
        }
        default:
            return state;
    }
}

export default reducer;