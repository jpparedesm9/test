import React, { Component } from 'react';
import TextField from '@material-ui/core/TextField';
import actualizarJson from '../../../../../redux/actions/actualizarJson';
import {connect} from 'react-redux';

class MensajeEjecutar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mensaje: ""
        };
        this.props.actualizarJson({codigo:""});
    }
    handleChange = (event) => {
        this.setState({
            mensaje: event.target.value
        });
        this.props.actualizarJson({codigo:event.target.value});
    };
    render() {
        return (
            <React.Fragment>
                <TextField id="standard-name" label="Por favor ingrese un mensaje" value={this.state.mensaje} onChange={this.handleChange} />
            </React.Fragment>
        );
    }
}
const mapStateToProps=(state)=>{
    return {
       generalJson: state.generalJson
    };
 }
 
 
 const mapDispatchToProps = {
    actualizarJson
 }
 export default connect(mapStateToProps,mapDispatchToProps)(MensajeEjecutar);