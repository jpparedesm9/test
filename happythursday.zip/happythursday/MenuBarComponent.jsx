import React, { Component } from 'react';
import { Menubar } from 'primereact/menubar';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import '../../../../recursos/Style.css';
import { connect } from 'react-redux';
import { Button } from 'primereact/button';

class MenuBarComponent extends Component {

    constructor(props) {
        super(props);
        //this.props.filtrarCorrectos();
        let itemsIniciales = [
            {
                label: 'Nuevo',
                icon: 'pi pi-fw pi-file',
                command: () => {
                    this.props.nuevoRegistroAccion();
                }
            },
            {
                label: 'Exportar',
                icon: 'pi pi-fw pi-upload',
                items: [
                    {
                        label: 'Excel',
                        icon: 'pi pi-fw pi-file-excel',
                        command: () => {
                            this.props.excelExportAction();
                        }
                    },
                    {
                        label: 'Pdf',
                        icon: 'pi pi-fw pi-file-pdf',
                        command: () => {
                            this.props.pdfExportAction();
                        }
                    }, {
                        label: 'Csv',
                        icon: 'pi pi-fw pi-file',
                        command: () => {
                            this.props.csvExportAction();
                        }
                    },
                ]
            },
            {
                label: 'Imprimir',
                icon: 'pi pi-fw pi-print',
                command: () => {
                    this.props.Imprimir()
                }
            },
            {
                label: 'Importar',
                icon: 'pi pi-fw pi-download',
                command: () => {
                    this.props.accionImportarExcel()
                }
            },
            {
                label: 'Copiar',
                icon: 'pi pi-fw pi-copy',
                command: () => {
                    this.props.accionCopiado();
                }
            }
        ];
        if (typeof this.props.excluirFunciones !== "undefined")
            for (let excluye of this.props.excluirFunciones) {
                let excluirMenu = itemsIniciales.findIndex(menu => menu.label === excluye);
                itemsIniciales.splice(excluirMenu, 1);
            }

        this.state = {
            items: itemsIniciales.concat(props.herramientasComplementarias)
        };
    }
    render() {
        return (
            <React.Fragment>
                <Menubar model={this.state.items} style={{ textAlign: 'right' }}>
                    <div>
                        {this.props.validacion &&
                            <React.Fragment>
                                <Button label={"Incorrecto ( " + this.props.validacionIncorrecto.toString() + " %)"}
                                    icon="pi pi-times" onClick={this.props.filtrarIncorrectos}
                                    className="p-button-secondary"
                                    style={{ borderColor: 'white', backgroundColor: 'white' }}>
                                </Button>

                                <Button label={"Correcto ( " + this.props.validacionCorrecto.toString() + " %)"}
                                    icon="pi pi-check" onClick={this.props.filtrarCorrectos}
                                    className="p-button-secondary"
                                    style={{ borderColor: 'white', backgroundColor: 'white' }}>
                                </Button> 
                                {(typeof this.props.accionesValidacion !== "undefined") ?
                                    this.props.accionesValidacion.map(registro => {
                                        return (
                                            <Button label={registro.etiqueta} icon={registro.icono}
                                                onClick={registro.accion} model={this.items} className="p-button-secondary"
                                                style={{ borderColor: 'white', backgroundColor: 'white' }}>
                                            </Button>);
                                    })
                                    : ""}
                            </React.Fragment>}
                    </div>
                </Menubar>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        validacionCorrecto: state.validacion.validacionCorrecto,
        validacionIncorrecto: state.validacion.validacionIncorrecto
    };
}

export default connect(mapStateToProps)(MenuBarComponent);
