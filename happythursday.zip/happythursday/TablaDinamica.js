import React, { useRef, useEffect } from 'react';
import "jspdf-autotable";
import MenuBarComponent from './MenuBarComponent';
import CsvDownloader from 'react-csv-downloader';
import 'react-notifications/lib/notifications.css';
import ExportacionExcel from './exportacion/ExportacionExcel';
import ExportacionPdf from './exportacion/ExportacionPdf';
import ExportacionCsv from './exportacion/ExportacionCsv';
import MTableEditRow2 from './MTableEditRow';
import MTableToolBar from './MTableToolbar';
import moment from 'moment';
import VentanaModalCsv from './VentanaModalCsv';
import VentanaModal from '../../comun/VentanaModal';
import { Formik, Field, getIn } from "formik";
import MTableEditField from "./m-table-edit-field";
import MaterialTable from "material-table";
import { createMuiTheme, makeStyles, ThemeProvider } from '@material-ui/core/styles';
import { zhCN } from '@material-ui/core/locale';
import MomentUtils from '@date-io/moment';
import "moment/locale/es";
import { MuiPickersUtilsProvider, } from '@material-ui/pickers';
import Grid from '@material-ui/core/Grid';
import MTableActions from './MTableActions';
import NativeSelect from '@material-ui/core/NativeSelect';
import { useDispatch } from "react-redux";
import actualizarBreadCrumb from '../../../../../redux/actions/actualizarBreadCrumb';
import {actualizar} from '../../../../../redux/actions/actualizarFecha';
import CircularProgress from '@material-ui/core/CircularProgress';
import Helper from './helper/Helper';
import MTableAction from './MTableAction';
import spinner from '../../../../recursos/spinner.gif';

const { forwardRef, useImperativeHandle } = React;
const TablaDinamica = forwardRef((props, ref) => {
    const useStyles = makeStyles(theme => ({
        palette: {
            primary: {
                main: 'blue',
                light: 'yellow',
                dark: 'green',
            },
            secondary: {
                main: 'red',
            },
        },
        table: {
            '& tbody>.MuiTableRow-root:hover': {
                background: '#f6f8f9',
            }
        },
        select: {
            '& option:hover': {
                backgroundColor: '#f6f8f9 !important',
            }
        }
    }));
    const dispatch = useDispatch();
    const classes = useStyles();
    const tableRef = useRef();
    const [separador, setSeparador] = React.useState(",");
    const [mostrarSpinner, setSpinner]=React.useState(false);
    const [fechas, setFechas] = React.useState({});
    const modalCsvRef = useRef();
    const ventanaModalRef = useRef();
    const [componenteModal, setComponenteModal] = React.useState(null);
    const countRef = useRef(props);
    const componentRef = useRef();
    const componentRef2 = useRef();  
    const [state, setState] = React.useState({
        assemble: false,
        columns: (typeof props.parametros.paginacionRemota==="undefined")?props.parametros.cabecera:[],
        csvColumns: ObtenerColumnasCsv(),
        nombreArchivo: props.parametros.nombreArchivo,
        data: [],
        temporalData:[],
        csvdata: [],
        mostrarFechas:false
    });
    const [filaSeleccionada, setFilaSeleccionada] = React.useState(null);
    countRef.current = props;
    useImperativeHandle(ref, () => ({
        actualizarFecha() {
            actualizarFecha();
        },
        refrescar() {
            obtenerInformacion();
        },
        obtenerFilasRegistradas() {
            return state.data;
        },
        exportarExcel(){
            excelExportAction();
        },
        actualizarRegistro(registroAnterior, registroNuevo) {
            if (registroAnterior) {
                setState(prevState => {
                    let data = [...prevState.data];
                    data[data.indexOf(registroAnterior)] = registroNuevo;
                    data = Helper.formatear(data);
                    return { ...prevState, data };
                });
            }
        },
    }));
    useEffect(() => {
        if(props.parametros.componente!=="ComponenteDinamico")
        dispatch(actualizarBreadCrumb(props.parametros.componente));
        obtenerInformacion();

        if (typeof props.parametros.fechas!=="undefined"){
            setFechas(props.parametros.fechas);
            setState(prevState => {
                let mostrarFechas = true;
                return { ...prevState, mostrarFechas };
            });
        }
    }, []);
    const FormikMTInput = props => {

        return (
            <Field name={props.columnDef.field}>
                {({ field, form }) => {
                    const { name } = field
                    const { errors, setFieldValue } = form
                    const showError = !!getIn(errors, name)
                    return (
                        <div>
                            <MTableEditField
                                {...props}
                                {...field}
                                error={showError}
                                onChange={newValue =>{
                                    setFieldValue(name, newValue);
                                    if(typeof props.columnDef.onChange!=="undefined"){
                                                    props.columnDef.onChange(newValue);
                                    }
                                    
                                }
                                }
                            />
                            {errors[field.name] && (
                                <div style={{ color: "#f44336" }}>{errors[field.name]}</div>
                            )}
                        </div>
                    )
                }}
            </Field>
        )
    }
    const theme = createMuiTheme({
        palette: {
            primary: {
                main: '#000000',
              },
              secondary: {
                main: '#000000',
              },
        }
    }, zhCN);

    const editarColumna = ({ onEditingApproved, ...props }) => {
        if (typeof props.data === 'undefined') props.data ={ esActivo: true};
        return (
            <Formik
                validationSchema={extraerObjeto(props.data)}
                initialValues={props.data}
                onSubmit={values => {
                    if (JSON.stringify(values) !== JSON.stringify(props.data)) {
                        delete values.tableData
                    }
                    onEditingApproved(props.mode, values, props.data)
                }}>
                {({ submitForm }) => (
                    <MTableEditRow2 {...props} onEditingApproved={submitForm} />
                )}
            </Formik>
        )
    }
    function extraerObjeto(objeto) {
        if (props.parametros.extraerObjeto !== "Jerarquía de Oficina"
            || props.parametros.componente === "Tasa Valor"
            || props.parametros.componente === "Cotiza Canje"
            || props.parametros.componente === "ModeloPlazoPitValor"
            || props.parametros.componente === "ModeloAsignacionProductoValor"
            || props.parametros.activarValidacionMixta)
            return props.parametros.objetoValidacion(objeto, state.data);
        return props.parametros.objetoValidacion();
    }
    function ObtenerColumnasCsv() {
        let columnasCsv = [];
        props.parametros.cabecera.forEach(columna => {
            if(columna.title!==""){
            columnasCsv.push({
                id: columna.field,
                displayName: columna.title
            });
        }
        }
        );
        return columnasCsv;
    }
    const [spinnerActive, setSpinnerActive] = React.useState(true);
    async function actualizarFecha(){
        const fechasTemporales=await props.parametros.actualizarFecha();
        setFechas(fechasTemporales);
        props.parametros.obtenerInformacion(fechasTemporales.ultimo).then(response => {
            const data = response.data;
            setState(prevState => {
                return { ...prevState, data };
            });
        }
        );
    }
    function obtenerInformacion() {

        if(typeof props.parametros.paginacionRemota!=="undefined")
        {
            const objetoPaginacion=props.parametros.obtenerInformacion();
            const data=query =>
            new Promise((resolve, reject) => {
              let url=objetoPaginacion.obtenerSubdetalleUrl(query.page,query.pageSize);
              fetch(url)
                .then(response => response.json())
                .then(result => {
                    let columns=objetoPaginacion.obtenerSubdetalleCabecera(result.metadataDetalleLista);
                    setState(prevState => {
                        return { ...prevState, columns };
                    });
                  resolve({
                    data: result.registroEtlLista,
                    page: query.page,
                    totalCount: objetoPaginacion.totalRegistros,
                  })
                })
            });
            setState(prevState => {
                return { ...prevState, data };
            });
        }
        else
        {setSpinner(true);
        if (props.parametros.componente === "test") {
            const data = props.parametros.obtenerInformacion();
            setState(prevState => {
                return { ...prevState, data };
            });
            setSpinner(false);
        } else if (props.parametros.componente === "Cotiza Canje"
            || props.parametros.componente === "Tasa Valor"
            || props.parametros.componente === "Selecci\u00F3n Cost Driver"
            || props.parametros.componente === "ModeloAsignacionProductoValor"
            || props.parametros.componente === "Asignaci\u00f3n Patrimonio Valor"
        ) {
            props.parametros.obtenerInformacion().then(response => {
                let data = response.data;
                data = Helper.formatear(data);
                setState(prevState => {
                    return { ...prevState, data };
                });
                setSpinner(false);
            }
            );
        } else {
            let obtenerInformacionPromesa=props.parametros.obtenerInformacion();
            if (Array.isArray(obtenerInformacionPromesa))
            {
                const data = obtenerInformacionPromesa;
                setState(prevState => {
                    return { ...prevState, data };
                });
                setSpinner(false);
            }
            else
            obtenerInformacionPromesa.then(response => {
                if(typeof response!=="undefined"){
                let data = response.data;
                if (typeof props.parametros.filtroPersonalizado !== "undefined") 
                {
                    data = props.parametros.filtroPersonalizado(data);
                }
                if (typeof props.parametros.seleccionInicial !== "undefined") {
                    let newData = [];
                    (async () => {
                        const object = await props.parametros.seleccionInicial();
                        let codigos = [];
                        object.data.forEach(item => {
                            codigos.push(item.producto.codigo);
                        });
                        data.forEach(record => {
                            if (codigos.includes(record.codigo)) record.tableData = { checked: true };
                            newData.push(record);
                        });
                        data = newData;
                        setState(prevState => {
                            return { ...prevState, data };
                        });
                    })();
                } else {
                    setState(prevState => {
                        return { ...prevState, data };
                    });
                }
                setSpinner(false);
               }
               else{
                setSpinner(false);
                let data = [];
                setState(prevState => {
                    return { ...prevState, data };
                });
               }
            }
            );
        }

    }
    }

    function excelExportAction() {
        ExportacionExcel.descargarExcel(props.parametros, state.columns, state.data);
    }

    function pdfExportAction() {
        var promise = new Promise((resolve, reject) => {
            var temporalData=[];
            temporalData=state.data;
            ExportacionPdf.descargarPdf(props.parametros, state.columns, temporalData);
            resolve();
        });
        promise.then(result => {
        }, function (error) {

        });
    }

    function Imprimir() {
       var promise = new Promise((resolve, reject) => {
        ExportacionPdf.descargarPdf(props.parametros, state.columns, state.data,true);
        resolve();
    });
    promise.then(result => {
    }, function (error) {

    });     
        
    }

    async function extraerCsv(separador_tmp) {
        await new Promise((resolve, reject) => {
            setSeparador(separador_tmp);
            resolve();
        });
        let csvdata = ExportacionCsv.descargarCsv(props.parametros,state.columns, state.data);
        setState(prevState => {
            return { ...prevState, csvdata };
        });
        var linkToClick = document.getElementById(props.parametros.componente + 'csv_download');
        linkToClick.click();

    }

    function csvExportAction() {
        modalCsvRef.current.abrirVentana();
    }

    function accionCopiado() {
        setComponenteModal(() => {
            return props.parametros.copiarComponente.componente
        });
        ventanaModalRef.current.abrirVentana(
            0,
            props.parametros.copiarComponente.titulo,
            [
                {
                    nombre: "Copiar", accion: () => {
                        props.parametros.copiarComponente.callBack();
                    }, cerrarVentana: props.parametros.copiarComponente.cerrarVentana
                }
            ]
        );
    }

    function accionImportarExcel() {
        setComponenteModal(() => {
            return props.parametros.logicaImportar.componente
        });
        ventanaModalRef.current.abrirVentana(
            0,
            props.parametros.logicaImportar.titulo,
            [
                {
                    nombre: "Importar", accion: () => {
                        props.parametros.logicaImportar.callBack();
                        obtenerInformacion();
                        ventanaModalRef.current.cerrarVentana();
                    }
                }
            ]
        );
    }

    function nuevoRegistroAccion() {
        document.querySelector("[data-mycustomid='" + state.nombreArchivo + "']").parentNode.click()
    }

    const handleChange = (event) => {
        dispatch(actualizar.actualizarFechaOrigen({ fechaOrigen: event.target.value }));
        props.parametros.obtenerInformacion(event.target.value).then(response => {
            const data = response.data;
            setState(prevState => {
                return { ...prevState, data };
            });
        }
        );
    };
    function obtenerModales(componente,botones,titulo) {
        setComponenteModal(() => {
            return componente
        });
        ventanaModalRef.current.abrirVentana(
            0,
            titulo,
            botones
        );
    }
    function obtenerHerramientasComplementarias(){
        let herramientas=[];
        if(typeof props.parametros.herramientasComplementarias!=="undefined"){

            props.parametros.herramientasComplementarias.forEach(registro=>{
                if(registro.callback==="function")registro.icono.command=()=>{registro.callback();}
                else registro.icono.command=()=>{obtenerModales(registro.componente,registro.botones,registro.titulo);};
                herramientas.push(registro.icono);
            });

        }
        return herramientas;
    }
    function obtenerAccionesValidacion(){
        let acciones=[];
        if(typeof props.parametros.accionesValidacion!=="undefined"){
            props.parametros.accionesValidacion.forEach(registro=>{
                const temp={};
                temp.accion=()=>{obtenerModales(registro.componente,registro.botones,registro.titulo);};
                temp.icono=registro.icono;
                temp.etiqueta=registro.etiqueta;
                acciones.push(temp);
            });
        }
        return acciones;
    }
    function filtrarCorrectos()
    {
        if(typeof props.parametros.correctos!=="undefined"){
            if(state.temporalData.length===0){
                setState(prevState => {
                    let temporalData = state.data;
                    return { ...prevState, temporalData};
                });
                setState(prevState => {
                    let data = state.data.filter(registro=>
                        props.parametros.correctos.includes(registro.codigo)
                    );
                    return { ...prevState, data};
                });

            }
            else{
                setState(prevState => {
                    let data = state.temporalData.filter(registro=>
                        props.parametros.correctos.includes(registro.codigo)
                    );
                    return { ...prevState, data};
                });               

            }
        }
        if(typeof props.parametros.incorrectos!=="undefined"){
            if(state.temporalData.length===0){
                setState(prevState => {
                    let temporalData = state.data;
                    return { ...prevState, temporalData};
                });
                setState(prevState => {
                    let data = state.data.filter(registro=>
                        !props.parametros.incorrectos.includes
                        (typeof props.parametros.customField!=="undefined"
                        ?eval("registro."+props.parametros.customField):registro.codigo
                        )
                    );
                    return { ...prevState, data};
                });

            }
            else{
                setState(prevState => {
                    let data = state.temporalData.filter(registro=>
                        !props.parametros.incorrectos.includes
                        (typeof props.parametros.customField!=="undefined"
                        ?eval("registro."+props.parametros.customField):registro.codigo
                        )
                    );
                    return { ...prevState, data};
                });               

            }
        }
    }
    function filtrarIncorrectos()
    {
        if(typeof props.parametros.correctos!=="undefined"){
            if(state.temporalData.length===0){
                setState(prevState => {
                    let temporalData = state.data;
                    return { ...prevState, temporalData};
                });
                setState(prevState => {
                    let data = state.data.filter(registro=>
                        !props.parametros.correctos.includes(registro.codigo)
                    );
                    return { ...prevState, data};
                });

            }
            else{
                setState(prevState => {
                    let data = state.temporalData.filter(registro=>
                        !props.parametros.correctos.includes(registro.codigo)
                    );
                    return { ...prevState, data};
                });               

            }
        }
        if (typeof props.parametros.incorrectos!=="undefined"){
            if(state.temporalData.length===0){
                setState(prevState => {
                    let temporalData = state.data;
                    return { ...prevState, temporalData};
                });
                setState(prevState => {
                    let data = state.data.filter(registro=>
                        props.parametros.incorrectos.includes
                        (typeof props.parametros.customField!=="undefined"
                        ?eval("registro."+props.parametros.customField):registro.codigo
                        )
                    );
                    return { ...prevState, data};
                });

            }
            else{
                setState(prevState => {
                    let data = state.temporalData.filter(registro=>
                        props.parametros.incorrectos.includes
                        (typeof props.parametros.customField!=="undefined"
                        ?eval("registro."+props.parametros.customField):registro.codigo
                        )
                    );
                    return { ...prevState, data};
                });               

            }
        }
    }
    return (
        <React.Fragment>
            {props.parametros.activarToolBar &&
                <MenuBarComponent excluirFunciones={props.parametros.excluirFunciones}
                    nuevoRegistroAccion={nuevoRegistroAccion} accionImportarExcel={accionImportarExcel}
                    excelExportAction={excelExportAction} pdfExportAction={pdfExportAction}
                    csvExportAction={csvExportAction} Imprimir={Imprimir}
                    accionCopiado={accionCopiado} validacion={props.parametros.validacion} 
                    herramientasComplementarias={obtenerHerramientasComplementarias()}
                    accionesValidacion={obtenerAccionesValidacion()}
                    filtrarCorrectos={filtrarCorrectos}
                    filtrarIncorrectos={filtrarIncorrectos}
                    />}

            <MuiPickersUtilsProvider utils={MomentUtils} locale="es">
                {((props.parametros.componente === "Distribuci\u00F3n OverHead Cost Driver Valor" ||
                    props.parametros.componente === "DistribucionOverHeadCostDriverValor" ||
                    props.parametros.componente === "Distribuci\u00F3n a Producto Cost Driver Valor")&&state.mostrarFechas) &&
                    <React.Fragment>
                        <Grid container spacing={3}>
                            <Grid item xs={3}>
                                <NativeSelect
                                    defaultValue={fechas.ultimo}
                                    inputProps={{ name: 'name', id: 'uncontrolled-native' }}
                                    onChange={handleChange}>
                                    {fechas.registros.map(registro =>
                                        <option value={registro.codigo}>{registro.fecha}</option>
                                    )}
                                </NativeSelect>
                            </Grid>
                            <Grid item xs={6}>
                            </Grid>
                        </Grid>
                    </React.Fragment>
                }
            </MuiPickersUtilsProvider>

            <VentanaModalCsv extraerCsv={extraerCsv} ref={modalCsvRef} />

            {(typeof props.parametros.acciones !== "undefined" || typeof props.parametros.copiarComponente !== "undefined" 
            || typeof props.parametros.logicaImportar !== "undefined"||
               typeof props.parametros.herramientasComplementarias!== "undefined") &&
                <VentanaModal ref={ventanaModalRef} componente={componenteModal} refrescarComponente={obtenerInformacion} />
            }
            <div className={classes.table}>
                <ThemeProvider theme={theme}>
                    {mostrarSpinner?
                    <img src={spinner} width="40px" />:
                        <div>
                            <MaterialTable size="small"
                                detailPanel={typeof props.parametros.filaExpandible !== "undefined" ? 
                                props.parametros.filaExpandible.accion : false}
                                icons={{
                                    Add: props => (<div data-mycustomid={state.nombreArchivo} />)
                                }}
                                title=""
                                loading={true}
                                tableRef={tableRef}
                                columns={state.columns}
                                data={state.data}
                                searchFieldAlignment='left'
                                onRowClick={(evt, fila) => {
                                    setFilaSeleccionada(fila.tableData.id);
                                    if (typeof props.parametros.clickFila === "function")
                                        props.parametros.clickFila(evt, fila);
                                }}
                                onSelectionChange={(typeof props.parametros.seleccionRegistro !== 'undefined') ? props.parametros.seleccionRegistro.accion : () => {
                                }}
                                options={Helper.obtenerOpcionesTabla(filaSeleccionada,props.parametros)}
                                localization={Helper.obtenerLocalizacionTabla()}
                                actions={typeof props.parametros.excluirFunciones !== "undefined" ? (props.parametros.excluirFunciones.indexOf("editable") > -1) ? [] :
                                    Helper.obtenerAcciones(props.parametros.acciones,ventanaModalRef,setComponenteModal) : []}
                                components={{
                                    EditRow: editarColumna,
                                    EditField: FormikMTInput,
                                    Actions: MTableActions,
                                    Action: props2=>
                                    (<MTableAction accionesGenerales={typeof props.parametros.accionesGenerales!=="undefined"?props.parametros.accionesGenerales:null} {...props2} />
                                    ),
                                    Toolbar: props => (
                                        <MTableToolBar {...props} />
                                    )
                                }}
                                editable={typeof props.parametros.excluirFunciones !== "undefined" ? (props.parametros.excluirFunciones.indexOf("editable") > -1) ? {} : {
                                    cellStyle: {
                                        textAlign: 'center',
                                        padding: 0,
                                        margin: 0
                                    },
                                    onRowAdd: Helper.obtenerAccionInsertar(props.parametros,setState),
                                    onRowUpdate: (typeof props.parametros.botonesEdicion != "undefined") ? props.parametros.botonesEdicion.editar ?  Helper.obtenerAccionActualizar(props.parametros,setState): false : false,
                                    onRowDelete: (typeof props.parametros.botonesEdicion != "undefined") ? props.parametros.botonesEdicion.eliminar ?  Helper.obtenerAccionEliminar(props.parametros,setState): false : false,
                                } : {}}
                            />
                        </div>
                        }
                </ThemeProvider>
            </div>

            <CsvDownloader
                filename={props.parametros.nombreArchivo + "_" + moment().format("DD-MM-YYYY").toString() + ".csv"}
                separator={separador}
                columns={state.csvColumns}
                datas={state.csvdata}>
                <div id={props.parametros.componente+"csv_download"}></div>
            </CsvDownloader>
        </React.Fragment>
    );
});
export default TablaDinamica;