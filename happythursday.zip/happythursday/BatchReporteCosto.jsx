import React, { Component, createRef } from 'react';
import TablaDinamica from '../../comun/TablaDinamica/TablaDinamica';
import Grid from '@material-ui/core/Grid';
import { Panel } from 'primereact/panel';
import { connect } from 'react-redux';
import BatchServicio from '../../../../api/BatchServicio';
import { NotificationManager } from 'react-notifications';
import MensajeEjecutar from './MensajeEjecutar';

class BatchReporteCosto extends Component {
    constructor(props) {
        super(props);
        this.detalleRef = new createRef();
        this.resumenRef = new createRef();
        this.state = {
            treeData: [],
            selectedNodeKey: null,
            mostrarOperaciones: false,
            nodoSeleccionado: null,
            operaciones: [],
            mostrarSubdetalle: false,
            subdetalleCabecera: [],
            contenidoSubdetalle: [],
            detalle: [],
            mostrarDetalle: true
        };
    }

    obtenerObjetoValidacion = () => {
        return [];
    }
    obtenerParametros = () => {
        const parametros = {
            cabecera: this.state.subdetalleCabecera,
            componente: 'ComponenteDinamico',
            obtenerInformacion: () => { return this.state.contenidoSubdetalle; },
            objetoValidacion: this.obtenerObjetoValidacion(),
            nombreArchivo: "componente_dinamico",
            excluirFunciones: ["Copiar", "Importar", "Imprimir"],
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false
        };
        return parametros;
    }

    obtenerCabeceraDetalle = () => {
        const cabecera = [
            { title: 'Tipo', field: 'tipo' },
            { title: 'Nombre Esquema', field: 'tipoEsquema.nombre' }
        ];
        return cabecera;
    }
    ObtenerParametrosDetalle = () => {
        const parametros = {
            herramientasComplementarias: [
                {
                    icono: {
                        label: 'Ejecutar',
                        icon: 'pi pi-config'
                    },
                    callback: () => {
                        const registro =
                        {
                            "solicitudUnica": {
                                "codigo": this.state.nodoSeleccionado
                            },
                            "descripcion": "Mensaje de Prueba"
                        };
                        const ejecucion = BatchServicio.obtenerReporteBatchCostoEjecutar(registro);
                        ejecucion.then(resultado => {
                            this.detalleRef.current.refrescar();
                            NotificationManager.success(`Ejecucion Iniciada`);
                        }, error => {
                            NotificationManager.error('Error', "Ha ocurrido un error. Intente nuevamente", 5000, () => { })
                        });
                    }
                },
                {
                    icono: {
                        label: 'Ejecutar',
                        icon: 'pi pi-config'
                    },
                    componente: props => (
                        <MensajeEjecutar {...props} render={true} componenteBase={this.state.nodoSeleccionado} />
                    ),
                    botones: [
                        {
                            nombre: "Ejecutar",
                            accion: () => {
                                const registro =
                                {
                                    "solicitudUnica": {
                                        "codigo": this.state.nodoSeleccionado
                                    },
                                    "descripcion": this.props.generalJson.json.codigo
                                };
                                const ejecucion = BatchServicio.obtenerReporteBatchCostoEjecutar(registro);
                                ejecucion.then(resultado => {
                                    this.detalleRef.current.refrescar();
                                    NotificationManager.success(`Ejecucion Iniciada`);
                                }, error => {
                                    NotificationManager.error('Error', "Ha ocurrido un error. Intente nuevamente", 5000, () => { })
                                });
                            },
                            cerrarVentana: true,
                        }
                    ],
                    titulo: "Ejecutar"
                },
                {
                    icono: {
                        label: 'Actualizar',
                        icon: 'pi pi-refresh'
                    },
                    callback: () => {
                        const actualizar = BatchServicio.obtenerReporteBatchCostoActualizar(this.state.nodoSeleccionado);
                        actualizar.then(resultado => {
                            this.detalleRef.current.refrescar();
                        }, error => {
                            NotificationManager.error('Error', "Ha ocurrido un error. Intente nuevamente", 5000, () => { })
                        });
                    }
                }
            ],
            cabecera: this.obtenerCabeceraDetalle(),
            componente: 'ComponenteDinamico',
            obtenerInformacion: BatchServicio.obtenerReporteBatchCostoResumen,
            objetoValidacion: this.obtenerObjetoValidacion,
            clickFila: (evt, selectedRow) => {

                this.setState({
                    mostrarSubdetalle: false,
                    nodoSeleccionado: selectedRow.codigo
                },
                    () => {
                        this.setState({ mostrarSubdetalle: true }, () => {
                            this.detalleRef.current.refrescar();
                        });
                    });
            },
            estiloSeleccion: true,
            nombreArchivo: "componente_dinamico",
            excluirFunciones: ["Copiar", "Importar", "Imprimir", "Exportar"],
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: true,
            toolbar: false,
            search: false,
            paging: false
        };
        return parametros;
    }
    shouldComponentUpdate(nextProps, nextState) {
        if (this.props.breadcrumb.breadcrumb !== nextProps.breadcrumb.breadcrumb) {
            this.setState(
                {
                    mostrarSubdetalle: false
                }, () => {
                    this.iniciarOperaciones(this.obtenerCodigoComponente(nextProps.breadcrumb.breadcrumb));
                }
            );
        }
        return true;
    }
    obtenerCabeceraSubDetalle = () => {
        const cabecera = [
            { title: 'Fecha Proceso', field: 'fechaProceso' },
            { title: 'Descripción', field: 'descripcion' },
            { title: 'Duración', field: 'duracion' },
            {
                title: 'Estado', field: 'estado',
                lookup: { 1: 'En Proceso', 2: 'Finalizado', 3: 'Error' }
            },
            { title: 'Mensaje', field: 'mensaje' }   //Pendiente de revision 
        ];
        return cabecera;
    }
    ObtenerParametrosSubDetalle = () => {
        const parametros = {
            cabecera: this.obtenerCabeceraSubDetalle(),
            componente: 'ComponenteDinamico',
            obtenerInformacion: () => {
                return BatchServicio.obtenerReporteBatchCostoDetalle(this.state.nodoSeleccionado);
            },
            objetoValidacion: this.obtenerObjetoValidacion(),
            nombreArchivo: "componente_dinamico",
            excluirFunciones: ["Copiar", "Importar"],
            botonesEdicion: { editar: false, eliminar: false },
            activarToolBar: false,
            toolbar: false,
            search: false,
            paging: false
        };
        return parametros;
    }
    render() {
        return (
            <React.Fragment>
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        <Panel header="Resumen">
                            {this.state.mostrarDetalle &&
                                <TablaDinamica ref={this.resumenRef} parametros={this.ObtenerParametrosDetalle()} />
                            }
                        </Panel>
                        <Panel header="Detalle">
                            {this.state.mostrarSubdetalle &&
                                <TablaDinamica ref={this.detalleRef} parametros={this.ObtenerParametrosSubDetalle()} />
                            }

                        </Panel>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        breadcrumb: state.breadcrumb,
        generalJson: state.generalJson
    };
}

const mapDispatchToProps = {
}


export default connect(mapStateToProps, mapDispatchToProps)(BatchReporteCosto);