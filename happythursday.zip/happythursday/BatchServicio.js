import axios from 'axios';
import { JPA_API_URL } from '../../Constantes';

class BatchServicio {
    /*********************BATCH COSTOS **************************************/
    obtenerFechasCostos=()=>{
        return axios.get(`${JPA_API_URL}/costos/fechaPresupuestada/lista`);
    }
    insertarFechaCostos=(fecha)=>{
        const registro={
            "codigo": fecha,
            "login": "lm"
        };
        return axios.post(`${JPA_API_URL}/costos/procesoBatchCosto/insertarCombinaCosto`, registro);
    }
    obtenerCabeceraCostos=()=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchCosto/listaCombinaCosto`);
    }
    obtenerCostoDetalle=(fecha)=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchCosto/listaCombinaCostoDetalle/${fecha}`);
    }
    ejecutarBatchCosto=(fechaPropuesta)=>{
        const registro={
            fechaPropuesta,
            "descripcion": "prueba 4",
            "login": "lm"
          };
        return axios.post(`${JPA_API_URL}/costos/procesoBatchCosto/ejecutarBatchCosto`,registro);
    }
    actualizarBatchCosto=(fecha)=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchCosto/actualizarBatchCosto/${fecha}`);
    }
    /*****************Fin Operaciones ************************************/

    /*********************BATCH Rentabilidad **************************************/
    obtenerFechasRentabilidad=()=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchRentabilidad/listaGeneraRentabilidad`);
    }
    obtenerRentabilidadDetalle=(fecha)=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchRentabilidad/listaGeneraRentabilidadDetalle/${fecha}`);
    }
    ejecutarBatchRentabilidad=()=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchRentabilidad/ejecutarBatchRentabilidad`);
    }
    actualizarBatchRentabilidad=(fecha)=>{
        return axios.get(`${JPA_API_URL}/costos/procesoBatchRentabilidad/actualizarBatchRentabilidad/${fecha}`);
    }
    /*****************Fin Operaciones ************************************/



    /*********************REPORTE BATCH COSTO **************************************/
    obtenerReporteBatchCostoResumen=()=>{
        return axios.get(`${JPA_API_URL}/costos/solicitudUnica/listaSolicitudUnica`);
    }
    obtenerReporteBatchCostoDetalle=(codigo)=>{
        return axios.get(`${JPA_API_URL}/costos/solicitudUnica/listaSolicitudUnicaDetalle/${codigo}`);
    }
    obtenerReporteBatchCostoEjecutar=(registro)=>{
        return axios.post(`${JPA_API_URL}/costos/reporteBatchCosto/ejecutarBatchReporte`,registro);
    }
    obtenerReporteBatchCostoActualizar=(codigo)=>{
        return axios.get(`${JPA_API_URL}/costos/solicitudUnica/actualizarBatchReporte/${codigo}`);
    }

    /*****************Fin REPORTE BATCH COSTO ************************************/

}
export default new BatchServicio();

