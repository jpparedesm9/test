import React, { Component } from 'react';
import TablaDinamica from '../comun/TablaDinamica/TablaDinamica';
import BimCrud from '../../../api/BimCrud';
import * as Yup from 'yup';
import mensajes from "../../../global/Mensajes";

let msn = mensajes();
class Etiquetas extends Component {
    constructor(props){
        super(props);
        this.state={
            cabecera:[
                { title: msn.msnNombre, field: 'nombre'},
                { title: msn.msnDescripcion, field: 'descripcion' },
                { title: "Tipo", field: 'tipo'},
                {title: msn.msnActivo, field: 'esActivo', type: 'boolean',
                cellStyle: {
                    textAlign: 'center'
                }}
            ]
        }
    }

    obtenerObjetoValidacion=()=>{
        return [];
    }

    obtenerParametros=()=>{
        const parametros={
            cabecera:this.state.cabecera,
            componente:'Etiquetas',
            nuevoRegistro:(registro)=>{return BimCrud.RegistrarJerarquiaDeOFicina(registro)},
            editarRegistro:(registroanterior,registro)=>{return BimCrud.ActualizarJerarquiaDeOFicina(registro)}, 
            eliminarRegistro:(registro)=>{return BimCrud.EliminarJerarquiaDeOFicina(registro)},
            obtenerInformacion:()=>{
                const informacion=[
                {nombre:"Nombre",descripcion:"Descripcion",tipo:"RML",esActivo:true},
                {nombre:"Nombre1",descripcion:"Descripcion 2",tipo:"RML2",esActivo:false},
                {nombre:"Nombre2",descripcion:"Descripcion 3",tipo:"RML3",esActivo:true},
                {nombre:"Nombre3",descripcion:"Descripcion 4",tipo:"RML3",esActivo:false},
                ];
                return informacion;
            },
            objetoValidacion:(objeto,registros)=>{return this.obtenerObjetoValidacion(objeto,registros)},
            excluirFunciones:["Copiar","Importar"],
            nombreArchivo:"jerarquía_de_oficina",
            botonesEdicion:{editar:true,eliminar:false},
            activarToolBar:true,
            validarObjeto: true
        };
        return parametros;
    }
    render() {
        return (
            <div>
            <TablaDinamica parametros={this.obtenerParametros()}/>
            </div>
        );
    }
}

export default Etiquetas;
