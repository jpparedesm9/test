import React from 'react';
import List from '@material-ui/core/List';

import HomeWorkIcon from '@material-ui/icons/HomeWork';
import EventSeatIcon from '@material-ui/icons/EventSeat';
import PhonelinkSetupIcon from '@material-ui/icons/PhonelinkSetup';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import AccountBalanceIcon from '@material-ui/icons/AccountBalance';
import PublicIcon from '@material-ui/icons/Public';
import LocationCityIcon from '@material-ui/icons/LocationCity';
import AssignmentIndIcon from '@material-ui/icons/AssignmentInd';
import TouchAppIcon from '@material-ui/icons/TouchApp';
import EmojiSymbolsIcon from '@material-ui/icons/EmojiSymbols';
import DeviceHubIcon from '@material-ui/icons/DeviceHub';
import '../../../recursos/Style.css';
import { makeStyles} from '@material-ui/core/styles';
import mensajes from "../../../global/Mensajes";
import TrendingUpIcon from '@material-ui/icons/TrendingUp';
import EnsamblaMenu from "../../submodulos/comun/EnsamblaMenu";
import VerificarRuta from "../../../api/VerificarRuta";

let msn = mensajes();
const useStyles = makeStyles(theme => ({
  listItem: {
    "&$selected, &$selected:hover, &$selected:focus": {
      backgroundColor: "#ffffff",
      color: "#000000"
    }
  },
  selected: {},
  root: {
    display: 'flex',
  },
}));

export default function MainDrawer(props) {
  const classes = useStyles();
  const [selectedIndex, setSelectedIndex] = React.useState(null);

  const handleListItemClick = (event, index) => {
    setSelectedIndex(index);
  };
  const menus = [
    { url: "/submenu/bim/office_jerarqui", key: "jerarqui", icono: <HomeWorkIcon style={{color:(selectedIndex === 0)?"#000000":'#ffffff'}}/>, msn: msn.msnjerarquia_oficina },
    { url: "/submenu/bim/fuente_de_informacion", key: "information_source2", icono: <PhonelinkSetupIcon style={{color:(selectedIndex === 1)?"#000000":'#ffffff'}}/>, msn: msn.msnfuente_informacion },
    { url: "/submenu/bim/moneda", key: "coin1", icono: <MonetizationOnIcon style={{color:(selectedIndex === 2)?"#000000":'#ffffff'}}/>, msn: "Moneda" },
    { url: "/submenu/bim/compania", key: "company2", icono: <AccountBalanceIcon style={{color:(selectedIndex === 3)?"#000000":'#ffffff'}}/>, msn: "Compañía" },
    { url: "/submenu/bim/region_geografica", key: "geographic_region", icono: <PublicIcon style={{color:(selectedIndex === 4)?"#000000":'#ffffff'}}/>, msn: "Región Geográfica" },
    { url: "/submenu/bim/localidad", key: "geographic_region", icono: <LocationCityIcon style={{color:(selectedIndex === 5)?"#000000":'#ffffff'}}/>, msn: "Localidad" },
    { url: "/submenu/bim/funcionario", key: "fn_1", icono: <AssignmentIndIcon style={{color:(selectedIndex === 6)?"#000000":'#ffffff'}}/>, msn: "Funcionario" },
    { url: "/submenu/bim/oficina", key: "office2", icono: <EventSeatIcon style={{color:(selectedIndex === 7)?"#000000":'#ffffff'}}/>, msn: "Oficina" },
    { url: "/submenu/bim/producto_financiero", key: "office56", icono: <EmojiSymbolsIcon style={{color:(selectedIndex === 8)?"#000000":'#ffffff'}}/>, msn: "Producto Financiero" },
    { url: "/submenu/bim/servicio", key: "Servicio122", icono: <TouchAppIcon style={{color:(selectedIndex === 9)?"#000000":'#ffffff'}}/>, msn: "Servicio" },
    { url: "/submenu/bim/canal", key: "lateral_menu3", icono: <DeviceHubIcon style={{color:(selectedIndex === 10)?"#000000":'#ffffff'}}/>, msn: "Canal" },
    { url: "/submenu/bim/tasa_referencial", key: "tasa_referencial2", icono: <TrendingUpIcon style={{color:(selectedIndex === 11)?"#000000":'#ffffff'}}/>, msn: msn.msnTasaRefeferencial },
    { url: "/submenu/bim/etiquetas", key: "tasa_referencial2", icono: <TrendingUpIcon style={{color:(selectedIndex === 11)?"#000000":'#ffffff'}}/>, msn: "Etiquetas" },
    

  ];
  const menusProcesados=menus.filter(item=>VerificarRuta.verificar(item.url));
  return (
    <List key="lista_general">
      <EnsamblaMenu menus={menusProcesados}/>
    </List>
  );
}
