import React, { Component } from 'react';
import TablaDinamica from '../comun/TablaDinamica/TablaDinamica';
import MenuBarComponent from './comun/MenuBarHomologacion';
import Grid from '@material-ui/core/Grid';
import {Panel} from 'primereact/panel';
import {Tree} from 'primereact/tree';
import {connect} from 'react-redux';
import {Menu} from 'primereact/menu';
import EtlServicio from '../../../api/EtlServicio';


const data = [
	{
		key: '0',
		label: 'Homologar Cost Driver Valor',
		data: 'Documents Folder',
		icon: 'pi pi-fw pi-check success_icon'
	}
    ];
const items = [
        {
            label: 'Componente',
            items: [{label: 'Cost Drivers Unidad', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Cost Drivers Producto', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Costos', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Datos de Clientes', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Factor Rentabilidad', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Valor Fren Carga', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Transacción por Canal', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Transacción por Producto', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            {label: 'Operaciones', icon: 'pi pi-fw pi-upload', command:()=>{ }},
            ]
        }
    ];
class Homologacion extends Component {
    constructor(props){
        super(props);
        this.state={
           treeData:[],
           selectedNodeKey:null,
           mostrarOperaciones:false,
           operaciones:[],
           mostrarSubdetalle:false,
           subdetalleCabecera:[],
           contenidoSubdetalle:[],
           detalle:[],
           mostrarDetalle:true
        };
        const operacionesPromise=EtlServicio.ObtenerOperaciones();
        operacionesPromise.then(resultado=>{
            let operaciones=[];
            const informacion=resultado.data;
            let claveRegistro=0;
            informacion.forEach(registro=>{
                const fila={
                    key: claveRegistro,
                    label: registro.nombre,
                    data: 'Documents Folder',
                    icon: registro.estado===1?'pi pi-fw pi-check success_icon':'pi pi-fw pi-times error_icon'
                };
                let hijos=[];
                let subClave=0;
                registro.estadoProcesoLista.forEach(estadoProceso=>{
                    const estado={
                        key: claveRegistro.toString()+"="+subClave.toString(),
                        label: estadoProceso.descripcion,
                        data: 'Work Folder',
                        icon: registro.estado===1?'pi pi-fw pi-check success_icon':'pi pi-fw pi-times error_icon'
                    };
                    hijos.push(estado);
                    subClave=subClave+1;
                });
                if(hijos.length>0)fila.children=hijos;
                operaciones.push(fila);
                claveRegistro=claveRegistro+1;
            });
            this.setState({
                operaciones,
                mostrarOperaciones:true
            }
            );
        }
        );

        const cargarDetalle=EtlServicio.ObtenerDetalles();
        cargarDetalle.then(resultado=>{
            let detalle=[];
            const informacion=resultado.data;
            detalle.push(informacion);
            this.setState({
                detalle,
                mostrarDetalle:true
            }
            );
        }
        );


        const cargarSubdetalle=EtlServicio.ObtenerSubdetalle();
        cargarSubdetalle.then(resultado=>{
            let subdetalleCabecera=[];
            const informacion=resultado.data;
            informacion.metadataEtlLista.forEach(registro=>{
                const columna={title: registro.cabecera, field: registro.campo};
                subdetalleCabecera.push(columna);
            });
            this.setState({
                subdetalleCabecera,
                contenidoSubdetalle:informacion.registroEtlLista,
                mostrarSubdetalle:true
            }
            );
        }
        );

    }

    obtenerObjetoValidacion = () => {
        return [];
    }
    obtenerParametros=()=>
    {
        const parametros={
            cabecera:this.state.subdetalleCabecera,
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{return this.state.contenidoSubdetalle;},
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:false,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false
        };
        return parametros;
    }

    obtenerCabeceraDetalle= () => {
        const cabecera = [
            { title: 'Numerado', field: 'numerado' },
            { title: 'TABLA DE HOMOLOGACIÓN', field: 'tablahomologacion' },
            { title: 'DESCRIPCIÓN TABLA HOMOLOGACIÓN', field: 'descripcion' }
        ];

        return cabecera;
    }
    ObtenerParametrosDetalle=()=>{
        const parametros={
            cabecera:this.obtenerCabeceraDetalle(),
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{
            return ([
            {numerado:1, tablahomologacion:"HG_COMPANIA",descripcion:"HOMOLOGACIÓN DE COMPAÑIAS"},
            {numerado:2, tablahomologacion:"HG_AREA",descripcion:"HOMOLOGACIÓN DE AREAS"},
            {numerado:3, tablahomologacion:"HG_OFICINA",descripcion:"HOMOLOGACIÓN DE OFICINA"},
            {numerado:4, tablahomologacion:"HG_COSTDRIVER",descripcion:"HOMOLOGACIÓN DE COST_DRIVERS"}
            ]);
            },
            objetoValidacion:this.obtenerObjetoValidacion,
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:true,eliminar:false},
            activarToolBar:true,
            toolbar:false,
            search:false,
            paging:false
        };
        return parametros;      
    }

    obtenerCabeceraSubDetalle= () => {
        const cabecera = [
            { title: 'Compañía', field: 'compania' },
            { title: 'CODIGO_AREA', field: 'codigo_area' },
            { title: 'AREA_SI_CODIGO', field: 'area_si_codigo' },
            { title: 'CNIA_BY_CODIGO', field: 'cnia_by_codigo' },
            { title: 'AREA_A2_NOMBRE', field: 'area_a2_nombre' }
        ];

        return cabecera;
    }
    ObtenerParametrosSubDetalle=()=>{
        const parametros={
            cabecera:this.obtenerCabeceraSubDetalle(),
            componente:'ComponenteDinamico',
            obtenerInformacion:()=>{
            return ([
            {compania:"GrupoContext", codigo_area:1,area_si_codigo:31,cnia_by_codigo:1,area_a2_nombre:"OVERHEAD"},
            {compania:"GrupoContext", codigo_area:10,area_si_codigo:32,cnia_by_codigo:1,area_a2_nombre:"LINEA DE NEGOCIO"},
            {compania:"GrupoContext", codigo_area:2,area_si_codigo:32,cnia_by_codigo:1,area_a2_nombre:"LINEA DE NEGOCIO"},
            {compania:"GrupoContext", codigo_area:3,area_si_codigo:33,cnia_by_codigo:1,area_a2_nombre:"SOPORTE A PRODUCTO"},
            {compania:"GrupoContext", codigo_area:64,area_si_codigo:32,cnia_by_codigo:1,area_a2_nombre:"LN"},
            ])
            },
            objetoValidacion:this.obtenerObjetoValidacion(),
            nombreArchivo:"componente_dinamico",
            excluirFunciones:["Copiar","Importar"],
            botonesEdicion:{editar:true,eliminar:false},
            activarToolBar:false,
            toolbar:false,
            search:false,
            paging:false
        };
        return parametros;      
    }
    render() {
        return (
            <React.Fragment>
                <Grid container spacing={1}>
                    <Grid item xs={3}>
                        <Panel header="COST DRIVERS UNIDAD">
                        {this.state.mostrarOperaciones&&
                        <Tree style={{textAlign:'left', border:'0px', width:'200px'}} value={data} selectionMode="single" selectionKeys={this.state.selectedNodeKey} onSelectionChange={e => this.setState({selectedNodeKey: e.value})}/>
                        }
                        <Menu model={items} style={{width:"100%", textAlign:"left"}}/>
                        </Panel>
                    </Grid>
                    <Grid item xs={9}>
                        <Panel header="Editar Homologación COST DRIVER UNIDAD">
                        {this.state.mostrarDetalle&&
                            <TablaDinamica parametros={this.ObtenerParametrosDetalle()}/>
                        }
                        </Panel>
                        <Panel header="Detalle de Registros de COST DRIVER UNIDAD" style={{height: '100px'}}>
                            {this.state.mostrarSubdetalle&&
                            <TablaDinamica parametros={this.ObtenerParametrosSubDetalle()}/>
                            }

                        </Panel>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        breadcrumb: state.breadcrumb
     };
}

const mapDispatchToProps = {
}


export default connect(mapStateToProps, mapDispatchToProps)(Homologacion);