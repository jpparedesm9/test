# Backend

El backend basa su funcionamiento en el uso de endpoints; usted puede encontrar detalles de todas las estructuras creadas en esta sección.

---

### Tecnologías utilizadas

Al tratarse de una aplicación con proyección a una alta transaccionalidad detaca el uso de las siguientes tecnologías.  

- __[MongoDB](https://www.mongodb.com/)__ -  Base de datos NoSQL.
- __[Nodejs](https://nodejs.org/es/)__ - Entorno de tiempo de ejecución JavaScript para el servidor.
- __[Express](https://expressjs.com/)__ - Framework Nodejs.


## Estructura
```no-highlight
package.json
app.js
controllers/
    user-controllers.js
middleware/
    check-auth.js
models/
    user.js
routes/
    user-routes.js
```
afasdf
## Base de Datos
![Screenshot](img/mongoTree.png)
![Screenshot](img/mongoServer.png)
![Screenshot](img/mongoPassword.png)




!!! note "Notas"
    Se recomienda el uso de un servidor Centos o Ubuntu.



