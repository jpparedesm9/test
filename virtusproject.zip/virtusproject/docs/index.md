# Proyecto Virtus

Bienvenido a la documentacion de el proyecto Virtus.

## Arquitectura

La arquitectura de el sistema se resume en tres bloques principales:

![Screenshot](img/Diagrama.png)
