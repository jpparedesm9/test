package com.formos.sales.model;

import com.formos.sales.util.Measure;

public class Ingredient {

	private String name;
	private Double quantity;
	private Measure unitMeasure;

	public Ingredient(String name, Double quantity, Measure unitMeasure) {
		this.name = name;
		this.quantity = quantity;
		this.unitMeasure = unitMeasure;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Measure getUnitMeasure() {
		return unitMeasure;
	}

	public void setUnitMeasure(Measure unitMeasure) {
		this.unitMeasure = unitMeasure;
	}

}
