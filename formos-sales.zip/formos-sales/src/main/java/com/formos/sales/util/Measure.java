package com.formos.sales.util;

public enum Measure {
	ML, G
}