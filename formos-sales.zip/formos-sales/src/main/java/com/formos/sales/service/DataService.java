package com.formos.sales.service;

import java.util.HashMap;
import java.util.Map;

import com.formos.sales.model.Ingredient;
import com.formos.sales.model.Recipe;
import com.formos.sales.util.Measure;

public class DataService {

	/**
	 * This method allows to return the whole data inventory
	 * 
	 * @return Returns a map with data inventory
	 */
	public static Map<String, Ingredient> getInventory() {
		Map<String, Ingredient> inventory = new HashMap<String, Ingredient>();
		inventory.put("Strawberry", new Ingredient("Strawberry", 500.0, Measure.G));
		inventory.put("Banana", new Ingredient("Banana", 20.0, Measure.G));
		inventory.put("Mango", new Ingredient("Mango", 20.0, Measure.G));
		inventory.put("Condensed_Milk", new Ingredient("Condensed_Milk", 20.0, Measure.G));
		inventory.put("Sugar", new Ingredient("Sugar", 20.0, Measure.G));
		inventory.put("Ice", new Ingredient("Ice", 20.0, Measure.G));
		return inventory;
	}

	public static Map<String, Recipe> getAvailableDrinks() {
		Map<String, Double> strawberryRecipe = getStrawberryReceipe();
		Map<String, Double> bananaRecipe = getBananaReceipe();
		Map<String, Double> mangoRecipe = getMangoReceipe();

		Map<String, Recipe> drinks = new HashMap<String, Recipe>();
		drinks.put("Strawberry", new Recipe(strawberryRecipe));
		drinks.put("Banana", new Recipe(bananaRecipe));
		drinks.put("Mango", new Recipe(mangoRecipe));
		return drinks;
	}

	private static Map<String, Double> getStrawberryReceipe() {
		Map<String, Double> recipeDetail = new HashMap<String, Double>();
		recipeDetail.put("Strawberry", 50.0); // This includes 50 ml of blended fruit
		recipeDetail.put("Sugar", 30.0);
		recipeDetail.put("Ice", 10.0);
		recipeDetail.put("Condensed_Milk", 20.0);
		return recipeDetail;
	}

	private static Map<String, Double> getBananaReceipe() {
		Map<String, Double> recipeDetail = new HashMap<String, Double>();
		recipeDetail.put("Banana", 60.0); // This includes 50 ml of blended fruit
		recipeDetail.put("Sugar", 8.0);
		recipeDetail.put("Ice", 30.0);
		recipeDetail.put("Condensed_Milk", 20.0);
		return recipeDetail;
	}

	private static Map<String, Double> getMangoReceipe() {
		Map<String, Double> recipeDetail = new HashMap<String, Double>();
		recipeDetail.put("Mango", 70.0); // This includes 50 ml of blended fruit
		recipeDetail.put("Sugar", 30.0);
		recipeDetail.put("Ice", 10.0);
		recipeDetail.put("Condensed_Milk", 20.0);
		return recipeDetail;
	}

}
