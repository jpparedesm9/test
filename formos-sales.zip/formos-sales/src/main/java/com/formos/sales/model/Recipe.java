package com.formos.sales.model;

import java.util.Map;

public class Recipe {

	private Map<String, Double> recipe;

	public Recipe(Map<String, Double> recipe) {
		this.recipe = recipe;
	}

	public Map<String, Double> getRecipe() {
		return recipe;
	}

	public void setRecipe(Map<String, Double> recipe) {
		this.recipe = recipe;
	}
}
