package com.formos.sales.model;

import java.util.Map;

public class Sale {

	private String drinkName;
	private Integer size;
	private Map<String, Double> ingredients;

	public Sale(String drinkName_p, Integer size_p, Map<String, Double> ingredients_p) {
		setDrinkName(drinkName_p);
		setSize(size_p);
		setIngredients(ingredients_p);
	}

	public String getDrinkName() {
		return drinkName;
	}

	public void setDrinkName(String drinkName) {
		this.drinkName = drinkName;
	}

	public Integer getSize() {
		return size;
	}

	public Map<String, Double> getIngredients() {
		return ingredients;
	}

	public void setIngredients(Map<String, Double> ingredients) {
		this.ingredients = ingredients;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

}
