package com.formos.sales.menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.formos.sales.model.Ingredient;
import com.formos.sales.model.Recipe;
import com.formos.sales.model.Sale;
import com.formos.sales.util.Validator;

public class SellDrink {
	String globalFlavors[] = { "Strawberry", "Banana", "Mango", "Combined" };
	Map<String, Ingredient> inventory;
	Map<String, Recipe> drinks;

	private Map<String, Double> getIngredientsNeeds(Map<Integer, Double> products) {
		Map<String, Double> finalRecipe = new HashMap<String, Double>();
		;
		for (Map.Entry<Integer, Double> entry : products.entrySet()) {
			Map<String, Double> currentRecipe;
			currentRecipe = drinks.get(globalFlavors[entry.getKey() - 1]).getRecipe();
			currentRecipe
					.forEach((key, value) -> finalRecipe.merge(key, value * entry.getValue(), (v1, v2) -> v1 + v2));
		}
		return finalRecipe;
	}

	private ArrayList<String> getMissingIngredients(Map<String, Double> finalRecipe, Integer size,
			Boolean warningLevel) {
		ArrayList<String> missingIngredients = new ArrayList<String>();
		;

		for (Map.Entry<String, Double> recipe : finalRecipe.entrySet()) {
			if (!(recipe.getValue() * size * (warningLevel ? 5 : 1) < inventory.get(recipe.getKey()).getQuantity()))
				missingIngredients.add(recipe.getKey());
		}
		return missingIngredients;
	}

	SellDrink(Map<String, Ingredient> inventory_p, Map<String, Recipe> drinks_p) {
		this.inventory = inventory_p;
		this.drinks = drinks_p;
	}

	public Map<Integer, Double> getCombinedProcessIds() {
		int swValue;
		Map<Integer, Double> combinedDrinks = new HashMap<Integer, Double>();

		for (Integer i = 0; i < 2; i++) {
			showPossibleFlavorsMenu();
			swValue = Validator.inInt(" Choose a flavor: ");
			combinedDrinks.put(swValue, 0.5);
		}
		return combinedDrinks;
	}

	public Sale saleProcess(Integer flavorSelection) {
		Map<Integer, Double> flavors;
		System.out.flush();
		int swValue;
		System.out.println("| MAIN MENU>>>>SELL A DRINK >>> Drink Size  |");
		System.out.println("| Options:                                  |");
		System.out.println("|      1. Small  (100 ml)                   |");
		System.out.println("|      2. Medium (200 ml)                   |");
		System.out.println("|      3. Large  (300 ml)                   |");
		swValue = Validator.inInt(" Select option: ");

		if (flavorSelection == 4) {
			flavors = getCombinedProcessIds();
		} else {
			flavors = new HashMap<Integer, Double>();
			flavors.put(flavorSelection, 1.0);
		}
		Map<String, Double> ingredientsNeeds = getIngredientsNeeds(flavors);
		ArrayList<String> missingIngredients = getMissingIngredients(ingredientsNeeds, swValue, false);
		if (missingIngredients.size() != 0) {
			System.out.println(" -------------No enough Stock  -----------");
			System.out.println(
					" We don't have enough Ingredients. Please review inventory for the following Ingredients:");
			for (String ingredient : missingIngredients) {
				System.out.println(ingredient);
			}
			return null;
		} else {
			ArrayList<String> ingredientsWarning = getMissingIngredients(ingredientsNeeds, swValue, true);
			if (missingIngredients.size() != 0) {
				System.out.println(" -------------Stock  Warning-----------");
				System.out.println(" Please review inventory for the following Ingredients:");
				for (String ingredient : ingredientsWarning) {
					System.out.println(ingredient);
				}
			}
		}
		return new Sale(globalFlavors[flavorSelection - 1], swValue, ingredientsNeeds);
	}

	private void showPossibleFlavorsMenu() {
		System.out.println("|      1. Strawberry        |");
		System.out.println("|      2. Banana            |");
		System.out.println("|      3. Mango             |");
		return;
	}

	public Sale initSell() {
		int swValue;
		System.out.flush();
		System.out.println("| MAIN MENU>>>>SELL A DRINK |");
		System.out.println("| Options:                  |");
		showPossibleFlavorsMenu();
		System.out.println("|      4. Combined          |");
		System.out.println("|      5. Go Back           |");
		swValue = Validator.inInt(" Select option: ");

		Sale saleResult = null;
		if (swValue <= 5 && swValue > 0) {
			saleResult = saleProcess(swValue);
		}

		return saleResult;
	}
}
