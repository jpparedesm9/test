package com.formos.sales.menu;

import java.util.Map;

import com.formos.sales.model.Ingredient;
import com.formos.sales.model.Recipe;
import com.formos.sales.model.Sale;
import com.formos.sales.util.Validator;

public class MainSelection {
	Map<String, Ingredient> inventory;
	Map<String, Recipe> drinks;

	public Map<String, Recipe> getDrinks() {
		return drinks;
	}

	public void setDrinks(Map<String, Recipe> drinks) {
		this.drinks = drinks;
	}

	public Map<String, Ingredient> getInventory() {
		return inventory;
	}

	public void setInventory(Map<String, Ingredient> inventory) {
		this.inventory = inventory;
	}

	public MainSelection(Map<String, Ingredient> inventory_p, Map<String, Recipe> drinks_p) {
		setInventory(inventory_p);
		setDrinks(drinks_p);
	}

	private void sellDrink() {
		SellDrink sellDrinkObj = new SellDrink(this.inventory, this.drinks);
		Sale result = sellDrinkObj.initSell();
		System.out.println(result);
	}

	public void displayMenu() {
		int swValue;
		do {
			System.out.flush();
			System.out.println("|          MAIN MENU       |");
			System.out.println("| Options:                 |");
			System.out.println("|      1. Sell a Drink     |");
			System.out.println("|      1. Update Inventory |");
			System.out.println("|      1. Sales Report     |");
			System.out.println("|      3. Exit         |");
			swValue = Validator.inInt(" Select option: ");

			// Switch construct
			switch (swValue) {
			case 1:
				sellDrink();
				break;
			case 2:
				System.out.println("Option 2 selected");
				break;
			case 3:
				System.out.println("Exit selected");
				break;
			default:
				System.out.println("Invalid selection");
				break; // This break is not really necessary
			}
		} while (swValue != 3);
	}

}
