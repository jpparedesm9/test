package com.formos.sales.main;

import java.util.Map;

import com.formos.sales.menu.MainSelection;
import com.formos.sales.model.Ingredient;
import com.formos.sales.model.Recipe;
import com.formos.sales.service.DataService;

public class EntryPoint {

	public static void main(String[] args) {
		Map<String, Ingredient> inventory = DataService.getInventory();
		Map<String, Recipe> drinks = DataService.getAvailableDrinks();

		MainSelection mainSelection = new MainSelection(inventory, drinks);
		mainSelection.displayMenu();
	}
}
