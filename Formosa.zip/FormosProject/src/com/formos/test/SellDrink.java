package com.formos.test;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class SellDrink {
    String flavors[]={"Strawberry","Banana","Mango"};
    Map<String, Ingredient> inventory;
    Map<String, Recipe> drinks;

    private Map<String,Boolean> validateStock(Map<Integer,Double> products,Integer size,Boolean warningLevel){    	
        Map<String,Boolean> ingredientsAvailability=new HashMap<String, Boolean>();
        for (Map.Entry<Integer,Double> entry : products.entrySet())
        {
        	Map <String,Double> currentRecipe;
        	currentRecipe=drinks.get(flavors[entry.getKey()-1]).getRecipe();
        	
            for (Map.Entry<String,Double> recipe : currentRecipe.entrySet()){
                ingredientsAvailability.put(recipe.getKey(),
                (recipe.getValue()*entry.getValue()*3*(warningLevel?5:1)<inventory.get(recipe.getKey()).getQuantity()));
            }
        }
       return ingredientsAvailability;
    }

    SellDrink(Map<String, Ingredient> inventory_p, Map<String, Recipe> drinks_p)
    {
        this.inventory=inventory_p;
        this.drinks=drinks_p;
    }

    public Map<Integer,Double> getCombinedProcessIds(){
        int swValue;
        Map<Integer,Double> combinedDrinks=new HashMap<Integer, Double>();

        for(Integer i=0;i<2;i++){
            showPossibleFlavorsMenu();
            swValue = Validator.inInt(" Choose a flavor: ");
            combinedDrinks.put(swValue,0.5);
        }
        return combinedDrinks;
    }
    public void saleProcess(Integer flavorSelection){
        Map<Integer,Double> flavors;
        System.out.flush();
        int swValue;
        System.out.println("| MAIN MENU>>>>SELL A DRINK >>> Drink Size  |");
        System.out.println("| Options:                                  |");
        System.out.println("|      1. Small  (100 ml)                   |");
        System.out.println("|      2. Medium (200 ml)                   |");
        System.out.println("|      3. Large  (300 ml)                   |");
        swValue = Validator.inInt(" Select option: ");

        if (flavorSelection==4){
            flavors=getCombinedProcessIds();
        }
        else{
            flavors=new HashMap<Integer, Double>();
            flavors.put(flavorSelection,1.0);
        }
        Map<String,Boolean> result=validateStock(flavors,swValue,false);
        
        for (Entry<String, Boolean> entry2 : result.entrySet()) {
        	 System.out.println(entry2.getKey());
        	 System.out.println(entry2.getValue());
        }
       

    }
    private void showPossibleFlavorsMenu(){
        System.out.println("|      1. Strawberry        |");
        System.out.println("|      2. Banana            |");
        System.out.println("|      3. Mango             |");
        return;
    }
    public Integer initSell(){
        int swValue;
            System.out.flush();
            System.out.println("| MAIN MENU>>>>SELL A DRINK |");
            System.out.println("| Options:                  |");
            showPossibleFlavorsMenu();
            System.out.println("|      4. Combined          |");
            System.out.println("|      5. Go Back           |");
            swValue = Validator.inInt(" Select option: ");
            saleProcess(swValue);
        return 1;
    }
}
