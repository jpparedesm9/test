package com.formos.test;
import java.util.Map;

public class Recipe {
    Map <String,Double> recipe;
    Recipe(Map <String,Double> recipe_p){
        setRecipe(recipe_p);
    }
    public Map<String, Double> getRecipe() {
        return recipe;
    }
    public void setRecipe(Map<String, Double> recipe) {
        this.recipe = recipe;
    }
}
