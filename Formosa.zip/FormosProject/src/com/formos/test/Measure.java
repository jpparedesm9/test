package com.formos.test;

public enum Measure
{
    ml,g
}