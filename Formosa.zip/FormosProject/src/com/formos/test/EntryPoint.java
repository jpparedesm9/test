package com.formos.test;

import java.util.HashMap;
import java.util.Map;

public class EntryPoint {

	public static void main(String[] args) {
		/******* Setting initial Values********/
		Map<String, Ingredient> inventory = new HashMap<String, Ingredient>();
		inventory.put("Strawberry",new Ingredient("Strawberry",500.0,Measure.g));
		inventory.put("Banana",new Ingredient("Banana",20.0,Measure.g));
		inventory.put("Mango",new Ingredient("Mango",20.0,Measure.g));
		inventory.put("Condensed_Milk",new Ingredient("Condensed_Milk",20.0,Measure.g));
		inventory.put("Sugar",new Ingredient("Sugar",20.0,Measure.g));
		inventory.put("Ice",new Ingredient("Ice",20.0,Measure.g));


		Map<String, Double> recipeDetail = new HashMap<String, Double>();
		recipeDetail.put("Strawberry",50.0); // This includes 50 ml of blended fruit
		recipeDetail.put("Sugar",30.0);
		recipeDetail.put("Ice",10.0);
		recipeDetail.put("Condensed_Milk",20.0);

		Map<String, Recipe> drinks= new HashMap<String, Recipe>();
		drinks.put("Strawberry",new Recipe(recipeDetail));

		Map<String, Double> recipeDetail2 = new HashMap<String, Double>();

		recipeDetail2.put("Banana",60.0);  // This includes 50 ml of blended fruit
		recipeDetail2.put("Sugar",8.0);
		recipeDetail2.put("Ice",30.0);
		recipeDetail2.put("Condensed_Milk",20.0);

		drinks.put("Banana",new Recipe(recipeDetail2));
		
		Map<String, Double> recipeDetail3 = new HashMap<String, Double>();

		recipeDetail3.put("Mango",70.0);  // This includes 50 ml of blended fruit
		recipeDetail3.put("Sugar",30.0);
		recipeDetail3.put("Ice",10.0);
		recipeDetail3.put("Condensed_Milk",20.0);

		drinks.put("Mango",new Recipe(recipeDetail3));
		/******* End - Setting initial Values********/

		MainSelection mainSelectionObj=new MainSelection(inventory,drinks);
		mainSelectionObj.displayMenu();

	}
}

